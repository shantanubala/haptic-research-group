

void UTMinv(int zoneLon, char zoneLat, double NtrmsB, double NtrmsD, int LLonly,
         double X, double Y, double *Lambda, double *Phi, double *pscale,
         double *CoM);