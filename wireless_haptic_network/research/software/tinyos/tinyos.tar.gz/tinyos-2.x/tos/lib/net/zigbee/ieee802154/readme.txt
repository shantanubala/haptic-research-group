Title: ZigBee
Author: Andr� Cunha - IPP-HURRAY! http://www.open-zb.net
----------------------------------------------


Notes:
------
This folder contains the main implementation files.

Note that the IEEE 802.15.4 MAC is implemented in the mac and timerasync folders and the IEEE 802.15.4
with the Zigbee Network layer including the Cluster-tree formation with the TDBS mechanism (refer to http://www.open-zb.net/publications/hurray-tr-070102.pdf)
is implemented in the macTDBS and timerasyncTDBS