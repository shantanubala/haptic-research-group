
#ifndef _POOL_THREAD_H_
#define _POOL_THREAD_H_

#ifndef NUM_POOL_THREADS
#define NUM_POOL_THREADS 5
#endif

#ifndef POOL_THREAD_STACK_SIZE
#define POOL_THREAD_STACK_SIZE 200
#endif

#endif

