/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef SPIRCB_H_
#define SPIRCB_H_

#include <avrhardware.h>
#include <hardware.h>
#include <tos.h>

TOSH_ASSIGN_PIN(SPI_RCB_CSN, A, 0);  // CSN output SPI interface.
TOSH_ASSIGN_PIN(SPI_RCB_SCLK, A, 1);
TOSH_ASSIGN_PIN(SPI_RCB_MOSI, A, 2);
TOSH_ASSIGN_PIN(SPI_RCB_MISO, A, 3);

/****************************************************************
  Performs a initialization of SPI pins.
****************************************************************/
void spi_rcb_init();

/****************************************************************
  Deselects a slave.
****************************************************************/
void spi_rcb_deselect();

/****************************************************************
  Selects a slave.
****************************************************************/
void spi_rcb_select();

/****************************************************************
  Writes a byte to spi.
    Writes a byte to selected a slave. Reads a byte from a slave.
  Returns:
    a delivered byte.
****************************************************************/
uint8_t spi_rcb_write(uint8_t value);

#endif /* SPIRCB_H_ */
