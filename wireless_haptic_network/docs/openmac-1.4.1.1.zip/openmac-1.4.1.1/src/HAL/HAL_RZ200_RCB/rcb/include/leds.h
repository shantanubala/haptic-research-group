/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef LEDS_H_
#define LEDS_H_ 1

#include <pwrctrl.h>
#include <avrhardware.h>
#include <gpio.h>

// The defines of the potential levels
#define LED_ON  0
#define LED_OFF 1

#define LED_RED    GPIO_0
#define LED_GREEN  GPIO_1
#define LED_YELLOW GPIO_2

/****************************************************************
  Opens leds module to use.
  Returns: 
    SUCCESS - always.
****************************************************************/
result_t leds_open(void);

/****************************************************************
  Closes leds module.
  Returns: 
    SUCCESS - always.
****************************************************************/
result_t leds_close(void);

/****************************************************************
  Turns on n­th LED.
  Parameters:
    id - number of led
****************************************************************/
void leds_on(uint8_t id);

/****************************************************************
  Turns off n­th LED.
    Parameters:
      id - number of led
****************************************************************/
void leds_off(uint8_t id);

/****************************************************************
  Changes n­th LED state to opposite.
    Parameters:
      id - number of led
****************************************************************/
void leds_toggle(uint8_t id);

#endif /*LEDS_H_*/
