/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The implementation of SPI module on RCB.
  SPI protocol uses mode 0 as defined in the Mega 128 data sheet.
****************************************************************/

#include <spircb.h>

/****************************************************************
  Performs a initialization of SPI pins.
****************************************************************/
void spi_rcb_init()
{
  TOSH_MAKE_SPI_RCB_MISO_INPUT();
  TOSH_MAKE_SPI_RCB_SCLK_OUTPUT();
  TOSH_MAKE_SPI_RCB_MOSI_OUTPUT();
  TOSH_MAKE_SPI_RCB_CSN_OUTPUT();
  TOSH_CLR_SPI_RCB_SCLK_PIN();
  spi_rcb_deselect();
}

/****************************************************************
  Deselects a slave.
****************************************************************/
void spi_rcb_deselect()
{
  TOSH_SET_SPI_RCB_CSN_PIN();
}

/****************************************************************
  Selects a slave.
****************************************************************/
void spi_rcb_select()
{
  TOSH_CLR_SPI_RCB_CSN_PIN();
}

/****************************************************************
  Writes a byte to spi. 
    Writes a byte to selected a slave. Reads a byte from a slave.
  Returns:
    a delivered byte.
****************************************************************/
uint8_t spi_rcb_write(uint8_t value)
{
  uint8_t i = 8, j;
  for( ; i ; i-- )
  {
    TOSH_CLR_SPI_RCB_SCLK_PIN();
    if(value & 0x80)
      TOSH_SET_SPI_RCB_MOSI_PIN();
    else
      TOSH_CLR_SPI_RCB_MOSI_PIN();
    TOSH_SET_SPI_RCB_SCLK_PIN();
    value <<= 1;
    j <<= 1;
    j |= TOSH_READ_SPI_RCB_MISO_PIN();
  }
  TOSH_CLR_SPI_RCB_SCLK_PIN();
  return j;
}

// eof hplspi.c
