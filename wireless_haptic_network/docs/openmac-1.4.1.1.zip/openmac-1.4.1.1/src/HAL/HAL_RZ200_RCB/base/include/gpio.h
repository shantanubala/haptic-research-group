/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef GPIO_H_
#define GPIO_H_

#include <tos.h>

#define GPIO_0 0              //GPIO0 ZigBit pin name 
#define GPIO_1 1              //GPIO1 ZigBit pin name 
#define GPIO_2 2              //GPIO2 ZigBit pin name  
#define GPIO_3 3              //GPIO3 ZigBit pin name    
#define GPIO_4 4              //GPIO4 ZigBit pin name  
#define GPIO_5 5              //GPIO5 ZigBit pin name 
#define GPIO_6 6              //GPIO6 ZigBit pin name 
#define GPIO_7 7              //GPIO7 ZigBit pin name 
#define GPIO_8 8              //GPIO8 ZigBit pin name 
#define GPIO_I2C_CLK 9        //I2C_CLK ZigBit pin name  
#define GPIO_I2C_DATA 10      //I2C_DATA ZigBit pin name 
#define GPIO_UART_TXD 11      //UART_TXD ZigBit pin name 
#define GPIO_UART_RXD 12      //UART_RXD ZigBit pin name 
#define GPIO_UART_RTS 13      //UART_RTS ZigBit pin name 
#define GPIO_UART_CTS 14      //UART_CTS ZigBit pin name 
#define GPIO_ADC_INPUT_3 15   //ADC_INPUT_3 ZigBit pin name 
#define GPIO_ADC_INPUT_2 16   //ADC_INPUT_2 ZigBit pin name 
#define GPIO_ADC_INPUT_1 17   //ADC_INPUT_1 ZigBit pin name 
#define GPIO_BAT 18           //BAT ZigBit pin name 
#define GPIO_1WR 19           //1WR ZigBit pin name 
#define GPIO_UART_DTR 20      //UART_DTR ZigBit pin name 
#define GPIO_USART0_RXD 21    //USART0_RXD ZigBit pin name 
#define GPIO_USART0_TXD 22    //USART0_TXD ZigBit pin name 
#define GPIO_USART0_EXTCLK 23 //UART0_EXTCLK ZigBit pin name 
#define GPIO_IRQ_6 24         //IRQ_6 ZigBit pin name 
#define GPIO_IRQ_7 25         //IRQ_7 ZigBit pin name 
#define GPIO_IRQ_5 26         //IRQ_5 ZigBit pin name 


typedef enum
{
  GPIO_INPUT_PULLUP_OFF, // input, pullup is off
  GPIO_INPUT_PULLUP_ON,  // input, pullup is on
  GPIO_Z,                // tri-state
  GPIO_OUTPUT            // output
} GPIOMode_t;

/*=============================================================
 Configure particular pin of ZigBit module to the specified 
 mode
 Parameters:
   pin  - GPIO pin sequence number.
   mode - GPIO mode.
 Returns:
   FAIL    - if there is no such GPIO pin sequence number.
   SUCCESS - otherwise.
===============================================================*/
result_t gpio_setConfig(uint8_t pin, GPIOMode_t mode);

/*=============================================================
 Read configuration for particular pin. Configuration is 
 returned in mode.
 Parameters:
   pin  - GPIO pin sequence number.
   mode - GPIO mode.
 Returns:
   FAIL    - if there is no such GPIO pin sequence number.
   SUCCESS - otherwise.
===============================================================*/
result_t gpio_getConfig(uint8_t pin, GPIOMode_t *mode);

/*=============================================================
 Get state of pin into value.
 Parameters:
   pin  - GPIO pin sequence number.
   value   - value of GPIO pin (0 or 1).
 Returns:
   FAIL    - if there is no such GPIO pin sequence number.
   SUCCESS - otherwise.
===============================================================*/
result_t gpio_getState(uint8_t pin, uint8_t *value);

/*=============================================================
 Get state of pin into value.
 Parameters:
   pin   - GPIO pin sequence number.
   value - value of GPIO pin (0 or 1).
 Returns:
   FAIL    - if there is no such GPIO pin sequence number.
   SUCCESS - otherwise.
===============================================================*/
result_t gpio_setState(uint8_t pin, uint8_t value);

#endif /* GPIO_H_ */

// eof gpio.h
