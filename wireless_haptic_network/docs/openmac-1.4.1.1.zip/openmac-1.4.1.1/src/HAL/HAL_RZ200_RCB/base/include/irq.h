/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef IRQ_H_
#define IRQ_H_

#include <tos.h>

#define IRQ_0 0
#define IRQ_1 1
#define IRQ_2 2
#define IRQ_3 3
#define IRQ_4 4
#define IRQ_5 5  // Valid for use
#define IRQ_6 6  // Valid for use
#define IRQ_7 7  // Valid for use

#define NUM_IRQ_LINES 3
#define FIRST_VALID_IRQ IRQ_5

// interrupt activation condition.
typedef enum
{
  IRQ_LOW_LEVEL,     // The low level generates an interrupt request.
  IRQ_ANY_EDGE,      // Any edge generates an interrupt request.
  IRQ_FALLING_EDGE,  // Falling edge generates an interrupt request.
  IRQ_RISING_EDGE    // Rising edge generates an interrupt request.
} irqMode_t;

/*=============================================================
 Registers user's irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
   irqMode   - Interrupt sence control
   f         - user's interrupt handler
 Returns:
   FAIL    - if irqNumber is out of range or such interrupt has 
             been already registered.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_register(uint8_t irqNumber, irqMode_t irqMode, void (*f)(void));

/*=============================================================
 Enables irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
 Returns:
   FAIL    - if irqNumber is out of range or has not been 
             registered yet.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_enable(uint8_t irqNumber);

/*=============================================================
 Disables irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
 Returns:
   FAIL    - if irqNumber is out of range or has not been 
             registered yet.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_disable(uint8_t irqNumber);

/*=============================================================
 Unregisters user's irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
 Returns:
   FAIL    - if irqNumber is out of range or has not been 
             registered yet.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_unregister(uint8_t irqNumber);

#endif /* IRQ_H_ */
