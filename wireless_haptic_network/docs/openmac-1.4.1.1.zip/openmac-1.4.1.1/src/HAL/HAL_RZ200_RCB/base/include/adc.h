/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


#ifndef ADC_H_
#define ADC_H_

#include <tos.h>

#define ADC_BAT 0       //ADC channel 0
#define ADC_INPUT_1 1   //ADC channel 1
#define ADC_INPUT_2 2   //ADC channel 2
#define ADC_INPUT_3 3   //ADC channel 3

// Voltage Reference = Internal 1.1V Voltage Reference with external capacitor at AREF pin.
// Right adjusted result
#define HAL_ADC_REF_VOLTAGE_SOURCE (0 << REFS0 | 1 << REFS1)

/*=============================================================
 Opens channel adcNumber, registers callback for data 
 indication
 Parameters:
   adcNumber - channel number.
   f         - data indicaion handler.
 Returns:
   FAIL    - if adcNumber is out of range or channel has been   
             already opened.
   SUCCESS - otherwise.
===============================================================*/
result_t adc_open(uint8_t adcNumber, void (*f)(uint16_t data));

/*=============================================================
 Gets sample from ADC channel adcNumber. The result is returned
 by callback registered by adc_open() function.
 Parameters:
   adcNumber - channel number.
 Returns:
   FAIL    - if adcNumber is out of range or channel has been   
             already opened.
   SUCCESS - otherwise.
===============================================================*/
result_t adc_get(uint8_t adcNumber);

/*=============================================================
 Closes adcNumber channel
 Parameters:
   adcNumber - channel number.
 Returns:
   FAIL    - if adcNumber is out of range or channel has been   
             already opened.
   SUCCESS - otherwise.
===============================================================*/
result_t adc_close(uint8_t adcNumber);

#endif /* ADC_H_ */

// eof adc.h
