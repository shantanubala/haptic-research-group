/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/*===============================================================
The implementation of access to at86rf230.
=================================================================*/

#include <tos.h>
#include <hplat86rf230m.h>
#include <hardware.h>
#include <atomic.h>
#include <at86rf230.h>
#include <hplspi.h>

uint8_t HPLAT86RF230C__descriptor = 0; // descriptor
bool HPLAT86RF230C__init = FALSE;
void (*HPLAT86RF230Cirq)();            //callback pointer

void HPLAT86RF230C__HPLAT86RF230__reset()
{
uint8_t i;
    TOSH_CLR_TRSLEEP_PIN();
    TOSH_MAKE_TRSLEEP_OUTPUT();

    HPLAT86RF230C__HPLAT86RF230__clrRST();
    TOSH_MAKE_RSTIN_OUTPUT();
    for(i = 0; i < 8 ; i++)
      __delay_us(250);
    HPLAT86RF230C__HPLAT86RF230__setRST();

    i = 0;
    (*((RegTrxState *)(&i))).trx_cmd = AT86RF230_TRX_CMD_TRX_OFF;
    HPLSPIM__HPLSPI__init();
    HPLSPIM__HPLSPI__clrCS();
      HPLSPIM__HPLSPI__write( (AT86RF230_TRX_STATE_REG & AT86RF230_RADDRM) | AT86RF230_CMD_RW);
      HPLSPIM__HPLSPI__write( i );
    HPLSPIM__HPLSPI__setCS();
}


/****************************************************************
  Makes RST and SLP_TR pins as outputs. Setups irq parameters.
****************************************************************/  
void HPLAT86RF230C__HPLAT86RF230__init()
{
  if( HPLAT86RF230C__init == FALSE)
  {
    HPLAT86RF230C__init = TRUE;        
    TCCR1B = (1 << ICES1) | (1 << CS10);// rising edge, no prescaling   
    TIFR1 = (1 << ICF1); // clear interrupt flag
  }
}


/****************************************************************
  Sets irq handler.
  Parameters:
    irq - callback
  Returns:
    FAIL - there is previous open call
    SUCCESS - otherwise.
****************************************************************/  
result_t HPLAT86RF230C__HPLAT86RF230__open(void (*irq)())
{
    if(HPLAT86RF230C__descriptor || !irq)
    { 
      return FAIL;
    }
    HPLAT86RF230C__HPLAT86RF230__reset();
    HPLAT86RF230C__HPLAT86RF230__init();
    HPLAT86RF230C__descriptor = 1;
    HPLAT86RF230Cirq = irq;
  return SUCCESS;
}

/****************************************************************
  Cancels irq handler.
  Returns:
    FAIL - there is no previous open call 
    SUCCESS - otherwise.
****************************************************************/  
result_t HPLAT86RF230C__HPLAT86RF230__close()
{
  if(HPLAT86RF230C__descriptor)
  {
    ATOMIC_SECTION_ENTER
    {
      HPLAT86RF230C__HPLAT86RF230__irqDisable();
      HPLAT86RF230C__descriptor = 0;
    }
    ATOMIC_SECTION_LEAVE
    return SUCCESS; 
  }
  return FAIL;  
}

/****************************************************************
  Enables the irq.
  Returns:
    FAIL - there is no previous open call 
    SUCCESS - otherwise.
****************************************************************/    
result_t HPLAT86RF230C__HPLAT86RF230__irqEnable()
{
  if( HPLAT86RF230C__descriptor )
  { 
    TIMSK1 |= (1 << ICIE1);
   return SUCCESS;
  }
  return FAIL;
}

/****************************************************************
  Disables the irq.
****************************************************************/  
void HPLAT86RF230C__HPLAT86RF230__irqDisable()
{
  TIMSK1 &= ~(1 << ICIE1);
}


/****************************************************************
  Sets RST pin to 1.
****************************************************************/    
void HPLAT86RF230C__HPLAT86RF230__setRST()
{
  TOSH_SET_RSTIN_PIN();
}

/****************************************************************
 Sets RST pin to 0.
****************************************************************/  
void HPLAT86RF230C__HPLAT86RF230__clrRST()
{
  TOSH_CLR_RSTIN_PIN();
}

/****************************************************************
  Sets SLP_TR pin to 1.
****************************************************************/
void HPLAT86RF230C__HPLAT86RF230__setSLPTR()
{
  TOSH_SET_TRSLEEP_PIN();
}

/****************************************************************
  Sets SLP_TR pin to 0.
****************************************************************/  
void HPLAT86RF230C__HPLAT86RF230__clrSLPTR()
{
  TOSH_CLR_TRSLEEP_PIN();
}

/****************************************************************
  Interrupt handler.
****************************************************************/
SIGNAL(SIG_INPUT_CAPTURE1)
{
  if(HPLAT86RF230Cirq && HPLAT86RF230C__descriptor) 
    HPLAT86RF230Cirq();
}

//endof hplat86rf230m.c
