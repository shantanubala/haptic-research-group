/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The module to control the power on periphery
****************************************************************/

#include <tos.h>
#include <pwrctrl.h>
#include <hplat86rf230m.h>

uint8_t power_control = 0;

/****************************************************************
  Powers on periphery.
*****************************************************************/
void hpl__peripherial__on( uint8_t id )
{
  if( !power_control )
  { 
#ifndef WDM_A1281_P1
	 TOSH_MAKE_SHDN_OUTPUT();
	 TOSH_CLR_SHDN_PIN();
#endif
   TOSH_MAKE_BTM_OUTPUT();
   TOSH_SET_BTM_PIN();
   TOSH_MAKE_VTE_OUTPUT();
   TOSH_SET_VTE_PIN();
  }
  power_control |= (1 << id);
}


/****************************************************************
  Powers off periphery.
****************************************************************/
void hpl__peripherial__off( uint8_t id )
{
  power_control &= ~(1 << id);
  if( power_control ) return;
#ifndef WDM_A1281_P1
	TOSH_MAKE_SHDN_OUTPUT();
	TOSH_SET_SHDN_PIN();
#endif
  TOSH_MAKE_BTM_OUTPUT();
  TOSH_CLR_BTM_PIN();
  TOSH_MAKE_VTE_OUTPUT();
  TOSH_CLR_VTE_PIN();
}

// eof hplpower.c
