/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The access to keys.
****************************************************************/

#include <tos.h>
#include <buttons.h>
#include <apptimer.h>

#ifndef KEY0
#define KEY0 GPIO_IRQ_6
#endif
#ifndef KEY1
#define KEY1 GPIO_IRQ_7
#endif

BUTTEventFunk vBUTTPressHandl;   // callback 
BUTTEventFunk vBUTTReleaseHandl; // callback

uint8_t button_state;                   // Current state of buttons.
int iButtonsPeriodicalTimer;     // timer descriptor 
   
void vbuttons__timer__fire(void); // callback of timer when one expired.

/****************************************************************
  Initializes buttons module.
****************************************************************/
void buttons_init()
{
uint8_t value, i;
static bool flag = FALSE;
  if( flag == TRUE ) return;
  flag = TRUE;
    button_state = 0;
    for (i = 0; i < MAX_BUTTONS_COUNT; i++)
    {
      gpio_setConfig(KEY0 + i, GPIO_INPUT_PULLUP_ON);
      gpio_getState( KEY0 + i, &value);
      button_state |= ( value & 0x01) << i;
    }
	appTimer_init();
	iButtonsPeriodicalTimer = appTimer_open(vbuttons__timer__fire);
	appTimer_start(iButtonsPeriodicalTimer, TIMER_REPEAT_MODE, SAMPLE_PERIOD);
  return ; 
}

/****************************************************************
  Register handlers for button events, that will be called in 
  the non­interrupt context.  
  Paremeters:
    pressed – the handler to process pressing the button
    released ­ the handler to process releasing the button
    bn – button number. 
  Returns:
  SUCCESS - always.
****************************************************************/
result_t buttons_open(void (*pressed)(uint8_t bn), void (*released)( uint8_t bn))
{
  buttons_init();
  vBUTTPressHandl = pressed;
  vBUTTReleaseHandl = released;
  return SUCCESS;
};

/****************************************************************
  Cancel button’s handlers. 
****************************************************************/
result_t buttons_close()
{
	appTimer_close(iButtonsPeriodicalTimer);
	vBUTTPressHandl = NULL;
	vBUTTReleaseHandl = NULL;
	return SUCCESS;
};

/****************************************************************
  Reads button_state of buttons.
  Returns:
    current buttons state in a binary way. 
    Bit 0 defines state of the button 1, bit 1 defines state of 
    the button 2.
****************************************************************/
uint8_t buttons_readState()
{
	return (~button_state) & (~((~(sizeof(button_state) - 1)) << MAX_BUTTONS_COUNT));
};

/****************************************************************
  Event about buttons poll interval expired
****************************************************************/
void vbuttons__timer__fire(void)
{
  uint8_t i, j, value; 
    j = 0;
    for (i = 0; i < MAX_BUTTONS_COUNT; i++)
    {
        gpio_getState( KEY0 + i, &value);
        j |= (value & 0x01) << i;
        if( (button_state & (1 << i)) ^ (j & (1 << i)) )
        {// "i" key has been toggled
          button_state &= ~(1 << i);
          button_state |= j & (1 << i);
          if( !(j & (1 << i) ) )
          {// key has been pressed            
            if( vBUTTPressHandl )
              vBUTTPressHandl(i + 1);
          }
          else
          {// key has been released
            if( vBUTTReleaseHandl )
              vBUTTReleaseHandl(i + 1);
          }
        }
    }// end for
};
// endof buttons.c
