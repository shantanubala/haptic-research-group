/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The access to sliders.
****************************************************************/
 
#include <gpio.h>
#include <tos.h>
#include <sliders.h>

#define SLIDER0 GPIO_3 
#define SLIDER1 GPIO_4 
#define SLIDER2 GPIO_5

/****************************************************************
  Reads sliders.
  Returns:
    state of 3 on­board DIP­switches.
****************************************************************/
uint8_t sliders_read()
{
  uint8_t i, result=0;
  uint8_t value;
  for( i=0 ; i<MAX_SLIDERS_COUNT ; i++)
  {
     gpio_setConfig(SLIDER0 + i, GPIO_INPUT_PULLUP_ON);
     gpio_getState(SLIDER0 + i, &value);
     gpio_setConfig(SLIDER0 + i, GPIO_INPUT_PULLUP_OFF);
     result |= value << i;
  }
  return result; 
}

// eof sliders.c
