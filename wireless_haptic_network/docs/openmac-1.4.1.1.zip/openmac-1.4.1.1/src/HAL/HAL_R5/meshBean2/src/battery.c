/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The measurement of battery voltage.
*****************************************************************/

#include <sensors.h>
#include <atomic.h>
#include <adc.h>
#include <battery.h>

// states 
typedef enum
{
  IDLE,           // idle
  DATA,           // performs request
}batteryStates_e;

batteryStates_e battery__state; // the state of component
uint16_t battery__data;         // contains sampled data

void (*battery__dataReady)(bool error, float data); // callback

/****************************************************************
  Inits the use of the battery sensor.
  Returns:
    SUCCESS - always
****************************************************************/
result_t battery__init() 
{       
  static bool flag = FALSE;
  if( flag == TRUE ) return SUCCESS;
  flag = TRUE;
  battery__state = IDLE;
  return SUCCESS;
}

/****************************************************************
  Opens the component to use.
  Returns: 
    SUCCESS - the component is ready to been use.
    FAIL - otherwise.
****************************************************************/
result_t battery__open()
{
  battery__init();
  if( battery__state == IDLE) return SUCCESS;
  return FAIL;
}

/****************************************************************
  Performs the test if the component have completed request.
  Returns:
    FAIL - the previous request is not completed.
    SUCCES - otherwise.
*****************************************************************/
result_t battery__close()
{
  if( battery__state == IDLE) return SUCCESS;
  return FAIL;
} 


/****************************************************************
 The task about the data request has been done.
****************************************************************/
void battery__postsamplingDone()
{
  ATOMIC_SECTION_ENTER
    battery__state = IDLE;  
    adc_close( ADC_BAT );
  ATOMIC_SECTION_LEAVE
  battery__dataReady(TRUE, ((float)battery__data * 1.25 * (1 + 2))/1024.0 );
}

/****************************************************************
 Notification about the request to the battery sensor 
 has been done.
****************************************************************/
void battery__samplingDone(uint16_t data)
{
  battery__data = data;
  TOS_post( battery__postsamplingDone );
}

/****************************************************************
  Gets data from battery sensor.
  Parameters:
    f - callback.
  Returns: 
    FAIL - if previous request has not been completed yet 
    SUCCESS -  other case.
****************************************************************/
result_t battery__getData( void (*f)(bool result, float data) )
{
  if( battery__state != IDLE ) 
  {
    return FAIL;
  }
  if( adc_open(ADC_BAT, battery__samplingDone) == FAIL)
  {
    return FAIL;
  }
  ATOMIC_SECTION_ENTER
    battery__state = DATA;  
  ATOMIC_SECTION_LEAVE
  battery__dataReady = f;
  if( adc_get( ADC_BAT ) == FAIL )
  {
    battery__state = IDLE;  
    return FAIL;
  }
  return SUCCESS;
}

// endof battery.c
