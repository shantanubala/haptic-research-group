/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#include <tos.h>

#ifndef SENSORS_H_
#define SENSORS_H_

#define SENSOR_LIGHT       1
#define SENSOR_TEMPERATURE 2
#define SENSOR_BATTERY     3
#define SENSOR_LED         4

/****************************************************************
  Inits id sensor.
  Parameters:
    id - sensor descriptor.
  Returns:
    FAIL - if there is hardware error or there is no requested sensor 
    SUCCESS - in other case.
****************************************************************/
result_t sensor_open(uint8_t id);

/****************************************************************
  Closes id sensor.
  Returns:
    FAIL - if there is hardware error, there is no requested sensor, 
           there is uncompleted getData request.
    SUCCESS  - in other case.
****************************************************************/
result_t sensor_close(uint8_t id);

/****************************************************************
  Gets data from id sensor.
  Parameters:
    dataReady - pointer to the sensor data handler.
    result - the result requested operation. TRUE - there is no error,
             FALSE - there is error.
    data - sensor data.
  Returns:
    FAIL - if there is no such sensor or previous request has not been 
           completed yet.
    SUCCESS - in other case.
****************************************************************/
result_t sensor_getData(uint8_t id, void (*dataReady)(bool error, float data));
#endif	/* SENSORS_H_ */

// eof Sensors.h

