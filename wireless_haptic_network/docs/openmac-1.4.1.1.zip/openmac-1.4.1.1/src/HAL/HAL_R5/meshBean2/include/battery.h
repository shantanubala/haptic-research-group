/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef BATTERY_SENSOR_H_
#define BATTERY_SENSOR_H_

/****************************************************************
  Opens the component to use.
  Returns: 
    SUCCESS - the component is ready to been use.
    FAIL - otherwise.
****************************************************************/
result_t battery__open();

/****************************************************************
  Performs the test if the component have completed request.
  Returns:
    FAIL - the previous request is not completed.
    SUCCES - otherwise.
*****************************************************************/
result_t battery__close();

/****************************************************************
  Gets data from battery sensor.
  Parameters:
    f – callback.
  Returns: 
    FAIL - if previous request has not been completed yet 
    SUCCESS -  other case.
****************************************************************/
result_t battery__getData( void (*f)(bool result, float data) );
#endif

// eof battery.h

