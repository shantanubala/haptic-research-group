/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The module for access to leds.
****************************************************************/

#include <leds.h>
#include <gpio.h>
#include <sensors.h>

#ifndef LED_ON 
#define LED_ON  1
#endif
#ifndef LED_OFF 
#define LED_OFF 0
#endif


/****************************************************************
  Inits LEDs control module.
****************************************************************/
void leds_init() 
{       
  static bool flag = FALSE;
  if( flag == TRUE ) return;
  flag = TRUE;
  gpio_setConfig(LED_RED, GPIO_OUTPUT);
  gpio_setConfig(LED_GREEN, GPIO_OUTPUT);
  gpio_setConfig(LED_YELLOW, GPIO_OUTPUT);
}

/****************************************************************
  Opens leds module to use.
  Returns: 
    SUCCESS - always.
****************************************************************/
result_t leds_open(void)
{
  leds_init();
  hpl__peripherial__on( SENSOR_LED ); 
  return SUCCESS;
}

/****************************************************************
  Closes leds module.
  Returns: 
    SUCCESS - always.
****************************************************************/
result_t leds_close(void)
{
  hpl__peripherial__off( SENSOR_LED ); 
  return SUCCESS;
}

/****************************************************************
  Turns on n­th LED.
  Parameters:
    id - number of led
****************************************************************/
void leds_on(uint8_t id)
{
  switch( id )
  {
    case LED_RED:
    case LED_GREEN:
    case LED_YELLOW:
        gpio_setState( id, LED_ON );
    break;
  }
}

/****************************************************************
  Turns off n­th LED.
    Parameters:
      id - number of led
****************************************************************/
void leds_off(uint8_t id)
{
  switch( id )
  {
    case LED_RED:
    case LED_GREEN:
    case LED_YELLOW:
        gpio_setState( id, LED_OFF );
    break;
  }
}

/****************************************************************
  Changes n­th LED state to opposite.
    Parameters:
      id - number of led
****************************************************************/
void leds_toggle(uint8_t id)
{
uint8_t value;
  switch( id )
  {
    case LED_RED:
    case LED_GREEN:
    case LED_YELLOW:
      gpio_getState( id, &value);
      if(value == LED_ON)
        leds_off( id );
      else
        leds_on( id );
    break;
  }
}
// eof leds.c
