/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef BUTTONS_H_
#define BUTTONS_H_
#include <tos.h>
#include <gpio.h>
#define MAX_BUTTONS_COUNT 2
#define SAMPLE_PERIOD 50  // Sample period, ms.
typedef void (*BUTTEventFunk)(uint8_t);

/****************************************************************
  Register handlers for button events, that will be called in 
  the non­interrupt context.  
  Paremeters:
    pressed – the handler to process pressing the button
    released ­ the handler to process releasing the button
    bn – button number. 
  Returns:
  SUCCESS - always.
****************************************************************/
result_t buttons_open(void (*pressed)(uint8_t bn), void (*released)( uint8_t bn));

/****************************************************************
  Reads state of buttoms.
  Returns:
    current buttons state in a binary way. 
    Bit 0 defines state of the button 1, bit 1 defines state of 
    the button 2.
****************************************************************/
uint8_t buttons_readState();

/****************************************************************
  Cancel button’s handlers. 
****************************************************************/
result_t buttons_close();

#endif	/* BUTTONS_H_ */
