/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The common interface to sensors.
****************************************************************/

#include <tos.h>
#include <sensors.h>
#include <tsl2550.h>
#include <lm73.h>
#include <battery.h>
#include <pwrctrl.h>

/****************************************************************
  Inits id sensor.
  Parameters:
    id - sensor descriptor.
  Returns:
    FAIL - if there is hardware error or there is no requested sensor 
    SUCCESS - in other case.
****************************************************************/
result_t sensor_open(uint8_t id)
{
    switch( id ) 
    {
    case SENSOR_LIGHT:
      if( tsl2550__open() == SUCCESS )
      {
        hpl__peripherial__on( id ); 
        return SUCCESS; 
      }
    break;

    case SENSOR_TEMPERATURE:
      if( lm73__open() == SUCCESS )
      {
        hpl__peripherial__on( id );
        return SUCCESS;
      }
    break;

    case SENSOR_BATTERY:
      if( battery__open() == SUCCESS )
      {
        hpl__peripherial__on( id );
        return SUCCESS;
      }
    break;

    default:{ return FAIL; }
  }
return FAIL;
}


/****************************************************************
  Closes id sensor.
  Returns:
    FAIL - if there is hardware error, there is no requested sensor, 
           there is uncompleted getData request.
    SUCCESS  - in other case.
****************************************************************/
result_t sensor_close(uint8_t id)
{ 
    switch( id ) 
    {
    case SENSOR_LIGHT:
      if( tsl2550__close() == SUCCESS )
      {
        hpl__peripherial__off( id ); 
        return SUCCESS; 
      }
    break;

    case SENSOR_TEMPERATURE:
      if( lm73__close() == SUCCESS )
      {
        hpl__peripherial__off( id );
        return SUCCESS;
      }
    break;

    case SENSOR_BATTERY:
      if( battery__close() == SUCCESS )
      {
        hpl__peripherial__off( id );
        return SUCCESS;
      }
    break;

    default:{ return FAIL; }
    }
return FAIL;
}

/****************************************************************
  Gets data from id sensor.
  Parameters:
    dataReady - pointer to the sensor data handler.
    result - the result requested operation. TRUE - there is no error,
             FALSE - there is error.
    data - sensor data.
  Returns:
    FAIL - if there is no such sensor or previous request has not been 
           completed yet.
    SUCCESS - in other case.
****************************************************************/
result_t sensor_getData(uint8_t id, void (*dataReady)(bool result, float data) )
{
  switch (id)
  {
    case SENSOR_LIGHT:
      return tsl2550__getData(dataReady);

    case SENSOR_TEMPERATURE:
      return lm73__getData(dataReady);

    case SENSOR_BATTERY:
      return battery__getData(dataReady);

    default:{ return FAIL; }
  }
}

// eof sensors.c
