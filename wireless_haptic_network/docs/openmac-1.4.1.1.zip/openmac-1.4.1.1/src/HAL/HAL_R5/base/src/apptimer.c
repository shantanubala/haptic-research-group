/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 

/*===============================================================
Implementation of application timer.
=================================================================*/
#include <apptimer.h>
#include <atomic.h>
#include <appclock.h>


uint32_t Timer__mState;         // Contains a bit mask of active timers
uint32_t Timer__mInterval;      // Contains a count out interval of the hardware timer.
int8_t Timer__queue_head;       // The queue index
int8_t Timer__queue_tail;       // The queue index
uint8_t Timer__queue_size;
uint8_t Timer__queue[NUM_TIMERS];
struct Timer__timer_s Timer__mTimerList[ NUM_TIMERS ]; // Array of the application timer descriptors.
bool Timer__initFlag = FALSE;

uint32_t systemTime = 0; // It is used  for to store the system time.

result_t Timer__Timer__fired(uint8_t);

/*===============================================================
Sets the interval.
Parameters:
  interval -  the value which has been counted out.
=================================================================*/
void appTimer_setInterval( uint32_t interval)
{
  Timer__mInterval = interval;
}

/*===============================================================
System time.
Returns:
  the system time in milliseconds.
=================================================================*/
uint32_t getSystemTime()
{
  return systemTime;
}

/*===============================================================
Removes the timer from queue.
=================================================================*/
uint8_t Timer__dequeue(void)
{
  if (Timer__queue_size == 0) 
  {
    return NUM_TIMERS;
  }
  if (Timer__queue_head == NUM_TIMERS - 1) 
  {
    Timer__queue_head = -1;
  }
  Timer__queue_head++;
  Timer__queue_size--;
  return Timer__queue[(uint8_t )Timer__queue_head];
}

/*===============================================================
The search of the expired timer.
=================================================================*/
inline void Timer__signalOneTimer(void)
{
  uint8_t itimer = Timer__dequeue();

  if (itimer < NUM_TIMERS) 
  {
    Timer__Timer__fired(itimer);
  }
}

/*===============================================================
Adds the timer to the queue.
=================================================================*/
static inline void Timer__enqueue(uint8_t value)
{
  if (Timer__queue_tail == NUM_TIMERS - 1) 
  {
    Timer__queue_tail = -1;
  }
  Timer__queue_tail++;
  Timer__queue_size++;
  Timer__queue[(uint8_t )Timer__queue_tail] = value;
}

/*===============================================================
The event of the appclock interrupt handler.
=================================================================*/
void appClock__Clock__HandleFire(void)
{
  uint8_t i;
  uint8_t val = 10;
  systemTime += Timer__mInterval;
  if(Timer__mState) 
  {
    for(i = 0; i < NUM_TIMERS; i++) 
    {
      if(Timer__mState & (0x1ul << i)) 
      {// the active timer
        if(Timer__mTimerList[i].ticksLeft > Timer__mInterval)
        {
          Timer__mTimerList[i].ticksLeft -= Timer__mInterval;
        }
        else
        {
          if(Timer__mTimerList[i].type == TIMER_REPEAT_MODE) 
	         {
            Timer__mTimerList[i].ticksLeft = Timer__mTimerList[i].ticks;
          }
          else 
          {
            Timer__mState &= ~(0x1ul << i);
          }
          Timer__enqueue(i);
          TOS_post(Timer__signalOneTimer);
        }
        if( Timer__mState ) 
        {// There is the active logic timers.
          if( (Timer__mState & (0x1ul << i)) && (Timer__mTimerList[i].ticksLeft < val) ) 
          {// There is a need to count out other interval.
             val = Timer__mTimerList[i].ticksLeft;
          }
        }
      }// end if active timer
    }
  }
  appClock__Clock__setInterval( Timer__mInterval = val );
}

/*===============================================================
Sends the event about expired the timer.
=================================================================*/
result_t Timer__Timer__fired(uint8_t id)
{
  unsigned int result;
  Timer__mTimerList[id].fired();
  return result;
}


/*===============================================================
Initializes apptimer control module.
=================================================================*/
void appTimer_init()
{
  if(!Timer__initFlag) 
  {
    Timer__initFlag = TRUE;
    Timer__mState = 0;
    Timer__queue_head = Timer__queue_tail = -1;
    Timer__queue_size = 0;
    Timer__mInterval = 10;
    appClock__Clock__setRate(Timer__mInterval);
  }
}

/*===============================================================
Registers the handler for the application timer event.
Parameters:
  fired – a pointer to a fired event handler.
Returns:
  Returns positive descriptor if the 
  registration is successful and negative value in other cases.
=================================================================*/
int appTimer_open(void (*fired)())
{
  int i = 0;
  appTimer_init();
  for(i = 0; i < NUM_TIMERS; i++)
  {
    if(Timer__mTimerList[i].fired == NULL)
    {
      Timer__mTimerList[i].fired = fired;
      return i;
    }
  }	
  return -1;
}

/*===============================================================
Cancels the handler that was associated with the id descriptor.
Parameters:
  id - the timer descriptor.
Returns:
  FAIL - there is no such descriptor.
  SUCCESS - in other cases.
=================================================================*/
result_t appTimer_close(int id)
{
  if ((uint16_t)id >= NUM_TIMERS)
  {
    return FAIL;
  }
  if(Timer__mTimerList[id].fired != NULL)
  {
    Timer__mTimerList[id].fired = NULL;
    return SUCCESS;
  }
  else
    return FAIL;
}

/*===============================================================
Starts the timer.
Parameters:
  id – descriptor.
  mode – application timer mode.
  delay – delay in milliseconds.
Returns:
  FAIL - there is no such descriptor.
  SUCCESS - in other cases.
=================================================================*/
result_t appTimer_start(int id, TimerMode_t mode, uint32_t delay)
{
  uint8_t diff;
  
  if((uint16_t)id >= NUM_TIMERS)
  {
    return FAIL;
  }
  if(mode > 1) 
  {
    return FAIL;
  }
  Timer__mTimerList[id].ticks = delay;
  Timer__mTimerList[id].type = mode;
    ATOMIC_SECTION_ENTER
      diff = appClock__Clock__readCounter();
      delay += diff;
      Timer__mTimerList[id].ticksLeft = delay;
      Timer__mState |= 0x1ul << id;
      if (delay < Timer__mInterval)
      {
        Timer__mInterval = delay;
	appClock__Clock__setInterval(Timer__mInterval);
      }
    ATOMIC_SECTION_LEAVE
  return SUCCESS;
}

/*===============================================================
Stops the application timer.
Parameters:
  id – descriptor
Returns:
  FAIL - there is no such descriptor.
  SUCCESS - in other cases.
=================================================================*/
result_t appTimer_stop(int id)
{
  if((uint16_t)id >= NUM_TIMERS) 
  {
    return FAIL;
  }
  if(Timer__mState & (0x1ul << id)) 
  {
    ATOMIC_SECTION_ENTER
      Timer__mState &= ~(0x1ul << id);
    ATOMIC_SECTION_LEAVE
    return SUCCESS;
  }
  return FAIL;
}

// eof apptimer.c
