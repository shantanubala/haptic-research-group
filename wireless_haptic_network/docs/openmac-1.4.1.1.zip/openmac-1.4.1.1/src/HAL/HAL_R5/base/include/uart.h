/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


#ifndef UART_H_
#define UART_H_

#include <tos.h>

#define USART_CHANNEL0 0
#define USART_CHANNEL1 1

#define UART_CTS_OFF 0
#define UART_CTS_ON 1

// USART states
typedef enum
{	
  USART_IDLE, // idle
  UART_BUSY,  // busy
  SPI_BUSY,   // busy
  SPI_FREE    // free
} USART_state_t;

extern USART_state_t USART_state[];

// clock rate of uart
typedef enum
{
  UART_BAUDRATE_1200 =  415, // 1200 baud rate
  UART_BAUDRATE_9600 =  51,  // 9600 baud rate
  UART_BAUDRATE_38400 = 12   // 38400 baud rate
} UARTBaudRate_t;

// uart data length
typedef enum
{
  UART_DATA5, // 5 bits data length
  UART_DATA6, // 6 bits data length
  UART_DATA7, // 7 bits data length
  UART_DATA8  // 8 bits data length
} UARTData_t;

// parity mode
typedef enum
{
  UART_PARITY_NONE = 0, // Non parity mode
  UART_PARITY_EVEN = 2, // Even parity mode
  UART_PARITY_ODD = 3   // Odd parity mode
} UARTParity_t;

// number of stop bits
typedef enum
{
  UART_STOPBITS1, // 1 stop bits mode
  UART_STOPBITS2  // 2 stop bits mode
} UARTStopBits_t;

// flow control mode
typedef struct
{
  bool ctsControl;  // CTS control is enabled
  bool rtsControl;  // RTS control is enabled
  bool dtrControl;  // DTR control is enabled
} UARTFlowControl_t;

// uart mode
typedef struct
{
  UARTBaudRate_t baudrate;  // UART baud rate
  UARTData_t data;          // UART data length
  UARTParity_t parity;      // UART parity mode. 
  UARTStopBits_t stopbits;  // UART stop bits number
  UARTFlowControl_t flowControl;
} UARTMode_t;

/*=============================================================
 Sets UART parameters
 Parameters:
   id    - channel number.
   param - UART parameters.
 Returns:
   FAIL    - if channel number is out of range or UART has been 
             already opened.
   SUCCESS - UART parameters are successfully stored.
===============================================================*/
result_t uart_setConfig(uint8_t id, const UARTMode_t *param);

/*=============================================================
 Gets UART parameters
 Parameters:
   id    - channel number.
   param - UART parameters.
 Returns:
   FAIL    - if channel number is out of range.
   SUCCESS - UART parameters are successfully passed.
===============================================================*/
result_t uart_getConfig(uint8_t id, UARTMode_t *param);

/*=============================================================
 Opens UART channel
 Parameters:
   id - channel number.
 Returns:
   FAIL    - if channel number is out of range or UART has been 
             already opened.
   SUCCESS - UART channel is ready.
===============================================================*/
result_t uart_open(uint8_t id);

/*=============================================================
 Closes UART channel
 Parameters:
   id - channel number.
 Returns:
   FAIL    - if channel number is out of range or UART has not 
             been opened yet.
   SUCCESS - UART channel has been closed.
===============================================================*/
result_t uart_close(uint8_t id);

/*=============================================================
 Puts data packet into UART buffer to transmit
 Parameters:
   id     - channel number.
   data   - start buffer pointer.
   length - data size.
 Returns:
   FAIL    - channel number is out of range
           - UART has no been opened yet
		   - data pointer is 0
		   - length is zero
		   - the UART buffer size is less than length.
   SUCCESS - otherwise.
===============================================================*/
result_t uart_put(uint8_t id, const uint8_t *data, uint8_t length);

/*=============================================================
 Checks the emptiness of transmitting buffer
 Parameters:
   id    - channel number.
   empty - emptiness flag.
 Returns:
   FAIL    - if channel number is out of range or UART has not 
             been opened yet.
   SUCCESS - otherwise.
===============================================================*/
result_t uart_isTxEmpty(uint8_t id, bool *empty);

/*=============================================================
 Reads received data from UART driver (Rx buffer) to buffer
 Parameters:
   id        - channel number.
   data      - start buffer pointer.
   length    - data size that user wants to read.
   actLength - actual data size has been read from driver.
 Returns:
   FAIL    - channel number is out of range
           - UART has no been opened yet
		   - data pointer is 0
		   - length is zero
   SUCCESS - otherwise.
===============================================================*/
result_t uart_get(uint8_t id, uint8_t *data, uint8_t length, uint8_t *actLength);

/*=============================================================
 Manipulates CTS signal
 Parameters:
   id  - channel number.
   cts - CTS signal state (UART_CTS_ON or UART_CTS_OFF).
 Returns:
   FAIL    - if channel number is out of range or UART has not 
             been opened yet.
   SUCCESS - otherwise.
===============================================================*/
result_t uart_cts(uint8_t id, bool cts);

#endif /* UART_H_ */
// eof uart.h
