/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 

#ifndef HPLI2CM_H_
#define HPLI2CM_H_
#include <avrhardware.h>
#include <tos.h>
#include <i2cpacket.h>

/*===============================================================
Inits TWI module. Setup teh speed of TWI.
Parameters:
  i2cMode - the speed of TWI.
Returns:
  FAIL - unsupported speed.
  SUCCESS - other case.
=================================================================*/
result_t i2c_init( const I2CMode_t* );

/*===============================================================
Directs TWI to send start condition.
Returns:
  SUCCESS - always.
=================================================================*/
result_t i2c_sendStart();

/*===============================================================
Directs TWI to send stop condition.
Returns:
  SUCCESS - always.
=================================================================*/
result_t i2c_sendEnd();

/*===============================================================
Begins to read an byte from TWI.
Parameters:
  ack - defines the need to send ACK after an byte was recieved.
Returns:
  FAIL -  the TWI is busy or the TWI improperly initialized.
  SUCCESS - other case.
=================================================================*/
result_t i2c_read(bool ack);

/*===============================================================
Begins the writing an byte to TWI.
Parameters:
  data - an byte for the sending.
Returns:
  FAIL -  the TWI is busy or the TWI improperly initialized.
  SUCCESS - other case.
=================================================================*/
result_t i2c_write(char data);

/*===============================================================
Notification that the stop condition was sent 
Returns:
  SUCCESS - always.
=================================================================*/
result_t i2c_sendEndDone(void);

/*===============================================================
Notification that the start condition was sent.
Returns:
  SUCCESS - always.
=================================================================*/
result_t i2c_sendStartDone(void);

/*===============================================================
Notification of a byte sucessfully written to the bus.
Parameters:
  result - contains result of previous operation.
Returns:
  FAIL - there is the state error.
  SUCCESS - other case.
=================================================================*/
result_t i2c_writeDone(bool);

/*===============================================================
Reads a byte off the TWI and adds it to the packet.
Returns:
  SUCCESS - always.
=================================================================*/
result_t i2c_readDone(char);

#endif /* HPLI2CM_H_*/
// eof i2c.h
