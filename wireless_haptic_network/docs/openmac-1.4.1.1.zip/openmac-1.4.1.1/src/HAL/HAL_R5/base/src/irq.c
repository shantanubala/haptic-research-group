/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


/*=============================================================
The implementation of IRQ interface.
===============================================================*/

#include <avr/interrupt.h>
#include <avr/io.h>
#include <irq.h>

#ifndef NUM_IRQ_LINES
#define NUM_IRQ_LINES 2
#endif

#ifndef FIRST_VALID_IRQ
#define FIRST_VALID_IRQ IRQ_6
#endif

typedef void (*IRQ_callback)(void);
IRQ_callback IRQ_callback_list[NUM_IRQ_LINES] = {[0 ... (NUM_IRQ_LINES - 1)] = NULL};

/*=============================================================
 Registers user's irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
   irqMode   - Interrupt sence control
   f         - user's interrupt handler
 Returns:
   FAIL    - if irqNumber is out of range or such interrupt has 
             been already registered.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_register(uint8_t irqNumber, irqMode_t irqMode, void (*f)(void))
{
  uint8_t irqOffsetNumber = irqNumber - FIRST_VALID_IRQ;
  // irqNumber is out of range
  if(irqOffsetNumber >= NUM_IRQ_LINES)
    return FAIL;
  // Such interrupt has been already register
  if(IRQ_callback_list[irqOffsetNumber] != NULL)
    return FAIL;
  // IRQ pin is input
  DDRE &= ~(1 << irqNumber);
  PORTE |= (1 << irqNumber);
  uint8_t ui8ShiftCount = (irqNumber - IRQ_4) << 1;
  // Clear previous settings of corresponding interrupt sense control
  EICRB &= ~(3 << ui8ShiftCount);
  // Setup corresponding interrupt sence control
  EICRB |= (irqMode & 0x03) << ui8ShiftCount;
  // Clear the INTn interrupt flag
  EIFR &= ~(1 << irqNumber);
  IRQ_callback_list[irqOffsetNumber] = f;
  return SUCCESS;
}

/*=============================================================
 Enables irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
 Returns:
   FAIL    - if irqNumber is out of range or has not been 
             registered yet.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_enable(uint8_t irqNumber)
{
  uint8_t irqOffsetNumber = irqNumber - FIRST_VALID_IRQ;
  // irqNumber is out of range
  if(irqOffsetNumber >= NUM_IRQ_LINES)
    return FAIL;
  // Interrupt has not been opened yet
  if(IRQ_callback_list[irqOffsetNumber] == NULL)
    return FAIL;
  // Enable external interrupt request
  EIMSK |= (1 << irqNumber);
  return SUCCESS;
}

/*=============================================================
 Disables irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
 Returns:
   FAIL    - if irqNumber is out of range or has not been 
             registered yet.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_disable(uint8_t irqNumber)
{
  uint8_t irqOffsetNumber = irqNumber - FIRST_VALID_IRQ;
  // irqNumber is out of range
  if(irqOffsetNumber >= NUM_IRQ_LINES)
    return FAIL;
  // Interrupt has not been opened yet
  if(IRQ_callback_list[irqOffsetNumber] == NULL)
    return FAIL;
  // Disable external interrupt request
  EIMSK &= ~(1 << irqNumber);
  return SUCCESS;
}

/*=============================================================
 Unregisters user's irqNumber interrupt
 Parameters:
   irqNumber - IRQ number
 Returns:
   FAIL    - if irqNumber is out of range or has not been 
             registered yet.
   SUCCESS - otherwise.
===============================================================*/
result_t irq_unregister(uint8_t irqNumber)
{
  uint8_t irqOffsetNumber = irqNumber - FIRST_VALID_IRQ;
  // irqNumber is out of range
  if(irqOffsetNumber >= NUM_IRQ_LINES)
    return FAIL;
  // Interrupt has not been opened yet
  if(IRQ_callback_list[irqOffsetNumber] == NULL)
    return FAIL;
  // Disable external interrupt request
  EIMSK &= ~(1 << irqNumber);
  IRQ_callback_list[irqOffsetNumber] = NULL;
  // IRQ pin is tri-state
  DDRE &= ~(1 << irqNumber);
  PORTE &= ~(1 << irqNumber);
  return SUCCESS;
}

/*=============================================================
 External interrupt 6 handler
===============================================================*/
SIGNAL(SIG_INTERRUPT6)
{
  IRQ_callback_list[IRQ_6 - FIRST_VALID_IRQ]();
}

/*=============================================================
 External interrupt 7 handler
===============================================================*/
SIGNAL(SIG_INTERRUPT7)
{
  IRQ_callback_list[IRQ_7 - FIRST_VALID_IRQ]();
}

// eof irq.c
