/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef W1_H_
#define W1_H_

#include <tos.h>

#define W1_ANY_FAMILY 0x00
#define DS2411 0x01

// w1 status
typedef enum
{
  W1_NO_DEVICE_STATUS, // There is no device on the bus 
  W1_SUCCESS_STATUS,   // At least one device is on the bus
  W1_INVALID_CRC       // Invalid CRC was read during the device search operation
} W1Status;

/*=============================================================
 Resets all devices connected to the bus. 
 Parameters:
 Returns:
   W1_SUCCESS_STATUS   - If device(s) was(were) detected.
   W1_NO_DEVICE_STATUS - If device(s) was(were) not detected.
===============================================================*/
W1Status w1_reset(void);

/*=============================================================
 Reads byte from the bus
 Returns:
   byte read from the bus
===============================================================*/
uint8_t w1_read (void);

/*=============================================================
 Writes byte to the bus
 Parameters:
   value - byte that should be written to the bus.
===============================================================*/
void w1_write (uint8_t value);

/*=============================================================
 1-Wire search procedure with search ROM command only
 Parameters:
   family   - 8-bit family code.
   data     - pointer of SRAM where are stored the 8 bytes ROM 
              codes returned by the devices.
   count    - number of devices wish to find.
   actCount - number of devices have been found.
 Returns:
   W1_SUCCESS_STATUS   - if at least one device has been found.
   W1_NO_DEVICE_STATUS - if there are no any devices presented 
                         on the bus with specified family code.
   W1_INVALID_CRC      - if during searching invalid CRC was read and 
                         no devices with specified family code was found.
===============================================================*/
W1Status w1_deviceSearch(uint8_t family,
                         uint8_t *data,
			 uint8_t count,
			 uint8_t *actCount);
/*=============================================================
 1-Wire search procedure with alarm search command only
 Parameters:
   family   - 8-bit family code.
   data     - pointer of SRAM where are stored the 8 bytes ROM 
              codes returned by the devices.
   count    - number of devices wish to find.
   actCount - number of devices have been found.
 Returns:
   W1_SUCCESS_STATUS   - if at least one device has been found.
   W1_NO_DEVICE_STATUS - if there are no any devices presented 
                         on the bus with specified family code.
   W1_INVALID_CRC      - if during searching invalid CRC was read and 
                         no devices with specified family code was found.
===============================================================*/
W1Status w1_alarmSearch(uint8_t family,
                        uint8_t *data,
			uint8_t count,
			uint8_t *actCount);

/*=============================================================
 Calculating 1-Wire 8-bit CRC
 Parameters:
   data   - data buffer pointer.
   length - data length.
 Returns:
   CRC value based on polynomial x^8 + x^5 + x^4 + 1
===============================================================*/
uint8_t w1_crc(uint8_t *data, uint8_t length);

#endif /* W1_H_ */
// eof w1.h
