/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 

#ifndef SPI_H_
#define SPI_H_

#include <tos.h>

// types of the clock mode
typedef enum
{  
  SPI_CLOCK_MODE0,  // leading edge – sample RX bit (rising), trailing edge – setup TX bit (falling).
  SPI_CLOCK_MODE1,  // leading edge – setup TX bit (rising),  trailing edge – sample RX bit (falling).
  SPI_CLOCK_MODE2,  // leading edge – sample RX bit (falling),  trailing edge – setup TX bit (rising).
  SPI_CLOCK_MODE3   // leading edge – setup TX bit (falling), trailing edge – sample RX bit (rising).
} SPIClockMode_t;

// clock rate
typedef enum
{
  SPI_CLOCK_RATE_125 = 125000,   // 125Kb/s
  SPI_CLOCK_RATE_250 = 250000,   // 250Kb/s
  SPI_CLOCK_RATE_500 = 500000,   // 500Kb/s
  SPI_CLOCK_RATE_1000 = 1000000, // 1Mb/s
  SPI_CLOCK_RATE_2000 = 2000000  // 2Mb/s
} SPIClockRate_t;

// Data order
typedef enum
{
  SPI_DATA_MSB_FIRST, // data with MSB first
  SPI_DATA_LSB_FIRST  // data with LSB first
} SPIDataOrder_t;

// SPI mode
typedef struct
{
  SPIClockMode_t clockMode; // SPI clock mode
  SPIClockRate_t clockRate; // SPI clock rate.
  SPIDataOrder_t dataOrder; // SPI data order.
} SPIMode_t;

/*=============================================================
 Opens USART as SPI channel
 Parameters:
   param - SPI parametrs (baud rate and frame format).
 Returns:
   FAIL    - if USART has been already opened (either as SPI or 
             UART).
   SUCCESS - SPI channel is ready.
===============================================================*/
result_t spi_open(const SPIMode_t *param);

/*=============================================================
 Closes USART as SPI channel
 Returns:
   FAIL    - if USART as SPI channel has not been opened yet.
   SUCCESS - USART as SPI channel has been closed.
===============================================================*/
result_t spi_close(void);

/*=============================================================
 Writes and read a set of bytes over SPI
 Parameters:
   data   - data buffer pointer.
   length - data buffer length.
 Returns:
   FAIL    - if USART as SPI channel has not been opened yet.
   SUCCESS - write and read operations are successfully done.
===============================================================*/
result_t spi_readWrite(uint8_t *data, uint8_t length);

#endif /* SPI_H_ */
