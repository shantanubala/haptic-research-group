/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 

#ifndef APPTIMERCLOCK_H
#define APPTIMERCLOCK_H
#include <tos.h>

struct Timer__timer_s 
{
  uint8_t type;        // type of timer
  uint32_t ticks;      // interval
  uint32_t ticksLeft;  // work interval
  void (*fired)(void); // callback
};

/*===============================================================
Stops the hardware application timer.
=================================================================*/
void appClock__Clock__stop();

/*===============================================================
 Starts the hardware application timer.
=================================================================*/
void appClock__Clock__start();

/*===============================================================
The event of the appclock interrupt handler.
=================================================================*/
void appClock__Clock__HandleFire();

/*===============================================================
Stops the hardware application timer.
=================================================================*/
void appClock__Clock__stopTimer();

/*===============================================================
 Starts the hardware application timer.
=================================================================*/
void appClock__Clock__startTimer();

/*===============================================================
Sets a counted out interval.
Parameters:
  value - contains the interval.
=================================================================*/
void appClock__Clock__setInterval(uint8_t value);

/*===============================================================
Returns a current value of the interval.
=================================================================*/
uint8_t appClock__Clock__readCounter(void);

/*===============================================================
Sets a count out interval. Perfoms init settings.
Parameters:
  interval - contains the interval.
=================================================================*/
result_t appClock__Clock__setRate(char interval);
#endif

// eof appclock.h
