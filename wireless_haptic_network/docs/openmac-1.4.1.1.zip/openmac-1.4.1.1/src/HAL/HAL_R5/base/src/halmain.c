/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


/*===============================================================
The main function of HAL.
=================================================================*/

#include <inttypes.h>
#include <tos.h>
#include <avrhardware.h> 
#include <realmain.h>
#include <hplat86rf230m.h>

/*===============================================================
Performs start up operations.
=================================================================*/
int HAL_main(void)
{
  HPLAT86RF230C__HPLAT86RF230__reset();
  hpl__init__freq();
  HPLInterrupt__Interrupt__enable();
return 0;
}
// eof halmain.c
