/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 

/*===============================================================
The module counts out requested interval of application timer.
=================================================================*/

#include <appclock.h>
#include <avrhardware.h>
#include <atomic.h>
#include <clkctrl.h>

uint8_t appClock__counter; // Stores the value which will be counted out
uint8_t appClock__cnt;     // Contains a counted out interval


/*===============================================================
Stops the hardware application timer.
=================================================================*/
void appClock__Clock__stop()
{
  TCCR4B = 0; // stop the timer
}

/*===============================================================
 Starts the hardware application timer.
=================================================================*/
void appClock__Clock__start()
{
  TCCR4B = (1 << WGM12) | (1 << CS11); // CTC, main clk / 8
}

/*===============================================================
Sets a interval.
Parameters:
  value - contains the interval.
=================================================================*/
void appClock__Clock__setInterval(uint8_t value)
{
  TIMSK4 &= ~(1 << OCIE4A); // Disable TC4 interrupt
  appClock__counter = value;
  appClock__cnt = 0;
  TIMSK4 |= (1 << OCIE4A); // Enable TC4 interrupt
}

/*===============================================================
Returns a current value of the interval.
=================================================================*/
uint8_t appClock__Clock__readCounter(void)
{
  return appClock__cnt;
}

/*===============================================================
Sets a count out interval. Performs init settings.
Parameters:
  interval - contains the interval.
Returns:
  SUCCESS - always.
=================================================================*/
result_t appClock__Clock__setRate(char interval)
{
  ATOMIC_SECTION_ENTER
    TCCR4B = 0; // stop the timer
    appClock__counter = interval;
    appClock__cnt = 0;
    TIMSK4 &= ~((1 <<  OCIE4A) | (1 << TOIE4)); // Disable TC4 interrupt
    OCR4A = ( F_CPU/1000ul ) / 8ul; // 1 millisecond timer interrupt interval.
    TCNT4 = 0;
    TCCR4B = (1 << WGM12) | (1 << CS11); // CTC, main clk / 8
    TIMSK4 |= (1 << OCIE4A); // Enable TC4 interrupt
  ATOMIC_SECTION_LEAVE
  return SUCCESS;
}

/*===============================================================
Interrupt handler
=================================================================*/
SIGNAL(SIG_OUTPUT_COMPARE4A)
{
  if(++appClock__cnt >= appClock__counter)
  {
    appClock__cnt = 0;
    appClock__Clock__HandleFire();
  }
}
// eof appclock.c
