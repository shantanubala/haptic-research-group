/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 

#ifndef HPLW1_H_
#define HPLW1_H_

#include <tos.h>

/*=============================================================
Reads bit from the bus
Returns:
  bit read from the bus.
===============================================================*/
uint8_t w1_read_bit (void);

/*=============================================================
Reads byte from the bus
Returns:
  byte read from the bus.
===============================================================*/
void w1_write_bit (uint8_t value);

#endif /* HPLW1_H_ */
