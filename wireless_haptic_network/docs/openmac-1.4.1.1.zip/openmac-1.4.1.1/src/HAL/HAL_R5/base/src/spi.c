/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


/*===============================================================
The implementation of USART in SPI mode.
=================================================================*/

#include <gpio.h>
#include <uart.h>
#include <clkctrl.h>
#include <spi.h>

#ifndef UDORD0
#define UDORD0 2
#endif

enum 
{
  SPI_START,
  SPI_STOP
};

/*=============================================================
 Opens USART as SPI channel
 Parameters:
   param - SPI parametrs (baud rate and frame format).
 Returns:
   FAIL    - if USART has been already opened (either as SPI or 
             UART).
   SUCCESS - SPI channel is ready.
===============================================================*/
result_t spi_open(const SPIMode_t *param)
{
  uint32_t clk_Hz;
  // USART 
  if (USART_state[USART_CHANNEL0] != USART_IDLE)
    return FAIL;
  UBRR0 = 0;
  // Set the XCKn port pin as output
  gpio_setConfig(GPIO_USART0_EXTCLK, GPIO_OUTPUT);
  // Set clock mode and data order
  UCSR0C = (param->dataOrder << UDORD0) | param->clockMode;
  // Set MSPI mode
  UCSR0C |= (1 << UMSEL01) | (1 << UMSEL00);
  // Enable receiver and transmitter
  UCSR0B = (1 << RXEN0) | (1 << TXEN0);
  // Set baud rate
  clk_Hz = (uint32_t) hpl__get__freq();
  UBRR0 = (uint16_t) (clk_Hz / (((uint32_t) param->clockRate) * 2)) - 1;
  USART_state[USART_CHANNEL0] = SPI_BUSY;
  return SUCCESS;
}

/*=============================================================
 Closes USART as SPI channel
 Returns:
   FAIL    - if USART as SPI channel has not been opened yet.
   SUCCESS - USART as SPI channel has been closed.
===============================================================*/
result_t spi_close(void)
{
  if (USART_state[USART_CHANNEL0] != SPI_BUSY)
    return FAIL;
  // Disable receiver and transmitter
  UCSR0B &= ~((1 << RXEN0) | (1 << TXEN0));
  // Set IO pins in tri-state
  gpio_setConfig(GPIO_USART0_RXD, GPIO_Z);
  gpio_setConfig(GPIO_USART0_TXD, GPIO_Z);
  gpio_setConfig(GPIO_USART0_EXTCLK, GPIO_Z);
  USART_state[USART_CHANNEL0] = USART_IDLE;
  return SUCCESS;
}

/*=============================================================
 Writes and read a set of bytes over SPI
 Parameters:
   data   - data buffer pointer.
   length - data buffer length.
 Returns:
   FAIL    - if USART as SPI channel has not been opened yet.
   SUCCESS - write and read operations are successfully done.
===============================================================*/
result_t spi_readWrite(uint8_t *data, uint8_t length)
{
  uint8_t i;
  static uint8_t SPI_state = SPI_STOP;

  if (USART_state[USART_CHANNEL0] != SPI_BUSY)
    return FAIL;
  if (SPI_state == SPI_START)
    return FAIL;
  SPI_state = SPI_START;
  for (i = 0; i < length; i++)
  {
    // Wait for empty transmit buffer
    while (!(UCSR0A & (1 << UDRE0)));
    // Send data
    UDR0 = *(data + i);
    // Wait for data to be received
    while (!(UCSR0A & (1 << RXC0)));
    // Receive data
    *(data + i) = UDR0;
  }
  SPI_state = SPI_STOP;
  return SUCCESS;
}

// eof spi.c
