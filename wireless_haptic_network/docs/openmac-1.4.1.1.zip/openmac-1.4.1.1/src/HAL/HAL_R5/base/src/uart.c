/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


/*===============================================================
The implementation of USART in UART mode.
=================================================================*/

#include <sched.h>
#include <gpio.h>
#include <clkctrl.h>
#include <uart.h>

#define UCSRnA 0
#define UCSRnB 1
#define UCSRnC 2
#define UBRRnL 4
#define UBRRnH 5
#define UDRn 6

// DTE is ready for data receiption from DCE
// if RTS state is UART_RTS_ON
#define UART_RTS_ON 0
// DTE is not ready for data receiption from DCE
// if RTS state is UART_RTS_OFF
#define UART_RTS_OFF 1

// UART channel count
#define NUM_USART_CHANNELS 2
// Speed modes count (with U2X and without one)
#define NUM_SPEED_MODES 2
// Double speed mode (with U2X)
#define DOUBLE_MODE 0
// Normal speed mode (without U2X)
#define NORMAL_MODE 1

// Transmitter buffer length
#define TX_BUFFER_SIZE 80
// Receiver buffer length
#define RX_BUFFER_SIZE 80
// Transmitter buffer threshold for switching on CTS
#define RX_BUFFER_CTS_ON_THRESHOLD 64
// Transmitter buffer threshold for switching off CTS
#define RX_BUFFER_CTS_OFF_THRESHOLD 16

// UART channel states
// USART_IDLE - UART channel is not opened
// USART_BUSY - UART channel is opened
USART_state_t USART_state[NUM_USART_CHANNELS] = \
  {[0 ... (NUM_USART_CHANNELS - 1)] = USART_IDLE};

// UART channel parameters
static UARTMode_t UARTMode[NUM_USART_CHANNELS];
// UART channel buffer parameters
static struct
{
  uint8_t TxBuff[TX_BUFFER_SIZE];
  uint8_t TxBuff_head;
  uint8_t TxBuff_tail;
  uint8_t TxBuff_length;
  uint8_t RxBuff[RX_BUFFER_SIZE];
  uint8_t RxBuff_head;
  uint8_t RxBuff_tail;
  uint8_t RxBuff_length;
} UARTBuff[NUM_USART_CHANNELS];

// Driver CTS state
static volatile bool user_cts_state;
// User CTS state
static volatile bool driver_cts_state;

/*=============================================================
 Sets driver CTS state
 Parameters:
   cts_state - CTS state that should be set according user CTS
               CTS state.
===============================================================*/
void set_driver_cts(bool cts_state)
{
  driver_cts_state = cts_state;
  if (UARTMode[USART_CHANNEL1].flowControl.ctsControl)
    gpio_setState(GPIO_UART_CTS, driver_cts_state || user_cts_state);
}

/*=============================================================
 Sets user CTS state
 Parameters:
   cts_state - CTS state that should be set according driver 
               CTS state.
===============================================================*/
void set_user_cts(bool cts_state)
{
  user_cts_state = cts_state;
  if (UARTMode[USART_CHANNEL1].flowControl.ctsControl)
    gpio_setState(GPIO_UART_CTS, driver_cts_state || user_cts_state);
}

/*=============================================================
 Sets correct CTS state wich depends on RTS state
===============================================================*/
uint8_t rts_affects_cts(void)
{
  uint8_t value = UART_RTS_ON;
  bool cts_state;
  if (UARTMode[USART_CHANNEL1].flowControl.rtsControl)
    gpio_getState(GPIO_UART_RTS, &value);
  if (value == UART_RTS_OFF) cts_state = UART_CTS_ON;
  else cts_state = UART_CTS_OFF;
  set_driver_cts(cts_state);
  return value;
}

/*=============================================================
 Sets UART parameters
 Parameters:
   id    - channel number.
   param - UART parameters.
 Returns:
   FAIL    - if channel number is out of range or UART has been 
             already opened.
   SUCCESS - UART parameters are successfully stored.
===============================================================*/
result_t uart_setConfig(uint8_t id, const UARTMode_t *param)
{
  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // UART has been already opened
  if (USART_state[id] != USART_IDLE) return FAIL;
  // Store UART configaration
  UARTMode[id] = *param;
  return SUCCESS;
}

/*=============================================================
 Gets UART parameters
 Parameters:
   id    - channel number.
   param - UART parameters.
 Returns:
   FAIL    - if channel number is out of range.
   SUCCESS - UART parameters are successfully passed.
===============================================================*/
result_t uart_getConfig(uint8_t id, UARTMode_t *param)
{
  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // Pass UART configaration
  *param = UARTMode[id];
  return SUCCESS;
}

/*=============================================================
 Opens UART channel
 Parameters:
   id - channel number.
 Returns:
   FAIL    - if channel number is out of range or UART has been 
             already opened.
   SUCCESS - UART channel is ready.
===============================================================*/
result_t uart_open(uint8_t id)
{
  uint8_t *membase;
  uint8_t i;

  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // UART has been already opened
  if (USART_state[id] != USART_IDLE) return FAIL;

  // Initialize buffer parameters
  UARTBuff[id].TxBuff_head = 0;
  UARTBuff[id].TxBuff_tail = 0;
  UARTBuff[id].TxBuff_length = 0;
  UARTBuff[id].RxBuff_head = 0;
  UARTBuff[id].RxBuff_tail = 0;
  UARTBuff[id].RxBuff_length = 0;

  // Select base address of USART registers setup 
  // for corresponding UART channel
  membase = (uint8_t *) (&UCSR0A + (id * 8));
  *(uint16_t*)(membase + UBRRnL) = UARTMode[id].baudrate;
  *(membase + UCSRnA) = (1 << U2X0);

  // Setup character size
  *(membase + UCSRnC) = (uint8_t) UARTMode[id].data << 1;
  // Setup parity mode
  *(membase + UCSRnC) |= (uint8_t) UARTMode[id].parity << 4;
  // Setup number of stop bits
  *(membase + UCSRnC) |= (uint8_t) UARTMode[id].stopbits << 3;
  // Enable hardware flow control
  if (id == USART_CHANNEL1)
  {
    // Enable data receiving
    if (UARTMode[USART_CHANNEL1].flowControl.ctsControl)
    {
	  gpio_setConfig(GPIO_UART_CTS, GPIO_OUTPUT);
	  user_cts_state = UART_CTS_OFF;
      gpio_setState(GPIO_UART_CTS, UART_CTS_OFF);
    }
    // RTS line will be listened
    if (UARTMode[USART_CHANNEL1].flowControl.rtsControl)
    {
      gpio_setConfig(GPIO_UART_RTS, GPIO_INPUT_PULLUP_ON);
    }
  }
  USART_state[id] = UART_BUSY;
  // Enable transmitter and receiver
  *(membase + UCSRnB) |= (uint8_t) ((1 << TXEN0) | (1 << RXEN0) | (1 << RXCIE0));
  return SUCCESS;
}

/*=============================================================
 Puts data packet into UART buffer to transmit
 Parameters:
   id     - channel number.
   data   - start buffer pointer.
   length - data size.
 Returns:
   FAIL    - channel number is out of range
           - UART has no been opened yet
		   - data pointer is 0
		   - length is zero
		   - the UART buffer size is less than length.
   SUCCESS - otherwise.
===============================================================*/
result_t uart_put(uint8_t id, const uint8_t *data, uint8_t length)
{
  uint8_t *membase;
  uint8_t i;
  uint8_t value = UART_RTS_ON;

  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // UART has not been opened yet
  if (USART_state[id] != UART_BUSY) return FAIL;
  // Data pointer is 0
  if (data == NULL) return FAIL;
  // length is 0
  if (length == 0) return FAIL;

  // UART buffer size is less than length
  if (length > (TX_BUFFER_SIZE - UARTBuff[id].TxBuff_length)) 
  {
    return FAIL;
  }
  
  membase = (uint8_t *) (&UCSR0A + (id * 8));
  // Disable interrupt on the UDREn flag
  *(membase + UCSRnB) &= ~(1 << UDRIE0);
  for (i = 0; i < length; i++)
  {
    UARTBuff[id].TxBuff[UARTBuff[id].TxBuff_head] = *(data + i);
	UARTBuff[id].TxBuff_head++;
	// Loopback
	if (UARTBuff[id].TxBuff_head == TX_BUFFER_SIZE)
	  UARTBuff[id].TxBuff_head = 0;
  }
  UARTBuff[id].TxBuff_length += length;
  if (id == USART_CHANNEL1) value = rts_affects_cts();
  // Enable interrupt on the UDREn flag (start transmission)
  if (value == UART_RTS_ON) *(membase + UCSRnB) |= (1 << UDRIE0);
  return SUCCESS;
}

/*=============================================================
 Reads received data from UART driver (Rx buffer) to buffer
 Parameters:
   id        - channel number.
   data      - start buffer pointer.
   length    - data size that user wants to read.
   actLength - actual data size has been read from driver.
 Returns:
   FAIL    - channel number is out of range
           - UART has no been opened yet
		   - data pointer is 0
		   - length is zero
   SUCCESS - otherwise.
===============================================================*/
result_t uart_get(uint8_t id, uint8_t *data, uint8_t length, uint8_t *actLength)
{
  uint8_t *membase;
  uint8_t i;

  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // UART has not been opened yet
  if (USART_state[id] != UART_BUSY) return FAIL;
  // Data pointer is 0
  if (data == NULL) return FAIL;
  // length is 0
  if (length == 0) return FAIL;

  membase = (uint8_t *) (&UCSR0A + (id * 8));
  // Disable interrupt on the RXCn flag
  *(membase + UCSRnB) &= ~(1 << RXCIE0);
  // Read data from receiver buffer
  if (length > UARTBuff[id].RxBuff_length) length = UARTBuff[id].RxBuff_length;
  for (i = 0; i < length; i++)
  {
    *(data + i) = UARTBuff[id].RxBuff[UARTBuff[id].RxBuff_tail];
	// Loopback
    UARTBuff[id].RxBuff_tail++;
	if (UARTBuff[id].RxBuff_tail == RX_BUFFER_SIZE)
	  UARTBuff[id].RxBuff_tail = 0;
  }
  UARTBuff[id].RxBuff_length -= length;
  *actLength = length;
  // Hardware flow control
  if (id == USART_CHANNEL1)
    if (UARTBuff[USART_CHANNEL1].RxBuff_length <= RX_BUFFER_CTS_OFF_THRESHOLD)
	  rts_affects_cts();
  // Enable interrupt on the RXCn flag
  *(membase + UCSRnB) |= (1 << RXCIE0);
  return SUCCESS;
}

/*=============================================================
 Checks the emptiness of transmitting buffer
 Parameters:
   id    - channel number.
   empty - emptiness flag.
 Returns:
   FAIL    - if channel number is out of range or UART has not 
             been opened yet.
   SUCCESS - otherwise.
===============================================================*/
result_t uart_isTxEmpty(uint8_t id, bool *empty)
{
  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // UART has not been opened yet
  if (USART_state[id] != UART_BUSY) return FAIL;
  *empty = (UARTBuff[id].TxBuff_length == 0);
  return SUCCESS;
}

/*=============================================================
 Manipulates CTS signal
 Parameters:
   id  - channel number.
   cts - CTS signal state (UART_CTS_ON or UART_CTS_OFF).
 Returns:
   FAIL    - if channel number is out of range or UART has not 
             been opened yet.
   SUCCESS - otherwise.
===============================================================*/
result_t uart_cts(uint8_t id, bool cts)
{
  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // UART has not been opened yet
  if (USART_state[id] != UART_BUSY) return FAIL;
  if (id == USART_CHANNEL1) set_user_cts(cts);
  return SUCCESS;
}

/*=============================================================
 Closes UART channel
 Parameters:
   id - channel number.
 Returns:
   FAIL    - if channel number is out of range or UART has not 
             been opened yet.
   SUCCESS - UART channel has been closed.
===============================================================*/
result_t uart_close(uint8_t id)
{
  uint8_t *membase;

  // UART channel is out of range
  if (id >= NUM_USART_CHANNELS) return FAIL;
  // UART has not been opened yet
  if (USART_state[id] != UART_BUSY) return FAIL;
  
  membase = (uint8_t *) (&UCSR0A + (id * 8));
  *(membase + UCSRnB) = 0x00;
  *(membase + UCSRnA) = 0x00;
  switch (id)
  {
    case USART_CHANNEL0:
	  gpio_setConfig(GPIO_USART0_RXD, GPIO_Z);
	  gpio_setConfig(GPIO_USART0_TXD, GPIO_Z);
	  break;
    case USART_CHANNEL1:
	  gpio_setConfig(GPIO_UART_RXD, GPIO_Z);
	  gpio_setConfig(GPIO_UART_TXD, GPIO_Z);
	  if (UARTMode[USART_CHANNEL1].flowControl.ctsControl)
	    gpio_setConfig(GPIO_UART_CTS, GPIO_Z);
      if (UARTMode[USART_CHANNEL1].flowControl.rtsControl)
        gpio_setConfig(GPIO_UART_RTS, GPIO_Z);
      break;
  }
  USART_state[id] = USART_IDLE;
  return SUCCESS;
}

/*=============================================================
 Resumes data transmission for first UART channel number when
 RTS has been switched on
===============================================================*/
void uart1_resume(void)
{
  uint8_t value;
  // Define RTS state
  gpio_getState(GPIO_UART_RTS, &value);
  if (value == UART_RTS_OFF) TOS_post(uart1_resume);
  // Resume transmission
  else
  {
    if (UARTMode[USART_CHANNEL1].flowControl.ctsControl)
	  set_driver_cts(UART_CTS_OFF);
    UCSR1B |= (1 << UDRIE1);
  }
}

/*=============================================================
 Interrupt on UDRE0 (USART0 data register empty) flag handler
===============================================================*/
SIGNAL(SIG_USART0_DATA)
{
  // Stop transmission if the transiver buffer is empty
  if (UARTBuff[USART_CHANNEL0].TxBuff_length == 0)
  {
    UCSR0B &= ~(1 << UDRIE0);
	return;
  }
  // Sent data
  UDR0 = UARTBuff[USART_CHANNEL0].TxBuff[UARTBuff[USART_CHANNEL0].TxBuff_tail];
  UARTBuff[USART_CHANNEL0].TxBuff_length--;
  UARTBuff[USART_CHANNEL0].TxBuff_tail++;
  // Loopback
  if (UARTBuff[USART_CHANNEL0].TxBuff_tail == TX_BUFFER_SIZE)
    UARTBuff[USART_CHANNEL0].TxBuff_tail = 0;
}

/*=============================================================
 Interrupt on UDRE1 (USART1 data register empty) flag handler
===============================================================*/
SIGNAL(SIG_USART1_DATA)
{
  // Stop transmission if the transiver buffer is empty
  if (UARTBuff[USART_CHANNEL1].TxBuff_length == 0)
  {
    UCSR1B &= ~(1 << UDRIE1);
	return;
  }
  // Check RTS line
  if (UARTMode[USART_CHANNEL1].flowControl.rtsControl)
  {
    uint8_t value;
    gpio_getState(GPIO_UART_RTS, &value);
	// Stop transmission
	if (value == UART_RTS_OFF) 
	{
	  UCSR1B &= ~(1 << UDRIE1);
	  if (UARTMode[USART_CHANNEL1].flowControl.ctsControl)
	    set_driver_cts(UART_CTS_ON);
	  TOS_post(uart1_resume);
	  return;
    }
  }
  // Sent data
  UDR1 = UARTBuff[USART_CHANNEL1].TxBuff[UARTBuff[USART_CHANNEL1].TxBuff_tail];
  UARTBuff[USART_CHANNEL1].TxBuff_length--;
  UARTBuff[USART_CHANNEL1].TxBuff_tail++;
  // Loopback
  if (UARTBuff[USART_CHANNEL1].TxBuff_tail == TX_BUFFER_SIZE)
    UARTBuff[USART_CHANNEL1].TxBuff_tail = 0;
}

/*=============================================================
 Interrupt on RXC0 (USART0 receive complete) flag handler
===============================================================*/
SIGNAL(SIG_USART0_RECV)
{
  uint8_t data_status;
  uint8_t data;

  // It's important to read USRnA register first 
  // before reading UDRn register (otherwise UCSRnA flags will be cleared)
  data_status = UCSR0A;
  data = UDR0;
  // There is some error in received data
  if (data_status & ((1 << FE0) | (1 << DOR0) | (1 << UPE0))) 
    return;
  // There is no free space in receiver buffer for storing data
  if (UARTBuff[USART_CHANNEL0].RxBuff_length == RX_BUFFER_SIZE)
  {
    UCSR0B &= ~(1 << RXCIE0);
    return;
  }
  // Store data to receiver buffer
  UARTBuff[USART_CHANNEL0].RxBuff[UARTBuff[USART_CHANNEL0].RxBuff_head] = data;
  UARTBuff[USART_CHANNEL0].RxBuff_head++;
  // Loopback
  if (UARTBuff[USART_CHANNEL0].RxBuff_head == RX_BUFFER_SIZE)
    UARTBuff[USART_CHANNEL0].RxBuff_head = 0;
  UARTBuff[USART_CHANNEL0].RxBuff_length++;
}

/*=============================================================
 Interrupt on RXC1 (USART1 receive complete) flag handler
===============================================================*/
SIGNAL(SIG_USART1_RECV)
{
  uint8_t data_status;
  uint8_t data;

  // It's important to read USRnA register first 
  // before reading UDRn register (otherwise UCSRnA flags will be cleared)
  data_status = UCSR1A;
  data = UDR1;
  // There is some error in received data
  if (data_status & ((1 << FE1) | (1 << DOR1) | (1 << UPE1))) 
    return;
  // There is no free space in receiver buffer for storing data
  if (UARTBuff[USART_CHANNEL1].RxBuff_length == RX_BUFFER_SIZE)
  {
    UCSR1B &= ~(1 << RXCIE1);
    return;
  }
  // Store data to receiver buffer
  UARTBuff[USART_CHANNEL1].RxBuff[UARTBuff[USART_CHANNEL1].RxBuff_head] = data;
  UARTBuff[USART_CHANNEL1].RxBuff_head++;
  // Loopback
  if (UARTBuff[USART_CHANNEL1].RxBuff_head == RX_BUFFER_SIZE)
    UARTBuff[USART_CHANNEL1].RxBuff_head = 0;
  // If receiver buffer is more or equal than 80% of RX_BUFFER_SIZE
  // and hardware flow control is enable CTS signal will be switched on
  UARTBuff[USART_CHANNEL1].RxBuff_length++;
  if (UARTMode[USART_CHANNEL1].flowControl.ctsControl)
    if (UARTBuff[USART_CHANNEL1].RxBuff_length >= RX_BUFFER_CTS_ON_THRESHOLD)
	  set_driver_cts(UART_CTS_ON);
}
// eof uart.c
