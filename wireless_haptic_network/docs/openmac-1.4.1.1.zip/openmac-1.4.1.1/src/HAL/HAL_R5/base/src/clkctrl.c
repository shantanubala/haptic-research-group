/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


/*===============================================================
The main clock control.
=================================================================*/

#include <clkctrl.h>
#include <avrhardware.h>
#include <hardware.h>
#include <tos.h>

/*===============================================================
Inits system clock.
=================================================================*/
inline void hpl__init__freq()
{
#ifdef HAL_RC_OSCILLATOR
#include <calibration.h>

  CLKPR = 1 << CLKPCE;
  CLKPR = 1 << CLKPS0;
  calibrateInternalRc();
#else
#include <at86rf230.h>
#include <hplspi.h>
uint8_t buffer[1];
    buffer[0] = 0;
    (*((RegTrxCtrl0 *)buffer)).pad_io = AT86RF230_PAD_IO_2MA;
    (*((RegTrxCtrl0 *)buffer)).pad_io_clkm = AT86RF230_PAD_IO_CLK_4MA;
    (*((RegTrxCtrl0 *)buffer)).clkm_sha_sel = AT86RF230_CLKM_SHA_SEL_DISABLE;
    (*((RegTrxCtrl0 *)buffer)).clkm_ctrl = AT86RF230_CLK_CTRL_4MHZ;
    HPLSPIM__HPLSPI__clrCS();    
      HPLSPIM__HPLSPI__write( (AT86RF230_TRX_CTRL_0_REG & AT86RF230_RADDRM) | AT86RF230_CMD_RW );
      HPLSPIM__HPLSPI__write( buffer[0] );
    HPLSPIM__HPLSPI__setCS();
#endif
}

/*===============================================================
System clock.
Returns:
  system clock in Hz.
=================================================================*/
inline uint32_t hpl__get__freq()
{
  return F_CPU;
}
// eof clkctrl.c
