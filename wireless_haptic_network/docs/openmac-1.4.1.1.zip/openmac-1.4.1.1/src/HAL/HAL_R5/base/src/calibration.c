/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


#include <tos.h>
#include <avrhardware.h> 
#include <hplat86rf230m.h>

#define INTERNAL_CLOCK 4000000

#ifndef RTC_CALIBRATION

#define EXTERNAL_TICKS 100*4
#define CYCLE_LENGTH 10
#define REFERENCE_CLOCK 1000000
#define REFERENCE_COUNT (INTERNAL_CLOCK * EXTERNAL_TICKS) / ( REFERENCE_CLOCK * CYCLE_LENGTH )
uint16_t measurement(void)
{
uint16_t cnt = 0;
  TCCR3B = 0; // stop the timer
  TCNT3 = 0;
  TCCR3B = (1 << CS30) | (1 << CS31) | (1 << CS32); // external clock source on T3 pin. Rising edge.
  do{                                                          
    cnt++;                                                     
  } while (TCNT3 < EXTERNAL_TICKS);
  return cnt;                           
}

void measurement_clear()
{
  TCCR3B = 0; // Stops the timer
  TIFR3  |= (1 << ICF3) | (1 << OCF3A) | (1 << OCF3B) | (1 << OCF3C) | (1 << TOV3); // Clears interrupt flags
}
#else

#define EXTERNAL_TICKS 2*4
#define CYCLE_LENGTH 7
#define REFERENCE_CLOCK 32768
#define REFERENCE_COUNT (INTERNAL_CLOCK * EXTERNAL_TICKS) / ( REFERENCE_CLOCK * CYCLE_LENGTH )
uint16_t measurement(void)
{
uint16_t cnt = 0;
  ASSR |= (1 << AS2);
  TCCR2B = 1 << CS20; 
  TCNT2 = 0;
  while ( ASSR & 0x1B);
  do{
    cnt++;
  } while (TCNT2 < EXTERNAL_TICKS);
  return cnt;                       
}

void measurement_clear()
{
  TCCR2B = 0; // Stops the timer
  TIFR2 |= (1 << OCF2A) | (1 << OCF2B) | (1 << TOV2); // Clears interrupt flags
}
#endif
void calibrateInternalRc(void)
{
  uint16_t count;
  uint8_t cycles = 0x80;
  do
  {
    count = measurement();
    if (count > REFERENCE_COUNT)
      OSCCAL--;                  
    if (count < REFERENCE_COUNT)
      OSCCAL++;
    if (count == REFERENCE_COUNT)
    { 
      measurement_clear();
      return;     
    }
  } while(--cycles); 
  measurement_clear();
}
