/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 
 
#ifndef I2CPACKETM_H
#define I2CPACKETM_H

typedef enum
{
  I2C_CLOCK_RATE_250 = 0, // 250 Kb/s clock rate
  I2C_CLOCK_RATE_125 = 8, // 125 Kb/s clock rate
  I2C_CLOCK_RATE_62  = 30 // 62.5 Kb/s clock rate
} I2CClockRate_t;

// TWI mode
typedef struct 
{
  I2CClockRate_t clockrate; // clock rate
}I2CMode_t;

/*===============================================================
Opens resource.
Parameters:
  i2cMode - mode.
Returns:
  FAIL - resource has been opened or unsupported mode.
  SUCCESS - other case.
=================================================================*/
result_t i2cpacket_open( const I2CMode_t *i2cMode );

/*===============================================================
Closes resource. 
Returns:
  FAIL - resource has not been opened.
  SUCCESS - other case.
=================================================================*/
result_t i2cpacket_close();

/*===============================================================
Writes a series of bytes out to the TWI bus 
Parameters:
  in_length      - number of bytes to be written to the bus
  in_data        - pointer to the data
  i2cPacket_done - callback
Returns:
  SUCCESS - the bus is free and the request is accepted.
  FAIL - other case.
=================================================================*/
result_t i2cpacket_write(uint8_t id, 
                         uint8_t in_length, 
                         const uint8_t* in_data, 
                         void (*f)(bool result));

/*===============================================================
Reads a series of bytes out to the TWI bus.
Parameters:
  in_length - number of bytes to be read from the bus.
  in_data   - the pointer to data buffer.
Returns:
  SUCCESS - the bus is free and the request is accepted.
  FAIL - other case.
=================================================================*/
result_t i2cpacket_read(uint8_t id, 
                        uint8_t in_length, 
                        uint8_t *data, 
                        void (*f)(bool result));

#endif
// eof i2cpacket.h
