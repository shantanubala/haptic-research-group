/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#include <avrhardware.h>
#include <tos.h>
#include <avr/wdt.h>

#ifndef WDTCTRL_H
#define WDTCTRL_H

// an interval before WDT will expire
enum
{
  WD_INTERVAL_16 = 0, // 16 ms
  WD_INTERVAL_32,     // 32 ms
  WD_INTERVAL_64,     // 64 ms
  WD_INTERVAL_125,    // 125 ms
  WD_INTERVAL_250,    // 250 ms
  WD_INTERVAL_500,    // 500 ms
  WD_INTERVAL_1000,   // 1 second
  WD_INTERVAL_2000,   // 2 seconds
  WD_INTERVAL_4000,   // 4 seconds
  WD_INTERVAL_8000    // 8 seconds
};

// starts wdt with x interval
#define wdt_start(x) wdt_enable(x)
// stops wdt
#define wdt_stop wdt_disable

#endif

// eof wdtctrl.h
