/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/*===============================================================
The implementation of some TOS functions.
=================================================================*/

#include <avrhardware.h>
#include <hardware.h>
#include <stdio.h>

/*===============================================================
Delay.
=================================================================*/
void TOSH_wait()
{
  asm volatile("nop");
  asm volatile("nop");
}

/*===============================================================
Idle mode.
=================================================================*/
void TOSH_sleep()
{
  SMCR = 0x1;
  asm volatile ("sleep");
  SMCR = 0;
}

/*===============================================================
Atomic statement runtime support.
=================================================================*/
inline __nesc_atomic_t __nesc_atomic_start(void)
{
  __nesc_atomic_t result = SREG;
  cli();
  return result;
}

/*===============================================================
Atomic statement runtime support.
=================================================================*/
inline void __nesc_atomic_end(__nesc_atomic_t oldSreg)
{
  SREG = oldSreg;
}


#warning "htole_u16"

/**************************************************
 * Endian-dependent byte swapping functions
 *************************************************/
// Host to Low-endian
inline uint16_t htole_u16(uint16_t fromU16) { return fromU16; }
inline uint32_t htole_u32(uint32_t fromU32) { return fromU32; }
inline uint64_t htole_u64(uint64_t fromU64) { return fromU64; }
// Low-endian to Host
inline uint16_t letoh_u16(uint16_t fromU16) { return fromU16; }
inline uint32_t letoh_u32(uint32_t fromU32) { return fromU32; } 
inline uint64_t letoh_u64(uint64_t fromU64) { return fromU64; } 

// eof tos.c
