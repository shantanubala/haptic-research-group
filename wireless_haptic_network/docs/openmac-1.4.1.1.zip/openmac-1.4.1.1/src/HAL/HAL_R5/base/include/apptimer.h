/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 

#ifndef APPTIMER_H_
#define APPTIMER_H_

#include <tos.h>
#include <appclock.h>

#ifndef APP_NUM_TIMERS 
#define APP_NUM_TIMERS 0 // the number of user timers
#endif

#define NUM_TIMERS (APP_NUM_TIMERS + 12) // total number of the application timers

typedef enum {
    TIMER_REPEAT_MODE = 0,
    TIMER_ONE_SHOT_MODE = 1,
}TimerMode_t;

/*===============================================================
Sets the interval.
Parameters:
  interval -  the value which has been counted out.
=================================================================*/
void appTimer_setInterval( uint32_t interval);

/*===============================================================
System time.
Returns:
  the system time in milliseconds.
=================================================================*/
uint32_t getSystemTime();

/*===============================================================
Registers the handler for the application timer event.
Parameters:
  fired – a pointer to a fired event handler.
Returns:
  Returns positive descriptor if the 
  registration is successful and negative value in other cases.
=================================================================*/
int appTimer_open(void (*fired)());

/*===============================================================
Cancels the handler that was associated with the id descriptor.
Parameters:
  id - the timer descriptor.
Returns:
  FAIL - there is no such descriptor.
  SUCCESS - in other cases.
=================================================================*/
result_t appTimer_close(int id);

/*===============================================================
Starts the timer.
Parameters:
  id – descriptor.
  mode – application timer mode.
  delay – delay in milliseconds.
Returns:
  FAIL - there is no such descriptor.
  SUCCESS - in other cases.
=================================================================*/
result_t appTimer_start(int id, TimerMode_t mode, uint32_t interval);

/*===============================================================
Stops the application timer.
Parameters:
  id – descriptor
Returns:
  FAIL - there is no such descriptor.
  SUCCESS - in other cases.
=================================================================*/
result_t appTimer_stop(int id);

#endif /* APPTIMER_H_ */
