/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The implementation of SPI module.
****************************************************************/

#include <hplspi.h>
#include <atomic.h>
#include <avr/interrupt.h>
#include <avrhardware.h>
#include <hardware.h>
#include <tos.h>

/****************************************************************
  Performs initialization of SPI interface.
****************************************************************/
void HPLSPIM__HPLSPI__init()
{
  TOSH_MAKE_SPI_MISO_INPUT();
  TOSH_MAKE_SPI_SCLK_OUTPUT();
  TOSH_MAKE_SPI_MOSI_OUTPUT();
  TOSH_MAKE_SPI_CSN_OUTPUT();
  SPCR = ((1 << SPE) | (1 << MSTR)); // SPI enable, master mode.
  SPSR = (1 << SPI2X); // rate = fosc/2
}

/****************************************************************
  Deselects a slave device.
****************************************************************/
void HPLSPIM__HPLSPI__setCS()
{
  TOSH_SET_SPI_CSN_PIN();
}

/****************************************************************
  Selects a slave device.
****************************************************************/
void HPLSPIM__HPLSPI__clrCS()
{
  TOSH_CLR_SPI_CSN_PIN();
}

/****************************************************************
  Writes a byte to SPI. 
    Writes a byte. Reads a byte from a slave.
  Returns:
    a delivered byte.
****************************************************************/
uint8_t HPLSPIM__HPLSPI__write(uint8_t value)
{
  SPDR = value; // Write data.
  while( !(SPSR&(1 << SPIF)) );
  return SPDR;
}

/****************************************************************
  Writes a block of bytes to SPI. 
  Params: value - pointer to the data to write. value[0] - block's
    length.
  Returns: void
****************************************************************/
void HPLSPIM__HPLSPI__writeBlock(uint8_t* value)
{
  uint8_t i;

  for(i = 0; i < value[0] - 1; i++)
  {// Without 2 bytes of CRC but with one byte of the length field.
    SPDR = value[i]; // Write data.
    while( !(SPSR&(1 << SPIF)) );
  }
}

/****************************************************************
  Reads out a block of bytes from SPI. 
  Params: value - pointer to the incomminf data's buffer.
          frameLength - number of bytes to read.
  Returns: void
****************************************************************/
void HPLSPIM__HPLSPI__readBlock(uint8_t* value, uint8_t frameLength)
{
  uint8_t i;

  for(i = 0; i < frameLength; i++)
  {
    SPDR = 0x55; // Just something.
    while( !(SPSR&(1 << SPIF)) );
    value[i] = SPDR; // Write data.
  }
}

// eof hplspi.c
