/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/*===============================================================
Implementation of the EEPROM module.
=================================================================*/

#include <tos.h>
#include <eeprom.h>
#include <atomic.h>

enum // EEPROM states
{
  EEPROM_IDLE_STATE = 10,
  EEPROM_WRITE_STATE,
  EEPROM_READ_STATE,
} EEPROM__state;
  
enum // EEPROM substates
{
  EEPROM_IDLE_SUBSTATE = 0, // idle
  EEPROM_NOT_LAST_BYTE,     // one more byte (not last) need to be processed
  EEPROM_LAST_BYTE,         // last byte need to be processed
} EEPROM__subState;

  EEPROMParams_t *EEPROM__param;   // pointer to parameter
  void (*EEPROM__operationDone)(); // callback

/*===============================================================
  StdControl interface.
=================================================================*/
result_t eeprom_init()
{
  EEPROM__state = EEPROM_IDLE_STATE;
  EEPROM__subState = EEPROM_IDLE_SUBSTATE;
  return SUCCESS;
}
  
/*===============================================================
  The task signals that the data block has been written.
=================================================================*/
void EEPROM__signalWriteDone()
{
  EEPROM__param->status = EEPROM_SUCCESS_STATUS;
  EEPROM__operationDone();
}

/*===============================================================
  The task signals that the data block has been read.
=================================================================*/
void EEPROM__signalReadDone()
{
  EEPROM__param->status = EEPROM_SUCCESS_STATUS;
  EEPROM__operationDone();
}

/*===============================================================
  Reads bytes from the EEPROM.
=================================================================*/
void EEPROM_read_byte()
{
  while( EECR & (1 << EEPE) ); // wait for complition of previous write
  for(; EEPROM__param->length > 0; EEPROM__param->length--)
  {
    EEARH = EEPROM__param->addr >> 8;  	
    EEARL = EEPROM__param->addr;  	
    EEPROM__param->addr++;
    EECR |= (1 << EERE);
    *EEPROM__param->data = EEDR;
    EEPROM__param->data++;
  }
}

/*===============================================================
  Writes one byte to the EEPROM.
=================================================================*/
void EEPROM_write_byte()
{
  while( EECR & (1 << EEPE) ); // wait for complition of previous write
  EEPROM__param->length--;
  EEARH = EEPROM__param->addr >> 8;  	
  EEARL = EEPROM__param->addr;  	
  EEPROM__param->addr++;
  EEDR = *EEPROM__param->data;
  EEPROM__param->data++;
    ATOMIC_SECTION_ENTER
    asm volatile
      (
        "sbi 0x1F,0x03\n\t" //sbi EECR,EERIE //enable EEPROM ready interrupt
        "sbi 0x1F,0x02\n\t" //sbi EECR,EEMPE
        "sbi 0x1F,0x01\n\t" //sbi EECR,EEPE        
      ::);
    ATOMIC_SECTION_LEAVE
}

/*===============================================================
  The main state machine.
=================================================================*/
void EEPROM__callDispatcher(result_t status)
{
  switch (EEPROM__state)
  {
    case EEPROM_WRITE_STATE:
      switch (EEPROM__subState)
      {
        case EEPROM_IDLE_SUBSTATE:
          if(EEPROM__param->length > 1)
              EEPROM__subState = EEPROM_NOT_LAST_BYTE;
          else
            EEPROM__subState = EEPROM_LAST_BYTE;
            EEPROM_write_byte();
        break;

        case EEPROM_NOT_LAST_BYTE:
          if(EEPROM__param->length == 1)
              EEPROM__subState = EEPROM_LAST_BYTE;
            EEPROM_write_byte();
        break;

        case EEPROM_LAST_BYTE:
          EEPROM__state = EEPROM_IDLE_STATE;
          EEPROM__subState = EEPROM_IDLE_SUBSTATE;
          TOS_post( EEPROM__signalWriteDone );
        break;

        default:
        break;
      }
        
    break;

    case EEPROM_READ_STATE:
      switch (EEPROM__subState)
      {
        case EEPROM_IDLE_SUBSTATE:
          EEPROM_read_byte();
          EEPROM__state = EEPROM_IDLE_STATE;
          TOS_post( EEPROM__signalReadDone );
          break;

        case EEPROM_NOT_LAST_BYTE:
          break;

        case EEPROM_LAST_BYTE:
          break;

        default:
          break;
      }
      
      break;

      default:
        break;	
  }
}


/*===============================================================
  call splitter.
=================================================================*/
void EEPROM__tDispatcher()
{
    EEPROM__callDispatcher(SUCCESS);
}

/*===============================================================
  Writes the data block to the EEPROM.
  Parameters:
    params - address of parameters structure.
    writeDone - callback.
  Returns: 
    SUCCESS -  no operations is performing and length is not 0
    FAIL - in other case.
=================================================================*/
result_t eeprom_write(EEPROMParams_t *params, void (*writeDone)())
{
  if( !params || !writeDone ) return FAIL;
  if( params->addr >= EEPROM_DATA_MEMORY_SIZE )
  {
    params->status = EEPROM_ADDR_TOO_FAR_STATUS;
    return SUCCESS;
  }
  if( (uint16_t)(params->addr + params->length) > EEPROM_DATA_MEMORY_SIZE )
  {
    params->status = EEPROM_LENGTH_TOO_LONG_STATUS;
    return SUCCESS;
  }
  if( EEPROM_IDLE_STATE != EEPROM__state)
  {
    params->status = EEPROM_OPERATION_OVERFLOW_STATUS;
    return SUCCESS;
  }
  EEPROM__state = EEPROM_WRITE_STATE;
  EEPROM__param = params;
  EEPROM__operationDone = writeDone;

  TOS_post( EEPROM__tDispatcher );
  return SUCCESS;
}
  
/*===============================================================
Reads data block from the EEPROM.
Parameters:
  params - address of parameters structure.
Returns: 
  SUCCESS -  no operations is performing and length is not 0 
  FAIL - in other case.
=================================================================*/
result_t eeprom_read(EEPROMParams_t *params, void (*readDone)())
{
  if( !params || !readDone ) return FAIL;
  if( params->addr >= EEPROM_DATA_MEMORY_SIZE )
  {
    params->status = EEPROM_ADDR_TOO_FAR_STATUS;
    return SUCCESS;
  }
  if( (uint16_t)(params->addr + params->length) > EEPROM_DATA_MEMORY_SIZE )
  {
    params->status = EEPROM_LENGTH_TOO_LONG_STATUS;
    return SUCCESS;
  }
  if( EEPROM_IDLE_STATE != EEPROM__state)
  {
    params->status = EEPROM_OPERATION_OVERFLOW_STATUS;
    return SUCCESS;
  }
  EEPROM__state = EEPROM_READ_STATE;
  EEPROM__param = params;
  EEPROM__operationDone = readDone;
  TOS_post( EEPROM__tDispatcher );
  return SUCCESS;
}
  
/*===============================================================
EEPROM Ready interrupt handler.
=================================================================*/
SIGNAL(SIG_EEPROM_READY)
{
  EECR &= ~(1 << EERIE); //disable interrupt
  if(EEPROM__state == EEPROM_WRITE_STATE)
  TOS_post( EEPROM__tDispatcher );
}

// eof eeprom.c
