/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


#ifndef EEPROM_H_
#define EEPROM_H_

#define EEPROM_DATA_MEMORY_SIZE 0x1000u

// the return codes of eeprom module
typedef enum
{
  EEPROM_SUCCESS_STATUS,
  EEPROM_ADDR_TOO_FAR_STATUS,
  EEPROM_LENGTH_TOO_LONG_STATUS,
  EEPROM_HARDWARE_ERROR_STATUS,
  EEPROM_OPERATION_OVERFLOW_STATUS,
  EEPORM_INVALID_DATA_POINTER_STATUS
}EEPROMStatus_t;

typedef struct
{
  uint16_t addr;           // eeprom address
  uint8_t *data;           // pointer to data memory
  uint16_t length;         // number of bytes
  EEPROMStatus_t status;   // contains result of operation
}EEPROMParams_t;

/****************************************************************
  StdControl interface.
****************************************************************/
result_t eeprom_init();

/****************************************************************
  Writes the data block to the EEPROM.
  Parameters:
    params - address of parameters structure.
    writeDone - callback.
  Returns: 
    SUCCESS -  no operations is performing and length is not 0
    FAIL - in other case.
****************************************************************/
result_t eeprom_write(EEPROMParams_t *params, void (*writeDone)());

/****************************************************************
  Reads data block from the EEPROM.
  Parameters:
    params - address of parameters structure.
  Returns: 
    SUCCESS -  no operations is performing and length is not 0 
    FAIL - in other case.
****************************************************************/
result_t eeprom_read(EEPROMParams_t *params, void (*readDone)());

#define eeprom__init eeprom_init
#define eeprom__write eeprom_write
#define eeprom__read eeprom_read

#endif	/* EEPROM_H_ */
// eof EEPROM.h

