/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/****************************************************************
  The module to make power off mode.
****************************************************************/

#include <tos.h>
#include <atomic.h>
#include <hplat86rf230m.h>
#include <sleeptimerclock.h>

uint8_t wakeupFlag = 0; //it is used for reliable wake up

/****************************************************************
  Lets the network stack to control TRSLEEP pin.
****************************************************************/
void PowerOn()
{ // will let the application the control of TRSLEEP pin
  wakeupFlag = 1;
#ifdef HAL_RC_OSCILLATOR
  TOSH_CLR_TRSLEEP_PIN();
#else
  TOSH_MAKE_TRSLEEP_INPUT(); // Disconnects TRSLEEP pin from comparator output.
  TCCR2A &= ~(1<<COM2A1 | 1<<COM2A0);// no compare  
  while ( ASSR & 0x1B); 
#endif
  TOSH_MAKE_TRSLEEP_OUTPUT();
}
  
/****************************************************************
  Shutdown system.
  NOTES:
  the application should be sure the poweroff will not be 
  interrupted before the execution of the sleep command.
****************************************************************/
void PowerOff()
{      
  if(wakeupFlag)
   return;  // it is a too late for sleep.  The sleep interval is expired.
#ifdef HAL_RC_OSCILLATOR
  HPLTimer0Clock__sleepControl( TRUE );// will be shutdown
  TOSH_SET_TRSLEEP_PIN();
  TOSH_MAKE_TRSLEEP_OUTPUT();
  SMCR |= (1 << SM1) | (1 << SM0);
  SMCR |= 1 << SE;
  asm volatile
  (
    "SLEEP\n\t"
  ::);
  SMCR = 0;
#else
  uint8_t timsk5 = TIMSK5;
  uint8_t twcr = TWCR;
  uint8_t adcsra =  ADCSRA;
  TIMSK5 = 0;
  TWCR = 0;
  ADCSRA = 0;
  HPLTimer0Clock__sleepControl( TRUE );// will be shutdown
  TOSH_MAKE_TRSLEEP_OUTPUT();
  SMCR |= (1 << SM1) | (1 << SM0);
  SMCR |= 1 << SE;
  asm volatile
  (
    "SLEEP\n\t"
  ::);
  SMCR = 0;
  TIMSK5 = timsk5;
  TWCR = twcr;
  ADCSRA = adcsra;       
#endif
}
 
/****************************************************************
  Prepares system for shutdown.
****************************************************************/
void sleep()
{ 
  wakeupFlag = 0;  // the reset of sign of entry to the sleep mode.
//    PORTA = 0xFF;
//    PORTB = 0xFF;
    PORTC = 0xFF;
//    PORTD = 0xFF;
//    PORTE = 0xFF;
//    PORTF = 0xFF;
#if 0
    DDRA = 0xFF;
//    DDRB = 0xFF;
    DDRC = 0xFF;
//    DDRD = 0xFF;
    DDRD = 0xFB;
//    DDRE = 0xFF;
    DDRE = 0xDE;
//    DDRF = 0xFF;
    DDRF = 0x6F;
    DDRG = 0xFF;
#endif
#if 0
//    DDRA = 0x00;
//    DDRB = 0x00;
    DDRC = 0x00;
    DDRD = 0x00;
    DDRE = 0x00;
    DDRF = 0x00;
    DDRG = 0x00;
#endif
//    PORTD = 0x7F;
//    DDRD = 0x80;

//    PORTF = 0xFC;
//    DDRF = 0x03;
#ifndef HAL_RC_OSCILLATOR
  TOSH_MAKE_TRSLEEP_INPUT();
  while ( ASSR & 0x1B);  
  TCCR2A |= (1<<COM2A1 | 1<<COM2A0); // set OC2A on compare
  while ( ASSR & 0x1B);
  TCCR2B |= 1<<FOC2A;// force output to set OC2A
  while ( ASSR & 0x1B);
  TCCR2A &= ~(1<<COM2A1 | 1<<COM2A0);// no compare  
  while ( ASSR & 0x1B);
  TCCR2A |= ( 1<<COM2A1 ); // clear OC2A on compare
  while ( ASSR & 0x1B);
#endif
  TOS_post(PowerOff);
}

// eof sleep.c
