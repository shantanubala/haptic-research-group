/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/


#ifndef HPLCLOCK_H_
#define HPLCLOCK_H_

#include <tos.h>
#include <avrhardware.h>

#define HPLCLOCK_TIMER_PRESCALER_1 64

/****************************************************************
  Sets a interval.
  Parameters:
    value - contains the interval.
****************************************************************/
void HPLClock__Clock__setInterval(uint8_t );

/***************************************************************
  Returns a current value of the interval.*
****************************************************************/
uint8_t HPLClock__Clock__readCounter(void);

/****************************************************************
  Sets a count out interval. Performs init settings.
  Parameters:
    interval - contains the interval.
  Returns:
    SUCCESS - always.
****************************************************************/
result_t HPLClock__Clock__setRate(char , char );

/****************************************************************
  Initialization.
****************************************************************/
result_t HPLClock__StdControl__init(void);

/****************************************************************
  Starts hardware timer.
****************************************************************/
result_t HPLClock__StdControl__start(void);

/****************************************************************
  Sets default interval.
****************************************************************/
result_t HPLClock__StdControl__stop(void);

#endif  /*  HPLCLOCK_H_ */

