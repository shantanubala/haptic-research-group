/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#include <tos.h>
#ifndef SLEEPTIMER_H
#define SLEEPTIMER_H

#include <apptimer.h>

#define NUM_SLEEP_TIMERS 2

/****************************************************************
  Registers handler for sleep timer fired event.
  Parameters:
    fired – pointer to fired event handler.
  Returns:
    positive descriptor if the registration is successful and 
    -1 - in other case.
****************************************************************/
int sleepTimer_open(void (*fired)());

/****************************************************************
  Cancels handler was concerned with id descriptor.
  Returns 
    FAIL - there is no such descriptor.
    SUCCESS - other case.
****************************************************************/
result_t sleepTimer_close(int id);

/****************************************************************
  Starts sleep timer.
  Parameters:
    id – descriptor.
    mode – sleep timer mode.
    interval - interval in ms.
  Retuirns:
    FAIL - bad descriptor or the type of timer.
    SUCCESS - otherwise.
*****************************************************************/
result_t sleepTimer_start(int id, TimerMode_t type, uint32_t interval);

/****************************************************************
  Stops timer.
  Returns:
  FAIL - bad descriptor.
  SUCCESS - otherwise.
****************************************************************/
result_t sleepTimer_stop(int id);

#define sleepTimer__open sleepTimer_open
#define sleepTimer__close sleepTimer_close
#define sleepTimer__start sleepTimer_start
#define sleepTimer__stop sleepTimer_stop

#endif
// eof sleeptimer.h



