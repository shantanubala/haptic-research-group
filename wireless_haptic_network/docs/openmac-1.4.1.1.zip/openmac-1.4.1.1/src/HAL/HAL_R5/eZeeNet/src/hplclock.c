/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/*===============================================================
The module counts out requested interval of timerM.
=================================================================*/

#include <hplclock.h>
#include <atomic.h>

//uint8_t HPLClock__set_flag;
uint8_t HPLClock__mscale;
//uint8_t HPLClock__nextScale;
uint8_t HPLClock__minterval; // Contains minimal interval
uint8_t HPLClock__counter;   // Stores the value which will be counted out
uint8_t HPLClock__cnt;       // Contains a counted out interval

// event hanndler
void TimerM__Clock__fire();

/*===============================================================
  Sets a interval.
  Parameters:
    value - contains the interval.
=================================================================*/
void HPLClock__Clock__setInterval(uint8_t value)
{
  TIMSK5 &= (1 << OCIE5A); // Disable TC5 interrupt
  HPLClock__counter = value;
  HPLClock__cnt = 0;
  TIMSK5 |= (1 << OCIE5A); // Enable TC5 interrupt
}

/*===============================================================
  Returns a current value of the interval.
=================================================================*/
uint8_t HPLClock__Clock__readCounter(void)
{
  return HPLClock__cnt;
}

/*===============================================================
  Sets a count out interval. Performs init settings.
  Parameters:
    interval - contains the interval.
  Returns:
    SUCCESS - always.
=================================================================*/
result_t HPLClock__Clock__setRate(char interval, char scale)
{
  /*scale &= 0x7;*/
  /*scale |= 0x8;*/
  ATOMIC_SECTION_ENTER
    TCCR5B = 0; // stop the timer
    HPLClock__counter = interval;
    HPLClock__cnt = 0;
    TIMSK5 &= ~((1 << OCIE5A) | (1 <<  TOIE5)); // Disable TC5 interrupt
    OCR5A = 500; // 1 millisecond timer interrupt interval.
    TCNT5 = 0;
    TCCR5B = (1 << WGM12) | (1 << CS11); // CTC, main clk / 8
    TIMSK5 |= (1 << OCIE5A); // Enable TC5 interrupt
  ATOMIC_SECTION_LEAVE
return SUCCESS;
}

/*===============================================================
  Initialization.
=================================================================*/
result_t HPLClock__StdControl__init(void)
{
  ATOMIC_SECTION_ENTER
    HPLClock__mscale = 0x02;
    HPLClock__minterval = 64;
  ATOMIC_SECTION_LEAVE
return SUCCESS;
}

/*===============================================================
  Starts hardware timer.
=================================================================*/
result_t HPLClock__StdControl__start(void)
{
  HPLClock__Clock__setRate(HPLClock__minterval,  HPLClock__mscale);
  return SUCCESS;
}

/*===============================================================
  Sets default interval.
=================================================================*/
result_t HPLClock__StdControl__stop(void)
{
  uint8_t mi;

  ATOMIC_SECTION_ENTER
    mi = HPLClock__minterval;
  ATOMIC_SECTION_LEAVE
  HPLClock__Clock__setRate(mi, 0);
  return SUCCESS;
}

/*===============================================================
Interrupt handler.
=================================================================*/
SIGNAL(SIG_OUTPUT_COMPARE5A)
{
/*	ATOMIC_SECTION_ENTER
    	if (HPLClock__set_flag)
        {
        	HPLClock__mscale = HPLClock__nextScale;
         	HPLClock__nextScale |= 0x8;
         	HPLClock__set_flag = 0;
        }
	ATOMIC_SECTION_LEAVE*/
  if (++HPLClock__cnt >= HPLClock__counter)
  {
    HPLClock__cnt = 0;
    TimerM__Clock__fire();
  }
}
// eof hplclock.c
