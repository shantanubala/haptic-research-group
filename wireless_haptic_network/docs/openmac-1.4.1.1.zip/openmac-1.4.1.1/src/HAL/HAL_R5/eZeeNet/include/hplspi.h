/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#ifndef HPLSPI_H_
#define HPLSPI_H_

#include "avrhardware.h"
#include "hardware.h"
#include "tos.h"

TOSH_ASSIGN_PIN(SPI_CSN, B, 0);        // CSN output SPI interface.
TOSH_ASSIGN_PIN(SPI_SCLK, B, 1);
TOSH_ASSIGN_PIN(SPI_MOSI, B, 2);
TOSH_ASSIGN_PIN(SPI_MISO, B, 3);

void HPLSPIM__HPLSPI__init();
void HPLSPIM__HPLSPI__setCS();
void HPLSPIM__HPLSPI__clrCS();
uint8_t HPLSPIM__HPLSPI__write(uint8_t value);
void HPLSPIM__HPLSPI__writeBlock(uint8_t* value);
void HPLSPIM__HPLSPI__readBlock(uint8_t* value, uint8_t frameLength);


typedef struct       // Read/write register operation parameters. 
{
  uint8_t addr;      // Register's address.
  uint8_t *data;     // Register's value.
} SPIRegistersParams;

typedef struct    // Read/write frame operation parameters.
{
  uint8_t *data;  // Frame buffer.
  uint8_t length; // Frame length.
} SPIFrameParams;

typedef struct    // Read/write SRAM operation parameters. 
{
  uint8_t addr;   // Base address.
  uint8_t *data;  // Buffer of bytes.
  uint8_t length; // Number of bytes.
} SPISRAMParams;

enum // Constants. 
{
  AT86RF230_CMD_RW = ((1<<7) | (1<<6)),
  AT86RF230_CMD_RR = ((1<<7) | (0<<6)),
  AT86RF230_CMD_FW = ((0<<7) | (1<<6) | (1<<5)),
  AT86RF230_CMD_FR = ((0<<7) | (0<<6) | (1<<5)),
  AT86RF230_CMD_SW = ((0<<7) | (1<<6) | (0<<5)),
  AT86RF230_CMD_SR = ((0<<7) | (0<<6) | (0<<5)),
  
  AT86RF230_RADDRM = ((0<<7) | (0<<6) | (1<<5) | (1<<4) | (1<<3) | (1<<2) |(1<<1) | (1<<0)),
};

#endif /* HPLSPI_H_ */
