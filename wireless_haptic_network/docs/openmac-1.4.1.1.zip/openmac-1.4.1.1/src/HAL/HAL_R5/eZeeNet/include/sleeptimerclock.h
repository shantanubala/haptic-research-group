/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

#include <tos.h>
#ifndef SLEEPTIMERCLOCK_H
#define SLEEPTIMERCLOCK_H

#define SLEEPTIMER_CLOCK 32768lu
#define SLEEPTIMER_PRESCALER_1    (1u << CS20)                  // No prescaling
#define SLEEPTIMER_PRESCALER_8    (1u << CS21)                  // clk/8
#define SLEEPTIMER_PRESCALER_32   (1u << CS20 | 1u << CS21)     // clk/32
#define SLEEPTIMER_PRESCALER_64   (1u << CS22)                  // clk/64
#define SLEEPTIMER_PRESCALER_128  (1u << CS20 | 1u << CS22)     // clk/128
#define SLEEPTIMER_PRESCALER_256  (1u << CS21 | 1u << CS22)     // clk/256
#define SLEEPTIMER_PRESCALER_1024 (1u << CS20 | 1u << CS21 | 1u << CS22) // clk/1024

/****************************************************************
  Stops the application timer. Sets the sleep control flag.
  Parameters: 
    enableSleep - TRUE system will be shutdown after 
                the wake up if the interval is still not counted.
****************************************************************/
void HPLTimer0Clock__sleepControl(bool enableSleep);

/****************************************************************
  Initializes the component.
****************************************************************/
result_t HPLTimer0Clock__StdControl__init();

/****************************************************************
  Sets clock interval. 
  Parameters:
    value - contains number of ticks which the timer must count out.
****************************************************************/
void HPLTimer0Clock__setInterval( uint32_t value );

/****************************************************************
  Returns the current interval in ticks.
****************************************************************/
uint32_t HPLTimer0Clock__getInterval();

/****************************************************************
  Returns the timer frequency in Hz.
****************************************************************/
uint32_t HPLTimer0Clock__getFrequency();

/****************************************************************
  Disables compare interrupt.
****************************************************************/
void HPLTimer0Clock__intDisable();

/****************************************************************
  Enables compare interrupt.
****************************************************************/
void HPLTimer0Clock__intEnable();

/****************************************************************
 Notifies on that the set interval was counted out
****************************************************************/
void HPLTimer0Clock__fire();
#endif
// eof sleeptimerclock.h



