/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/*===============================================================
  Module for count out requested interval.
=================================================================*/

#include <avrhardware.h>
#include <appclock.h>
#include <sleeptimerclock.h>

struct
{
  uint32_t Interval;     // Contains number of tics before will send event.
  uint32_t workInterval; // Contains number of ticks had passed since moment of call setInterval()
  uint32_t factor;       // Contains scale factor.
} HPLTimerControl;

bool HPLSleepTimer__enableSleep = FALSE; // Defines capability of the component makes shutdown.

/*===============================================================
Stops the application timer. Sets the sleep control flag.
Parameters: 
  enableSleep - if TRUE system will be shutdown after 
                the wake up if the interval is still not counted.
=================================================================*/
void HPLTimer0Clock__sleepControl(bool enableSleep)   
{
  appClock__Clock__stop();
  HPLSleepTimer__enableSleep = enableSleep;
}

/*===============================================================
Initializes the component.
=================================================================*/
result_t HPLTimer0Clock__StdControl__init()
{
  ASSR |= (1 << AS2);
  TCCR2B = 0x00;  // Stop the timer
  TCCR2A = 0x00;
  TCNT2 = 0x00;
  OCR2A = 0x00;
  HPLTimerControl.workInterval = 0;
  while ( ASSR & 0x1B);
  return SUCCESS;
 }

/*===============================================================
Starts the component and its subcomponents.
=================================================================*/
result_t HPLTimer0Clock__StdControl__start()
{
  return SUCCESS;
}

/*===============================================================
Stops the component. 
=================================================================*/
result_t HPLTimer0Clock__StdConrtol__stop()
{
  TCCR2B &= ~(1 << CS20 | 1 << CS21 | 1 << CS22);  // Stops the timer
  return SUCCESS;
}

/*===============================================================
Sets clock interval. 
Parameters:
  value - contains number of ticks which the timer must count out.
=================================================================*/
void HPLTimer0Clock__setInterval( uint32_t value )
{
  TCCR2B &= ~(1 << CS20 | 1 << CS21 | 1 << CS22);  // Stop the timer  
  HPLTimerControl.Interval = value;
  HPLTimerControl.workInterval = 0;
  HPLTimerControl.factor = value / 256ul;
  while ( ASSR & 0x1B);
  GTCCR |= 1<<PSRASY; // Prescaler reset Timer/Counter2
  TIFR2 |= (1 << OCF2A); // Clears Timer/Counter2 compare flag
  TCNT2 = 0x00;
  if(!HPLTimerControl.factor)
  {
    OCR2A = HPLTimerControl.Interval; 
  }
  else
  {
    OCR2A = 0x00;
  }
  TCCR2B |= SLEEPTIMER_PRESCALER;// starts timer 
  while ( ASSR & 0x1B);
}

/*===============================================================
Returns the current interval in ticks.
=================================================================*/
uint32_t HPLTimer0Clock__getInterval()
{
  return (HPLTimerControl.workInterval + TCNT2);
}

/*===============================================================
Returns the timer frequency in Hz.
=================================================================*/
uint32_t HPLTimer0Clock__getFrequency()
{
  const uint16_t ScaleFactors[]={
                                  0,   // Timer/Counter stopped
                                  1,   // No prescaling
                                  8,   // clk/8
                                  32,  // clk/32
                                  64,  // clk/64
                                  128, // clk/128
                                  256, // clk/256
                                  1024 // clk/1024
                                 };
  return (SLEEPTIMER_CLOCK / (uint32_t)ScaleFactors[ SLEEPTIMER_PRESCALER ]);
}

/*===============================================================
Set HW clock counter to a specified value.
=================================================================*/
void HPLTimer0Clock__setCounter(uint8_t n)
{
  uint8_t i;
  while ( ASSR & 0x1B);
  i = TCCR2B;
  TCCR2B = 0x00;  // Stops the timer
  TCNT2 = n;
  TCCR2B = i;
  while ( ASSR & 0x1B);
  return;
}

/*===============================================================
Disable compare interrupt.
=================================================================*/
void HPLTimer0Clock__intDisable()
{
  TIMSK2 &= ~(1 << OCIE2A); // Disables 8-bit Timer/Counter2 compare interrupt
  return;
}

/*===============================================================
Enable compare interrupt.
=================================================================*/
void HPLTimer0Clock__intEnable()
{
  TIMSK2 |= (1 << OCIE2A); // Sets 8-bit Timer/Counter0 compare interrupt enable
  return;
}

/*===============================================================
Interrupt handler.
=================================================================*/ 
SIGNAL(SIG_OUTPUT_COMPARE2A)
{
  uint8_t i;
  if( HPLTimerControl.factor )
  {
    // Sets the maximum interval of the uninterrupted sleep.
    HPLTimerControl.factor--;
    HPLTimerControl.workInterval += 256ul;
    if(!HPLTimerControl.factor)
    {
      i = HPLTimerControl.Interval - HPLTimerControl.workInterval; // The number of periods to sleep
      TCCR2B &= ~(1 << CS20 | 1 << CS21 | 1 << CS22);  // Stops the timer
      TCNT2 = 0x00;
      if(i)
      {            
        OCR2A = i;
        while ( ASSR & 0x1B);  
          TCCR2B |= SLEEPTIMER_PRESCALER;// start timer  
        while ( ASSR & 0x1B);
        if( HPLSleepTimer__enableSleep == TRUE)            
          sleep();      
      }
      else
      {
        while ( ASSR & 0x1B);
        if( HPLSleepTimer__enableSleep == TRUE )
        {
          HPLSleepTimer__enableSleep = FALSE;
          PowerOn();
            appTimer_setInterval( (HPLTimer0Clock__getInterval() * 1000) / HPLTimer0Clock__getFrequency() );
            appClock__Clock__HandleFire();
            appClock__Clock__start();
        }
        HPLTimer0Clock__fire();
      }
    }
    else
    {
      if( HPLSleepTimer__enableSleep == TRUE )
      sleep();
    }
  }
  else
  {
    // Remainder from 256.
    TCCR2B &= ~(1 << CS20 | 1 << CS21 | 1 << CS22);  // Stops the timer
    TCNT2 = 0;
    HPLTimerControl.workInterval = HPLTimerControl.Interval;          
    while ( ASSR & 0x1B);
    if( HPLSleepTimer__enableSleep == TRUE )
    {
      HPLSleepTimer__enableSleep = FALSE;
      PowerOn();
      appTimer_setInterval( (HPLTimer0Clock__getInterval() * 1000) / HPLTimer0Clock__getFrequency() );
      appClock__Clock__HandleFire();
      appClock__Clock__start();
    }
    HPLTimer0Clock__fire();
  }      
}
//eof sleeptimerclock.c

