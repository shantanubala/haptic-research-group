/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 
/********************************************************************************
  skbuff.h
  
********************************************************************************/

#ifndef __SKBUFF_H__
#define __SKBUFF_H__

#ifndef PACK
  #ifdef PACK_STRUCTURES
    #define PACK __attribute__ ((packed))
  #else
    #define PACK
  #endif
#endif

typedef struct __sk_buff_head {
  /* These two members must be first. */
  struct __sk_buff *next;
  struct __sk_buff *prev;

  uint16_t qlen;    /* queue len */
} PACK sk_buff_head;

typedef struct __sk_buff {
  /* These two members must be first. */
  struct __sk_buff *next;       /* Next buffer in list */
  struct __sk_buff *prev;       /* Previous buffer in list */

  sk_buff_head *list;  /* List we are on */

  uint16_t  len;              /* Length of actual data */
  uint16_t  truesize;         /* Buffer size */

  uint8_t   *head;            /* Head of buffer */
  uint8_t   *data;            /* Data head pointer */
  uint8_t   *tail;            /* Tail pointer */
  uint8_t   *end;             /* End pointer */

  /*TODO: add refcounter for clone operations */

} PACK sk_buff;

#endif  /* __SKBUFF_H__ */

//end of skbuff
