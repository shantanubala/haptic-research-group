/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 
/********************************************************************************
  File: PHY.h
  Created: AKokhonovskiy 2005.
  Description: Types and constants declaration for IEEE802.15.4 PHY implementation.
  Copyright: (c)Meshnetics.
********************************************************************************/

#ifndef _PHY_H
#define _PHY_H

/******************************************************************************
  Maximum PHY frame size.
  IEEE802.15.4 table - 18.
******************************************************************************/
enum
{
  MAX_PHY_PACKET_SIZE  = 127,
  PHY_TURNARROUND_TIME = 12,
  PHY_SYMBOL_DURATION  = 16,        // Duration of symbol (in microsecond).   
};

/******************************************************************************
  CCA mode types.
  IEEE802.15.4 paragraph - 6.7.9.
******************************************************************************/
typedef enum
{
  PHY_CCA_MODE_N = 0,
  PHY_CCA_MODE_1 = 1,
  PHY_CCA_MODE_2 = 2,
  PHY_CCA_MODE_3 = 3
} PHYCCAMode;

/******************************************************************************
  Some PHY constants.
******************************************************************************/
enum
{
  PHY_SUPPORTED_CHANNELS = 0x07fff800,    // Supported channels mask.
  PHY_MIN_CHANNEL        = 11,            // Minimum channel number.
  PHY_MAX_CHANNEL        = 26,            // Maximum channel number.
  PHY_CHANNELS_NUMBER    = PHY_MAX_CHANNEL - PHY_MIN_CHANNEL + 1, // Supported channels number.
  PHY_MIN_TX_POWER       = -17,           // Minimum transmit power value. 
  PHY_MAX_TX_POWER       = 3,             // Maximum transmit power value.
  PHY_DEFAULT_TX_POWER   = 0,             // Default transmit power value.
  PHY_DEFAULT_CCA_MODE   = PHY_CCA_MODE_1,// Default CCA mode.
};

/******************************************************************************
  TRX state type.
  IEEE802.15.4 paragraph - 6.2.2.7.
******************************************************************************/
typedef enum
{
  PHY_RX_ON_TRX_STATE = 0x06,
  PHY_OFF_TRX_STATE   = 0x08,
  PHY_TX_ON_TRX_STATE = 0x09
} PHYTRXState;

/******************************************************************************
  PHY PIB attribute ID type.
  IEEE802.15.4 table - 19.
******************************************************************************/
typedef enum
{
  PHY_PIB_CURRENT_CHANNEL_ID    = 0x00,
  PHY_PIB_CHANNELS_SUPPORTED_ID = 0x01,
  PHY_PIB_TX_POWER_ID     = 0x02,
  PHY_PIB_CCA_MODE_ID           = 0x03,
  // All other parameters are additional,
  // NOT described in the standard.
  PHY_PIB_PANID_ID              = 0x04,
  PHY_PIB_SHORT_ADDR_ID         = 0x05,
  PHY_PIB_EXT_ADDR_ID           = 0x06,
  PHY_PIB_ADDR_DECODE_ID        = 0x07,
  PHY_PIB_PAN_COORDINATOR_ID    = 0x08,
  PHY_PIB_MIN_BE_ID             = 0x09,
  PHY_PIB_MAX_CSMA_BACKOFFS_ID  = 0x0A,
} PHYPIBid;

/******************************************************************************
  PHY PIB attribute type.
  IEEE802.15.4 table - 19.
******************************************************************************/
typedef union
{
  uint8_t          channel;
  uint32_t         channelsSupported;
  // All other parameters are additional,
  // NOT described in the standard.
  MACPANId         panId;
  MACShortAddr     shortAddr;
  MACExtAddr       extAddr;
  bool             addrDecode;
  bool             panCoordinator;
  uint8_t          maxCSMABackoffs;
  uint8_t          minBE;
  PHYCCAMode       CCAMode;
  int8_t           txPower;
} PHYPIBAttr;

/******************************************************************************
  Params of SET/GET requests and confirms.
******************************************************************************/
typedef struct
{
  PHYPIBid id;
  PHYPIBAttr attr;
} PHYPIBParam;

#endif

// eof PHY.h
