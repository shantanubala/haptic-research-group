/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 
/********************************************************************************
  File: HPLIEEE802_15_4.h
  Created: AKokhonovskiy 2005.
  Description: IEEE802.15.4 constants for AT86RF230.
  Copyright: (c)Meshnetics.
********************************************************************************/

#ifndef _HPLIEEE802_15_4_H
#define _HPLIEEE802_15_4_H

enum
{
  ADDR_DECODE_FLAG           = (1 << 0), //saves addr decode mode
  UR_IRQ_FLAG                = (1 << 1), //there is a probability of UR_IRQ occures (because we check receive case through post)
};

typedef struct
{
  MACPANId panId;
  MACShortAddr shortAddr;
  MACExtAddr extAddr;
} ADDRInfo;


#endif

// eof HPLIEEE802_15_4.h
