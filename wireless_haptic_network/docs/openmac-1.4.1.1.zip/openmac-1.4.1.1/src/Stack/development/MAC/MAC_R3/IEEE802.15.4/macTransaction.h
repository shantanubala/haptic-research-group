/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: macTransaction.h
  Created: AKokhonovskiy 2005.
  Description: Transaction types and constants declaration.
  Copyright: (c)Meshnetics.
********************************************************************************/

#ifndef _MAC_TRANSACTION_H
#define _MAC_TRANSACTION_H

typedef enum // Transaction possible types.
{
  MAC_NO_TRANSACTION,
  MAC_ASSOCIATION_TRANSACTION,
  MAC_DATA_TRANSACTION,
  MAC_DISASSOCIATION_TRANSACTION,
} MACTransactionType;

typedef union // Transaction params.
{
  MACAssociateRespParams   *association;
  MACDataParams            *data;
  MACDisassociateReqParams *disassociation;
} MACTransactionParams;

typedef struct // Transaction. 
{
  MACTransactionType type;     // Transaction type.
  MACTransactionParams params; // Transaction params.
  uint32_t time;               // Remained transaction time, ms.
  bool serving;                // Serving transaction.  
} MACTransaction;

#endif

// eof macTransaction.h
