/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/
 
/********************************************************************************
  File: MAC.h
  Created: AKokhonovskiy 2005.
  Description: Types and constants declaration for IEEE802.15.4 MAC implementation.
  Copyright: (c)Meshnetics.
********************************************************************************/

#ifndef _MAC_H
#define _MAC_H

#ifndef PACK
#ifdef PACK_STRUCTURES
#define PACK __attribute__ ((packed))
#else
#define PACK
#endif
#endif

#include "MACAddrTypes.h"
#include "tos.h"
#include "PHY.h"

/******************************************************************************
  MAC primitives' return codes.
******************************************************************************/
typedef enum
{
  // IEEE802.15.4 table - 68.
  MAC_PAN_AT_CAPACITY_STATUS        = 0x01, 
  MAC_PAN_ACCESS_DENIED_STATUS      = 0x02,
  // IEEE802.15.4 table - 64.
  MAC_SUCCESS_STATUS                = 0x00, // The requested operation was completed 
                                            // successfully. For a transmission request,
                                            // this value indicates successful transmission.
  MAC_BEACON_LOSS_STATUS            = 0xE0,
  MAC_CHANNEL_ACCESS_FAILURE_STATUS = 0xE1,
  MAC_DENIED_STATUS                 = 0xE2,
  MAC_DISABLE_TRX_FAILURE_STATUS    = 0xE3,
  MAC_FAILED_SECURITY_CHECK_STATUS  = 0xE4, 
  MAC_FRAME_TOO_LONG_STATUS         = 0xE5,
  MAC_INVALID_GTS_STATUS            = 0xE6,
  MAC_INVALID_HANDLE_STATUS         = 0xE7,
  MAC_INVALID_PARAMETER_STATUS      = 0xE8,
  MAC_NO_ACK_STATUS                 = 0xE9,
  MAC_NO_BEACON_STATUS              = 0xEA,
  MAC_NO_DATA_STATUS                = 0xEB,
  MAC_NO_SHORT_ADDRESS_STATUS       = 0xEC,
  MAC_OUT_OFF_CAP_STATUS            = 0xED,
  MAC_PAN_ID_CONFLICT_STATUS        = 0xEE,
  MAC_REALIGNMENT_STATUS            = 0xEF,
  MAC_TRANSACTION_EXPIRED_STATUS    = 0xF0,
  MAC_TRANSACTION_OVERFLOW_STATUS   = 0xF1,
  MAC_TX_ACTIVE_STATUS              = 0xF2,
  MAC_UNAVAILABLE_KEY_STATUS        = 0xF3,
  MAC_UNSUPPORT_ATTRIBUTE_STATUS    = 0xF4
} MACStatus;

/******************************************************************************
  MAC PIB attribute ID type.
  IEEE802.15.4 table - 71.
******************************************************************************/
typedef enum
{
  MAC_PIB_ACK_WAIT_DURATION_ID                = 0x40, // This parameter's managing through MLME_SAP_SETrequest is switched off
                                                      // in current realization - raed only. Actually this parameter value is 
                                                      // defined by hardware.
  MAC_PIB_ASSOCIATION_PERMIT_ID               = 0x41,
  MAC_PIB_AUTO_REQUEST_ID                     = 0x42, // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                      // NOT used - superframe functionality is not implemented.
  MAC_PIB_BATT_LIFE_EXT_ID                    = 0x43, // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                      // NOT used - superframe functionality is not implemented.
  MAC_PIB_BATT_LIFE_EXT_PERIODS_ID            = 0x44, // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                      // NOT used - superframe functionality is not implemented.
  MAC_PIB_BEACON_PAYLOAD_ID                   = 0x45,
  MAC_PIB_BEACON_PAYLOAD_LENGTH_ID            = 0x46,
  MAC_PIB_BEACON_ORDER_ID                     = 0x47, // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                      // NOT used - superframe functionality is not implemented.
  MAC_PIB_BEACON_TX_TIME_ID                   = 0x48, // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                      // NOT used - superframe functionality is not implemented.
  MAC_PIB_BSN_ID                              = 0x49,
  MAC_PIB_COORD_EXT_ADDR_ID                   = 0x4A,
  MAC_PIB_COORD_SHORT_ADDR_ID                 = 0x4B,
  MAC_PIB_DSN_ID                              = 0x4C,
  MAC_PIB_GTS_PERMIT_ID                       = 0x4D,
  MAC_PIB_MAX_CSMA_BACKOFFS_ID                = 0x4E,
  MAC_PIB_MIN_BE_ID                           = 0x4F,
  MAC_PIB_PANID_ID                            = 0x50,
  MAC_PIB_PROMISCUOUS_MODE_ID                 = 0x51, // This parameter's managing through MLME_SAP_SETrequest is switched off
                                                      // in current realization - raed only. Promiscuous mode management is NOT
                                                      // implemented. 
  MAC_PIB_RX_ON_WHEN_IDLE_ID                  = 0x52,
  MAC_PIB_SHORT_ADDR_ID                       = 0x53,
  MAC_PIB_SUPERFRAME_ORDER_ID                 = 0x54, // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                      // NOT used - superframe functionality is not implemented.
  MAC_PIB_TRANSACTION_PERSISTENCE_TIME_ID     = 0x55,
  MAC_PIB_EXT_ADDR_ID                         = 0x6F, // Additional parameter. NOT described in the standard.
                                                      // This parameter replaces MAC_EXTENDED_ADDRESS constant.
  MAC_PIB_CCA_MODE_ID                         = 0x57, // Additional parameter. NOT described in the standard.
                                                      // Controls the mode of CCA.
  MAC_PIB_TX_POWER_ID                         = 0x58, // Additional parameter. NOT described in the standard.
                                                      // Controls Tx power.
} MACPIBId;

/******************************************************************************
  MAC sublayer constants.
  IEEE802.15.4 table - 70.
******************************************************************************/
enum
{
  MAC_BASE_SLOT_DURATION        = 60,
  MAC_NUM_SUPERFRAME_SLOTS      = 16,
  MAC_BASE_SUPERFRAME_DURATION  = MAC_BASE_SLOT_DURATION * MAC_NUM_SUPERFRAME_SLOTS,
  //MAC_EXTENDED_ADDRESS        // Meshnetics correction. This constant value has been moved to MAC_PIB 
                                // parameters table. Device own extended address. It can be managed 
                                // through MLME_SAP_SETrequets and MLME_SAP_GETrequest now. 
  MAC_MAX_BE                    = 5,
  MAC_MAX_BEACON_OVERHEAD       = 75,
  MAC_MAX_BEACON_PAYLOAD_LENGTH = MAX_PHY_PACKET_SIZE - MAC_MAX_BEACON_OVERHEAD,
  MAC_GTS_DESC_PERSISTENCE_TIME = 4,
  MAC_MAX_FRAME_OVERHEAD        = 25,
  MAC_MAX_FRAME_RESPONSE_TIME   = 1220,
  MAC_MAX_FRAME_RETRIES         = 3,
  MAC_MAX_LOST_BEACONS          = 4,
  MAC_MAX_FRAME_SIZE            = MAX_PHY_PACKET_SIZE - MAC_MAX_FRAME_OVERHEAD,
  MAC_MAX_SIFS_FRAME_SIZE       = 18,
  MAC_MIN_CAP_LENGTH            = 440,
  MAC_MIN_LIFS_PERIOD           = 40,
  MAC_MIN_SIFS_PERIOD           = 12,
  MAC_RESPONSE_WAIT_TIME        = 32*MAC_BASE_SUPERFRAME_DURATION,
  MAC_UNIT_BACKOFF_PERIOD       = 20
};

/******************************************************************************
  MAC other constants.
******************************************************************************/
enum
{
  MAC_BROADCAST_PANID      = 0xFFFF, // Broadcast PANID.
  MAC_BROADCAST_SHORT_ADDR = 0xFFFF, // Broadcast short address, no association.
  MAC_NO_SHORT_ADDR        = 0xFFFE, // After association no short address.
  MAC_GTS_MAX              = 7,      // Max of GTS.
  MAC_PENDING_ADDRESS_MAX  = 7,      // Max of pending address in beacon.
};

/******************************************************************************
  MAC PIB attributes default values. 
  IEEE802.15.4 table - 71.
******************************************************************************/
enum
{
  MAC_PIB_ACK_WAIT_DURATION_DEFAULT                = 54, // For currently supported channels range (11 - 26).
                                                         // Actually this is a constant value defined by hardware.
  MAC_PIB_ASSOCIATION_PERMIT_DEFAULT               = FALSE,
  MAC_PIB_AUTO_REQUEST_DEFAULT                     = TRUE,
  MAC_PIB_BATT_LIFE_EXT_DEFAULT                    = FALSE,
  MAC_PIB_BATT_LIFE_EXT_PERIODS_6                  = 6,
  MAC_PIB_BATT_LIFE_EXT_PERIODS_8                  = 8,
  MAC_PIB_BATT_LIFE_EXT_PERIODS_DEFAULT            = MAC_PIB_BATT_LIFE_EXT_PERIODS_6,
  MAC_PIB_BEACON_PAYLOAD_DEFAULT                   = 0,
  MAC_PIB_BEACON_PAYLOAD_LENGTH_MAX                = MAC_MAX_BEACON_PAYLOAD_LENGTH,
  MAC_PIB_BEACON_PAYLOAD_LENGTH_DEFAULT            = 0,
  MAC_PIB_BEACON_ORDER_MAX                         = 15, // Max beacon order.
  MAC_PIB_BEACON_ORDER_DEFAULT                     = MAC_PIB_BEACON_ORDER_MAX,
  MAC_PIB_BEACON_TX_TIME_DEFAULT                   = 0,
  MAC_PIB_COORD_SHORT_ADDR_DEFAULT                 = 0xFFFF,
  MAC_PIB_GTS_PERMIT_DEFAULT                       = TRUE,
  MAC_PIB_MAX_CSMA_BACKOFFS_MAX                    = 5,
  MAC_PIB_MAX_CSMA_BACKOFFS_DEFAULT                = 4,
  MAC_PIB_MIN_BE_MAX                               = 3,
  MAC_PIB_MIN_BE_DEFAULT                           = MAC_PIB_MIN_BE_MAX,
  MAC_PIB_PANID_DEFAULT                            = 0xFFFF,
  MAC_PIB_PROMISCUOUS_MODE_DEFAULT                 = FALSE,
  MAC_PIB_RX_ON_WHEN_IDLE_DEFAULT                  = FALSE,
  MAC_PIB_SHORT_ADDR_DEFAULT                       = 0xFFFF,
  MAC_PIB_SUPERFRAME_ORDER_MAX                     = 15, 
  MAC_PIB_SUPERFRAME_ORDER_DEFAULT                 = MAC_PIB_SUPERFRAME_ORDER_MAX,
  MAC_PIB_TRANSACTION_PERSISTENCE_TIME_DEFAULT     = 0x01F4,
  // The default value of own extAddr in according with standart is unknown 
  // but it is needed to initialize it for matching with RF chip extAddr registers value.
  MAC_PIB_EXT_ADDR_DEFAULT                         = 0,
  MAC_PIB_CCA_MODE_DEFAULT                         = PHY_DEFAULT_CCA_MODE,
  MAC_PIB_TX_POWER_DEFAULT                         = PHY_DEFAULT_TX_POWER,
};

/******************************************************************************
  MAC PIB type.
  IEEE802.15.4 table - 71.
******************************************************************************/
typedef struct
{
  //uint8_t               ackWaitDuration;      // This parameter managing through MLME_SAP_SETrequest is switched off
                                                // in current realization - raed only. Actually this parameter value is 
                                                // defined by hardware.
  bool                  associationPermit;  
  //bool                  autoRequest;          // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  //bool                  battLifeExt;          // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  //uint8_t               battLifeExtPeriods;   // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  uint8_t*              beaconPayload;      
  uint8_t               beaconPayloadLength; 
  //uint8_t               beaconOrder;          // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  //uint32_t              beaconTxTime;         // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  uint8_t               bsn;
  MACExtAddr            coordExtAddr;
  MACShortAddr          coordShortAddr;
  uint8_t               dsn;
  bool                  gtsPermit;
  uint8_t               maxCSMABackoffs;
  uint8_t               minBE;
  MACPANId              panId;
#ifdef _SENS_TEST
  bool                  promiscuousMode;       // This parameter's managing through MLME_SAP_SETrequest is switched off
                                               // in current realization - raed only. Promiscuous mode management is NOT
                                               // implemented.
#endif //_SENS_TEST
  bool                  rxOnWhenIdle;
  MACShortAddr          shortAddr;
  MACExtAddr            extAddr;                // Additional parameter. NOT described in the standard.
                                                // This parameter replaces MAC_EXTENDED_ADDRESS constant.
                                                // Device own extended address.
  //uint8_t               superframeOrder;      // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  uint16_t              transactionPersistenceTime;
  PHYCCAMode            CCAMode;                // Additional parameter. NOT described in the standard.
                                                // Mode of the CCA algorithm.
  int8_t                txPower;                // Additional parameter. NOT described in the standard.
                                                // Transmit power.
} PACK MACPIBType;

/******************************************************************************
  MAC PIB attribute type.
  IEEE802.15.4 table - 71.
******************************************************************************/
typedef union
{
  uint8_t               ackWaitDuration;        // This parameter managing through MLME_SAP_SETrequest is switched off
                                                // in current realization - raed only. Actually this parameter value is 
                                                // defined by hardware.
  bool                  associationPermit;  
  //bool                  autoRequest;          // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented. 
  //bool                  battLifeExt;          // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  //uint8_t               battLifeExtPeriods;   // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  uint8_t*              beaconPayload;
  uint8_t               beaconPayloadLength;
  uint8_t               beaconOrder;
  //uint32_t              beaconTxTime;         // This parameter managing through MLME_SAP_SET/GETrequest is switched off.
                                                // NOT used - superframe functionality is not implemented.
  uint8_t               bsn;
  MACExtAddr            coordExtAddr;
  MACShortAddr          coordShortAddr;
  uint8_t               dsn;
  bool                  gtsPermit;
  uint8_t               maxCSMABackoffs;
  uint8_t               minBE;
  MACPANId              panId;
  bool                  promiscuousMode;
  bool                  rxOnWhenIdle;
  MACShortAddr          shortAddr;
  MACExtAddr            extAddr;                   // Additional parameter. NOT described in the standard.
                                                   // This parameter replaces MAC_EXTENDED_ADDRESS constant.
                                                   // Device own extended address.
  uint8_t               superframeOrder;
  uint16_t              transactionPersistenceTime;
  PHYCCAMode            CCAMode;                  // Additional parameter. NOT described in the standard. 
                                                  // Mode of the CCA algorithm.
  int8_t                txPower;                  // Additional parameter. NOT described in the standard.
                                                  // Transmit power.
} MACPIBAttr;

/******************************************************************************
  MAC address mode types.
  IEEE802.15.4 table - 66.
******************************************************************************/
typedef enum
{
  MAC_NO_ADDR_MODE    = 0x00,
  MAC_RSRV_ADDR_MODE  = 0x01,
  MAC_SHORT_ADDR_MODE = 0x02,
  MAC_EXT_ADDR_MODE   = 0x03
} MACAddrMode;

/******************************************************************************
  MAC address. 
******************************************************************************/
typedef union
{
  MACShortAddr sh;
  MACExtAddr ext;
} MACAddr;

/******************************************************************************
  MAC TxOptions.
  IEEE802.15.4 table - 27.
******************************************************************************/
typedef enum
{
  MAC_ACK_TXOPTION      = 0x01,
  MAC_GTS_TXOPTION      = 0x02,
  MAC_INDIRECT_TXOPTION = 0x04,
  MAC_SECURE_TXOPTION   = 0x08
} MACTxOptions;

/******************************************************************************
  Diassociation reasons.
  IEEE802.15.4 table - 69.
******************************************************************************/
typedef enum
{
  MAC_COORDINATOR_WISHES_DEVICE_LEAVE_PAN_REASON = 0x01,
  MAC_DEVICE_WISHES_LEAVE_PAN_REASON             = 0x02,
} DeassociationReason;

/******************************************************************************
  Superframe specification.
  IEEE802.15.4 figure - 40.
******************************************************************************/
typedef struct
{
  uint16_t beaconOrder       : 4;
  uint16_t superframeOrder   : 4;
  uint16_t finalSlot         : 4;
  uint16_t battLifeExt       : 1;
  uint16_t reserved          : 1;
  uint16_t panCoordinator    : 1;
  uint16_t associationPermit : 1;
} MACSuperframeSpecification;

/******************************************************************************
  PAN descriptor.
  IEEE802.15.4 table - 41.
******************************************************************************/
typedef struct
{
  MACAddrMode                coordAddrMode;
  MACPANId                   coordPANId;
  MACAddr                    coordAddr;
  uint8_t                    channel;
  MACSuperframeSpecification superframeSpecification;
  bool                       gtsPermit;
  uint8_t                    quality;
  int8_t                     rssi;                    // Additional parameter (NOT described in the standard)
                                                      // RSSI value while beacon frame receiving procedure.
  uint32_t                   timeStamp;
  //bool                     securityEnable;          // Not used. Security functionality not implemented.
  //uint8_t                  ACLEntry;                // Not used. Security functionality not implemented.
  //bool                     SecurityFailure          // NOT used. Security functionality not implemented.
} PACK PANDescriptor;

/******************************************************************************
  MAC scanning procedure type.
  IEEE802.15.4 table - 54.
******************************************************************************/
typedef enum
{
  MAC_ED_SCAN      = 0x00,
  MAC_ACTIVE_SCAN  = 0x01,
  MAC_PASSIVE_SCAN = 0x02,
  MAC_ORPHAN_SCAN  = 0x03
} MACScanType;

/******************************************************************************
  Pending address specification fields.
  IEEE802.15.4 figure - 44.
******************************************************************************/
typedef struct
{
  uint8_t shortAddr : 3;
  uint8_t reserved  : 1;
  uint8_t extAddr   : 3;
} MACPendingAddressSpecification;

/******************************************************************************
  MAC capability information field.
  IEEE802.15.4 figure - 49.
******************************************************************************/
typedef struct
{
  uint8_t alternatePANCoordinator : 1;
  uint8_t deviceType              : 1;
  uint8_t powerSource             : 1;
  uint8_t rxOnWhenIdle            : 1;
  uint8_t reserved                : 2;
  uint8_t securityCapability      : 1;
  uint8_t allocateAddress         : 1;
} MACCapabilityInformation;

/******************************************************************************
  Energy level type.
******************************************************************************/
typedef uint8_t PHYEnergyLevel;

/******************************************************************************
  Params and status of DATA request.
  IEEE802.15.4 table - 27.
******************************************************************************/
typedef struct
{
  MACAddrMode  srcAddrMode;
  MACPANId     srcPANId;
  MACAddr      srcAddr;
  MACAddrMode  dstAddrMode;
  MACPANId     dstPANId;
  MACAddr      dstAddr;
  uint8_t      msduLength; // Data payload length.
  uint8_t*     msdu;       // Data payload buffer.
  uint8_t      msduHandle;
  MACTxOptions txOptions;
  MACStatus    status;     // Additional parameter (not described in the standard).
                           // Status of request operation.
                           // Should be analyzed only after DATAconfirm event.
} PACK MACDataParams;

/******************************************************************************
  Params and status of DATA request.
  IEEE802.15.4 table - 28.
******************************************************************************/
typedef struct // Params of DATA indication.
{
  MACAddrMode srcAddrMode;
  MACPANId    srcPANId;
  MACAddr     srcAddr;
  MACAddrMode dstAddrMode;
  MACPANId    dstPANId;
  MACAddr     dstAddr;
  uint8_t     msduLength;    // Data payload length.
  uint8_t*    msdu;          // Data payload.
  uint8_t     quality;
  int8_t      rssi;
} PACK MACDataIndParams;

/******************************************************************************
  Params of SET/GET requests and confirms.
  IEEE802.15.4 table - 56.
******************************************************************************/
typedef struct
{
  MACPIBId   id;
  MACPIBAttr attr;
  MACStatus  status; // Additional parameter (not described in the standard).
                     // Status of request operation.
                     // Should be analyzed only after SET/GET confirm event.
} PACK MACPIBParam;

/******************************************************************************
  Params of ASSOCIATE request.
  IEEE802.15.4 table - 33.
******************************************************************************/
typedef struct
{
  uint8_t                  channel;
  MACAddrMode              coordAddrMode;
  MACPANId                 coordPANId;
  MACAddr                  coordAddr;
  MACCapabilityInformation capability;
  //bool      securityEnable; // Not used. Security functionality not implemented.
} PACK MACAssociateReqParams;

/******************************************************************************
  Params of ASSOCIATE confirm.
  IEEE802.15.4 table - 36.
******************************************************************************/
typedef struct
{
  MACShortAddr shortAddr;
  MACStatus    status;
} PACK MACAssociateConfParams;

/******************************************************************************
  Params of ASSOCIATE indication.
  IEEE802.15.4 table - 34.
******************************************************************************/
typedef struct
{
  MACExtAddr                  extAddr;
  MACCapabilityInformation    capability;
  //bool     securityEnable; // Not used. Security functionality not implemented.
  //uint8_t  ACLEntry;       // Not used. Security functionality not implemented.
} PACK MACAssociateIndParams;

/******************************************************************************
  Params of ASSOCIATE response.
  IEEE802.15.4 table - 35.
******************************************************************************/
typedef struct
{
  MACExtAddr   extAddr;
  MACShortAddr shortAddr;
  MACStatus    status;
  //bool       securityEnable; // Not used. Security functionality not implemented.
  uint8_t*     msdu;           // Buffer for outgoing frame.
                               // (operation through transactions queue).
} PACK MACAssociateRespParams;

/******************************************************************************
  Params of COMM_STATUS indication.
  IEEE802.15.4 table - 55.
******************************************************************************/
typedef struct
{
  MACPANId    panId;
  MACAddrMode srcAddrMode;
  MACAddr     srcAddr;
  MACAddrMode dstAddrMode;
  MACAddr     dstAddr;
  MACStatus   status;
} PACK MACCommStatusIndParams;

/******************************************************************************
  Params and status of DISASSOCIATE request.
  IEEE802.15.4 table - 37.
******************************************************************************/
typedef struct
{
  MACExtAddr          extAddr;
  MACShortAddr        shortAddr;      // Additional parameter (not described in the standard).
                                      // Short address of the device that should be disassociated.
  DeassociationReason reason;
  uint8_t*            msdu;           // Buffer for outgoing frame, when coordinator inits operation.
                                      // (operation through transactions queue)
  //bool              securityEnable; // Not used. Security functionality not implemented.
  MACStatus           status;         // Additional parameter (not described in the standard).
                                      // Status of request operation.
                                      // Should be analyzed only after DISASSOCIATEconfirm event.
} PACK MACDisassociateReqParams;

/******************************************************************************
  Params of DISASSOCIATE indication event.
  IEEE802.15.4 table - 38.
******************************************************************************/
typedef struct
{
  MACExtAddr          extAddr;
  DeassociationReason reason;
  //bool              securityEnable; // Not used. Security functionality not implemented.
  //uint8_t           ACLEntry;       // Not used. Security functionality not implemented.
} PACK MACDisassociateIndParams;

/******************************************************************************
  Params of BEACON indication.
  IEEE802.15.4 table - 40.
******************************************************************************/
typedef struct
{
  uint8_t                        bsn;
  PANDescriptor                  panDescriptor;
  MACPendingAddressSpecification pendAddrSpecification;
  MACAddr*                       pendAddrList[MAC_PENDING_ADDRESS_MAX];
  uint8_t                        msduLength;                            // Beacon payload length.
  uint8_t*                       msdu;                                  // Beacon payload.
} PACK MACBeaconIndParams;

/******************************************************************************
  Params of ORPHAN indication.
  IEEE802.15.4 table - 47.
******************************************************************************/
typedef struct
{
  MACExtAddr extAddr;
  //bool     securityEnable; // Not used. Security functionality not implemented.
  //uint8_t  ACLEntry;       // Not used. Security functionality not implemented.
} PACK MACOrphanIndParams;

/******************************************************************************
  Params of ORPHAN response.
  IEEE802.15.4 table - 48.
******************************************************************************/
typedef struct
{
  MACExtAddr   extAddr;
  MACShortAddr shortAddr;
  bool         associate;
  //bool       securityEnable; // Not used. Security functionality not implemented.
} PACK MACOrphanRespParams;

/******************************************************************************
  Params and status of RX_ENABLE request.
  IEEE802.15.4 table - 51.
******************************************************************************/
typedef struct
{
  //bool      deferPermit;  // NOT used - superframe functionality is not implemented.
  //uint32_t  rxOnTime;     // NOT used - superframe functionality is not implemented.
  uint32_t  rxOnDuration;
  MACStatus status;         // Additional parameter (not described in the standard).
                            // Status of request operation.
                            // Should be analyzed only after MLME_SAP_RX_ENABLEconfirm event.
} PACK MACRxEnableParams;

/******************************************************************************
  Scanning results union.
******************************************************************************/
typedef union // SCAN result.
{
  PHYEnergyLevel* energy;
  PANDescriptor*  panDescriptor;
} PACK MACScanResult;

/******************************************************************************
  Params of SCAN request.
  IEEE802.15.4 table - 53.
******************************************************************************/
typedef struct
{
  MACScanType   type;
  uint32_t      channels;
  uint8_t       duration;
  uint8_t       maxResultSize; // Additional parameter (not described in the standard).
                               // Max number of scan results.
  MACScanResult result;        // Additional parameter (not described in the standard).
                               // Space to store scan procedure results (allocated by
                               // user's application).
} PACK MACScanReqParams;

/******************************************************************************
  Params of SCAN confirm.
  IEEE802.15.4 table - 54.
******************************************************************************/
typedef struct
{
  MACStatus       status;
  //MACScanType   type;              // Not implemented.
  uint32_t        unScannedChannels;
  uint8_t         resultSize;
  //MACScanResult result;            // The list of PAN descriptors is allocated by
                                     // application and pointer to this list should
                                     // be passed to MAC in MLME_SAP_SCANrequest params.
} PACK MACScanConfParams;

/******************************************************************************
  Params and status of START request.
  IEEE802.15.4 table - 58.
******************************************************************************/
typedef struct 
{
  MACPANId  panId;
  uint8_t   channel;
  //uint8_t   beaconOrder;     // NOT used - superframe functionality is not implemented.
  //uint8_t   superframeOrder; // NOT used - superframe functionality is not implemented.
  bool      panCoordinator;
  //bool      batteryLifeExt;  // NOT used - superframe functionality is not implemented.
  bool      coordRealignment;
  //bool    securityEnable;    // Not used. Security functionality not implemented.
  MACStatus status;            // Additional parameter (not described in the standard).
                               // Executing status of start procedure.
                               // Should be analyzed after STARTconfirm event.
} PACK MACStartParams;

/******************************************************************************
  Params and status of POLL request.
  IEEE802.15.4 table - 62.
******************************************************************************/
typedef struct
{
  MACAddrMode coordAddrMode;
  MACPANId    coordPANId;
  MACAddr     coordAddr;
  //bool      securityEnable; // Not used. Security functionality not implemented.
  MACStatus   status;         // Additional parameter (not described in the standard).
                              // Executing status of start procedure.
                              // Should be analyzed after POLLconfirm event.
} PACK MACPollParams;

/******************************************************************************
  MAC frame types.
******************************************************************************/
typedef enum
{
  MAC_BEACON_TYPE,
  MAC_DATA_TYPE,
  MAC_ASSOCIATION_RESPONSE_COMMAND_TYPE,
  MAC_DISASSOCIATION_NOTIFICATION_COMMAND_TYPE,
} MACFrameType;

/******************************************************************************
  MAC frames descriptor.
******************************************************************************/
typedef struct // Parameters of the frame for header and footer lengths getting.
{
  MACFrameType type; // Type of frame.
  union
  {
    MACStartParams*           beacon;
    MACDataParams*            data;
    MACAssociateRespParams*   association_response;
    MACDisassociateReqParams* disassociation_request;
  } params;
  uint8_t header; // Header length.
  uint8_t footer; // Footer length.
} PACK MACFrameParams;

/******************************************************************************
  MAC GTS direction types.
  IEEE802.15.4 paragraph - 7.3.3.1.2.
******************************************************************************/
typedef enum
{
  MAC_GTS_DIRECTION_TRANSMIT = 0,
  MAC_GTS_DIRECTION_RECEIVE  = 1
} MACGTSDirection;

/******************************************************************************
  MAC GTS types.
******************************************************************************/
typedef enum
{
  MAC_GTS_TYPE_DEALLOCATE = 0,
  MAC_GTS_TYPE_ALLOCATE   = 1
} MACGTSType;

/******************************************************************************
  MAC GTS characteristics.
  IEEE802.15.4 figure - 58.
******************************************************************************/
typedef struct
{
  uint8_t    length : 4;
  uint8_t direction : 1;
  uint8_t      type : 1;
  uint8_t  reserved : 2;
} PACK MACGTSCharacteristics;

/******************************************************************************
  Params and status of GTS request.
  IEEE802.15.4 table - 44.
  NOT used - superframe functionality is not implemented.
******************************************************************************/
/*typedef struct
{
  MACGTSCharacteristics characteristics;
  MACStatus status;
} PACK MACGTSReqParams;*/

/******************************************************************************
  Params of GTS indication.
  IEEE802.15.4 table - 46.
  NOT used - superframe functionality is not implemented.
******************************************************************************/
/*typedef struct
{
  MACShortAddr shortAddr;
  MACGTSCharacteristics characteristics;
} PACK MACGTSIndParams;*/

/******************************************************************************
  Some MAC frames' sizes, PHY header (1 byte - length) included .
******************************************************************************/
enum
{
  //IEEE802.15.4 paragraph - 7.3.2.5
  MAC_COORDINATOR_REALIGNMENT_COMMAND_LENGTH_MAX = 31 + 1,
  //IEEE802.15.4 paragraph - 7.2.2.1
  MAC_BEACON_HEADER_LENGTH_MAX                   = 96 + 1,
  //IEEE802.15.4 paragraph - 7.2.2.2
  MAC_DATA_HEADER_LENGTH_MAX                     = 23 + 1,
  //IEEE802.15.4 paragraph - 7.3.1.2
  MAC_ASSOCIATION_RESPONSE_LENGTH                = 27 + 1,
  //IEEE802.15.4 paragraph - 7.3.1.3
  MAC_DISASSOCIATION_REQUEST_LENGTH              = 25 + 1,
};

#endif

// eof MAC.h
