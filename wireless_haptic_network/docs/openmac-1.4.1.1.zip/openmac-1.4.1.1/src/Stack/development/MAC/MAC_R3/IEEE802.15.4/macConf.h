/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: macConf.h
  Created: AKokhonovskiy 2005.
  Description: Configuration constants declaration.
  Copyright: (c)Meshnetics.
********************************************************************************/

#ifndef _MAC_CONF_H
#define _MAC_CONF_H

enum
{
  MAC_RESET_ID,
  MAC_SCAN_ID,
  MAC_ASSOCIATION_ID,
  MAC_RX_ENABLE_ID,
  MAC_ORPHAN_ID,
  MAC_START_ID,
  MAC_POLL_ID,
  MAC_DATA_ID,
  MAC_DISASSOCIATION_ID,
  MAC_PAN_SERVER_ID,
  MAC_GTS_ID,

  PHY_MUTEX                 = unique("Mutex"),
  PHY_RX_MUTEX              = unique("PHY_MUTEX"),
  PHY_MAC_RESET_MUTEX       = unique("PHY_MUTEX"),
  PHY_MAC_SET_MUTEX         = unique("PHY_MUTEX"),
  PHY_MAC_GET_MUTEX         = unique("PHY_MUTEX"),
  PHY_MAC_START_MUTEX       = unique("PHY_MUTEX"),
  PHY_MAC_SYNC_MUTEX        = unique("PHY_MUTEX"),
  PHY_MAC_SCAN_MUTEX        = unique("PHY_MUTEX"),
  PHY_MAC_ASSOCIATION_MUTEX = unique("PHY_MUTEX"),
  PHY_MAC_SERVER_MUTEX      = unique("PHY_MUTEX"),
  PHY_PAN_SERVER_MUTEX      = unique("PHY_MUTEX"),

  MAC_SERVER_MUTEX     = unique("Mutex"),
  MAC_SERVER_IND_MUTEX = unique("MAC_SERVER_MUTEX"),
  MAC_SERVER_REQ_MUTEX = unique("MAC_SERVER_MUTEX"),

  PAN_SERVER_MUTEX     = unique("Mutex"),
  PAN_SERVER_INTERN_REQ_MUTEX     = unique("PAN_SERVER_MUTEX"),
  PAN_SERVER_EXTERN_REQ_MUTEX     = unique("PAN_SERVER_MUTEX"),
};

#endif

// eof macConf.h
