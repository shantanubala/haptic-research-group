/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: macGTS.h
  Created: AKokhonovskiy 2005.
  Description: Type and constants declarations for GTS management.
  Copyright: (c)Meshnetics.
********************************************************************************/

#ifndef _GTS_H_
#define _GTS_H_

  typedef struct // GTS element description.
  {
    bool                    empty; // Presence flag.
    MACGTSDescription description; // Description.
    MACGTSDirection     direction; // Direction.
    uint8_t             unuseTime; // Number of superframe, when the GTS has unused.
  } GTSElement;

  typedef struct // GTS specification for beacon.
  {
    uint8_t           persistCounter; // Presence in beacon.
    MACGTSDescription    description; // Description.
    MACGTSDirection        direction; // Direction.
  } GTSSpecification;

#endif //_GTS_H_
// eof macGTS.h

