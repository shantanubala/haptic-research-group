/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/******************************************************************************
  File: MACWrapper.h
  Created: ALuzhetsky January 2007.
  Description: file contains MAC function declarations and their renaming.
  Copyright: (c)Meshnetics.
*******************************************************************************/


#ifndef _MAC_WRAPPER_H
#define _MAC_WRAPPER_H

/******************************************************************************
---------------------  MLME_SAP functions declarations  -----------------------
******************************************************************************/

/******************************************************************************
  Request initiates start procedure.
  params - params of start and status of operation.
  Returns: SUCCESS, if request has been accepted for processing,FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.14.1
******************************************************************************/
result_t MACM__MLME_SAP__STARTrequest(MACStartParams* params);

#define MLME_STARTrequest MACM__MLME_SAP__STARTrequest


/******************************************************************************
  Notifies that start procedure was executed.
  Status of operation should be analyzed from MACStartParams
    (MLME_SAP_STARTrequest procedure)
  IEEE802.15.4 paragraph: 7.1.14.2
******************************************************************************/
void MACWrapperM__MLME_SAP__STARTconfirm();

#define MLME_STARTconfirm MACWrapperM__MLME_SAP__STARTconfirm

/******************************************************************************
  Request initiates the disassociation procedure.
  params - params of diassociation.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.4.1
******************************************************************************/
result_t MACM__MLME_SAP__DISASSOCIATErequest(MACDisassociateReqParams* params);

#define MLME_DISASSOCIATErequest MACM__MLME_SAP__DISASSOCIATErequest


/******************************************************************************
  Notifies that disassociation request has been completed.
  addr - additional parameter (not described in the IEEE standard),
    extended address of the node whose disassociation procedure was finished.
  Status of operation should be analyzed from MACDisassociateReqParams
    (MLME_SAP_DISASSOCIATErequest procedure)
  IEEE802.15.4 paragraph: 7.1.4.3
******************************************************************************/
void MACWrapperM__MLME_SAP__DISASSOCIATEconfirm(MACExtAddr *addr);

#define MLME_DISASSOCIATEconfirm MACWrapperM__MLME_SAP__DISASSOCIATEconfirm

  
/******************************************************************************
  Notifies, that disassociation request has been received.
  params - params of diassociation.
  IEEE802.15.4 paragraph: 7.1.4.2
******************************************************************************/
void MACWrapperM__MLME_SAP__DISASSOCIATEindication(MACDisassociateIndParams *params);

#define MLME_DISASSOCIATEindication MACWrapperM__MLME_SAP__DISASSOCIATEindication


/******************************************************************************
  Requests poll operation.
  params - params and status of operation.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.16.1
******************************************************************************/
result_t MACM__MLME_SAP__POLLrequest(MACPollParams* params);

#define MLME_POLLrequest MACM__MLME_SAP__POLLrequest


/******************************************************************************
  Notifies that poll request has been completed.
  Status of operation should be analyzed from MACPollParams 
    (MLME_SAP_POLLrequest procedure)
  IEEE802.15.4 paragraph: 7.1.16.2
******************************************************************************/
void MACWrapperM__MLME_SAP__POLLconfirm();

#define MLME_POLLconfirm MACWrapperM__MLME_SAP__POLLconfirm


/******************************************************************************
  Notifies that data request (poll) has been received.
  shortAddr - ahort address of the device which sent data request.
  IEEE802.15.4 paragraph: not specified (extra functionality implemented 
    by Meshnetics).
  This event could be ignored.
******************************************************************************/
void MACWrapperM__MLME_SAP__POLLindication(MACShortAddr shortAddr);

#define MLME_POLLindication MACWrapperM__MLME_SAP__POLLindication


/******************************************************************************
  Requests the association with the coordinator.
  reqParams - request params.
  confParams - confirm params - additional parameter (not described in the 
               standard). Space for ASSOCIATEconfirm parameters - should be 
               allocated before ASSOCIATErequest by user's application.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.3.1
******************************************************************************/
result_t MACM__MLME_SAP__ASSOCIATErequest(MACAssociateReqParams *reqParams, MACAssociateConfParams *confParams);

#define MLME_ASSOCIATErequest MACM__MLME_SAP__ASSOCIATErequest


/******************************************************************************
  Notifies that association request has been completed.
  Pointer to confirm parameters was passed while MLME_SAP_ASSOCIATErequest
    procedure, now confirm parameters could be analyzed.
  IEEE802.15.4 paragraph: 7.1.3.4
******************************************************************************/
void MACWrapperM__MLME_SAP__ASSOCIATEconfirm();

#define MLME_ASSOCIATEconfirm MACWrapperM__MLME_SAP__ASSOCIATEconfirm


/******************************************************************************
  Notifies that association request has been received.
  params - indication params.
  IEEE802.15.4 paragraph: 7.1.3.2
******************************************************************************/
void MACWrapperM__MLME_SAP__ASSOCIATEindication(MACAssociateIndParams *params);

#define MLME_ASSOCIATEindication MACWrapperM__MLME_SAP__ASSOCIATEindication


/******************************************************************************
  Responses to an ASSOCIATEindication.
  params - params of association response.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.3.3
******************************************************************************/
result_t MACM__MLME_SAP__ASSOCIATEresponse(MACAssociateRespParams* associateResponceParams);

#define MLME_ASSOCIATEresponse MACM__MLME_SAP__ASSOCIATEresponse


/******************************************************************************
  Requests reset operation of MAC layer.
  setDefaultPIB - if TRUE, all MAC PIB attributes are set to their default values.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.9.1
******************************************************************************/
result_t MACM__MLME_SAP__RESETrequest(bool setDefaultPIB);

 #define MLME_RESETrequest MACM__MLME_SAP__RESETrequest


/******************************************************************************
  Reports about the result of processing reset operation.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.9.2
******************************************************************************/
void MACWrapperM__MLME_SAP__RESETconfirm(MACStatus status);

#define MLME_RESETconfirm MACWrapperM__MLME_SAP__RESETconfirm


/******************************************************************************
  Request enables the receiver.
  !Meshnetics behaviour correction. Set params->rxOnDuration to zero to switch
    the receiver off... or to non zero value to enable it.
  params - params and status of operation.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.10.1
******************************************************************************/
result_t MACM__MLME_SAP__RX_ENABLErequest(MACRxEnableParams* params);

#define MLME_RX_ENABLErequest MACM__MLME_SAP__RX_ENABLErequest


/******************************************************************************
  Notifies that TRX enable request has been completed.
  Status of operation should be analyzed from MACRxEnableParams 
    (MLME_SAP_RX_ENABLErequest procedure)
  IEEE802.15.4 paragraph: 7.1.10.2
******************************************************************************/
void MACWrapperM__MLME_SAP__RX_ENABLEconfirm();

#define MLME_RX_ENABLEconfirm MACWrapperM__MLME_SAP__RX_ENABLEconfirm


/******************************************************************************
  Requests scan operation.
  reqParams - params of operation.
  confParams - confirm params - additional parameter (not described in the 
               standard). Space for SCANconfirm parameters - should be 
               allocated before SCANrequest by user's application.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.11.1
******************************************************************************/
result_t MACM__MLME_SAP__SCANrequest(MACScanReqParams *scanReqParams, MACScanConfParams *scanConfParams);

#define MLME_SCANrequest MACM__MLME_SAP__SCANrequest


/******************************************************************************
  Reports about the result of the scan operation.
  Scanning procedure results were passed among MLME_SAP_SCANrequest parameters.
  Scanning procedure results could be analyzed now.
  IEEE802.15.4 paragraph: 7.1.11.2
******************************************************************************/
void MACWrapperM__MLME_SAP__SCANconfirm();

#define MLME_SCANconfirm MACWrapperM__MLME_SAP__SCANconfirm


/******************************************************************************
  Notifies, that presence of an orphan device.
  params - params of orphan device.
  IEEE802.15.4 paragraph: 7.1.8.1
******************************************************************************/
void MACWrapperM__MLME_SAP__ORPHANindication(MACOrphanIndParams *params);

#define MLME_ORPHANindication MACWrapperM__MLME_SAP__ORPHANindication


/******************************************************************************
  Responses to an ORPHANindication.
  respParams - params of orphan device.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.8.2
******************************************************************************/
result_t MACM__MLME_SAP__ORPHANresponse(MACOrphanRespParams *params);

 #define MLME_ORPHANresponse MACM__MLME_SAP__ORPHANresponse


/******************************************************************************
  Indicates synchronization loss.
  reason - reason of synchronization loss.
  IEEE802.15.4 paragraph: 7.1.15.2
******************************************************************************/
void MACWrapperM__MLME_SAP__SYNC_LOSSindication(MACStatus reason);

#define MLME_SYNC_LOSSindication MACWrapperM__MLME_SAP__SYNC_LOSSindication
 
 
/******************************************************************************
  Indicates communication status.
  params - communication status parameters.
  IEEE802.15.4 paragraph: 7.1.12.1
******************************************************************************/
void MACWrapperM__MLME_SAP__COMM_STATUSindication(MACCommStatusIndParams *params);

#define MLME_COMM_STATUSindication MACWrapperM__MLME_SAP__COMM_STATUSindication


/******************************************************************************
  Notifies, that beacon has been received.
  params - params of beacon.
  IEEE802.15.4 paragraph: 7.1.5.1
******************************************************************************/
void MACWrapperM__MLME_SAP__BEACONindication(MACBeaconIndParams *params);

#define MLME_BEACON_NOTIFYindication MACWrapperM__MLME_SAP__BEACONindication


/******************************************************************************
  Writes attribute to MAC PIB.
  param - param and status of operation.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.13.1
******************************************************************************/
result_t MACM__MLME_SAP_SET__request(MACPIBParam *params);

#define MLME_SETrequest MACM__MLME_SAP_SET__request


/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam 
    (MLME_SAP_SETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.13.2
******************************************************************************/
void MACWrapperM__MLME_SAP_SET__confirm();

#define MLME_SETconfirm MACWrapperM__MLME_SAP_SET__confirm


/******************************************************************************
  Reads attribute from MAC PIB.
  param - param and status of operation.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.6.1
******************************************************************************/
result_t MACM__MLME_SAP_GET__request(MACPIBParam *params);

#define MLME_GETrequest MACM__MLME_SAP_GET__request


/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam 
    (MLME_SAP_GETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.6.2
******************************************************************************/
void MACWrapperM__MLME_SAP_GET__confirm();

#define MLME_GETconfirm MACWrapperM__MLME_SAP_GET__confirm

/******************************************************************************
-------------  MLEM_SAP functionality which NOT implemented!  -----------------
******************************************************************************/
/******************************************************************************
  Starts beacon tracking on channel.
  If trackBeacon = FALSE, synchronize with only next beacon.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 
******************************************************************************/
/*result_t MACM__MLME_SAP__SYNCrequest(uint8_t channel, bool trackBeacon);

#define MLME_SYNCrequest MACM__MLME_SAP__SYNCrequest*/


/******************************************************************************
  Requests to allocate/deallocate GTS.
  params - params of GTS request and status of operation.
  Returns: SUCCESS, if request has been accepted for processing, FAIL otherwise.        
  IEEE802.15.4 paragraph: 7.1.7.1
******************************************************************************/
/*result_t MACM__MLME_SAP__GTSrequest(MACGTSReqParams *params);

#define MLME_GTSrequest MACM__MLME_SAP__GTSrequest*/


/******************************************************************************
  Notify that GTS request has been completed.
  IEEE802.15.4 paragraph: 7.1.7.2
******************************************************************************/
/*void MACWrapperM__MLME_SAP__GTSconfirm();

#define MLME_GTSconfirm MACWrapperM__MLME_SAP__GTSconfirm*/


/******************************************************************************
  Notifies, that request to allocate/deallocate GTS has arrived.
  params - params of GTS request.
  IEEE802.15.4 paragraph: 7.1.7.3
******************************************************************************/
/*void MACWrapperM__MLME_SAP__GTSindication(MACGTSIndParams *params);

#define MLME_GTSindication MACWrapperM__MLME_SAP__GTSindication*/



/******************************************************************************
--------------------  MCPS_SAP functions declarations  ------------------------
******************************************************************************/

/******************************************************************************
  Requests the transfer of MSDU.
  params - params and status of operation.
  Returns: SUCCESS, if request was accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.1.1
******************************************************************************/
result_t MACM__MCPS_SAP__DATArequest(MACDataParams *params);

#define MCPS_DATArequest MACM__MCPS_SAP__DATArequest


/******************************************************************************
  Notifies that MSDU with the handle has been transfered.
  Status of operation should be analyzed from MACDataParams 
    (MCPS_SAP_DATArequest procedure)
  IEEE802.15.4 paragraph: 7.1.1.2
******************************************************************************/
void MACWrapperM__MCPS_SAP__DATAconfirm(uint8_t handle);

#define MCPS_DATAconfirm MACWrapperM__MCPS_SAP__DATAconfirm


/******************************************************************************
  Notifies that data frame has been recieved.
  indParams - params of received data frame.
  IEEE802.15.4 paragraph: 7.1.1.3
******************************************************************************/
void MACWrapperM__MCPS_SAP__DATAindication(MACDataIndParams *indParams);

#define MCPS_DATAindication MACWrapperM__MCPS_SAP__DATAindication


/******************************************************************************
  Purges MSDU from transaction queue.
  msduHandle - handle id of MSDU.
  Returns: SUCCESS, if request was accepted for processing, FAIL otherwise.
  IEEE802.15.4 paragraph: 7.1.1.4
******************************************************************************/
result_t MACM__MCPS_SAP__PURGErequest(uint8_t msduHandle);

#define MCPS_PURGErequest MACM__MCPS_SAP__PURGErequest
  

/******************************************************************************
  Notifies that MSDU has been purged from transaction queue.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.1.5
******************************************************************************/
void MACWrapperM__MCPS_SAP__PURGEconfirm(MACStatus status);

#define MCPS_PURGEconfirm MACWrapperM__MCPS_SAP__PURGEconfirm
  


/******************************************************************************
-------------------  MAC controlling functions declarations  ------------------
       Auxiliary functions. NOT described in the standard.
******************************************************************************/

/******************************************************************************
  Initializes MAC layer.
  This function should be called before any other MAC primitives.
  Returns: SUCCESS, if request was accepted for processing, FAIL otherwise.
******************************************************************************/
result_t MACM__MACControl__init(void);

#define MAC_init MACM__MACControl__init


/******************************************************************************
  Notifies that MAC layer was initialized.
******************************************************************************/
result_t MACWrapperM__MACControl__initDone(void);

#define MAC_initDone MACWrapperM__MACControl__initDone


/******************************************************************************
  Starts MAC layer.
  This function should be called after MAC_init function but before any other 
  MAC primitives.
  Returns: SUCCESS, if request was accepted for processing, FAIL otherwise.
******************************************************************************/
result_t MACM__MACControl__start(void);

#define MAC_start MACM__MACControl__start


/******************************************************************************
  Notifies that MAC layer was started.
******************************************************************************/
result_t MACWrapperM__MACControl__startDone(void);

#define MAC_startDone MACWrapperM__MACControl__startDone


/******************************************************************************
  Stops MAC layer.
  Returns: SUCCESS, if request was accepted for processing, FAIL otherwise.
******************************************************************************/
result_t MACM__MACControl__stop(void);

#define MAC_stop MACM__MACControl__stop


/******************************************************************************
  Notifies that MAC layer was stoped.
******************************************************************************/
result_t MACWrapperM__MACControl__stopDone(void);

#define MAC_stopDone MACWrapperM__MACControl__stopDone



/******************************************************************************
-------------------  MSRV_SAP functions declarations  -------------------------
           Additional auxiliary SAP. NOT described in the standard.
******************************************************************************/

/******************************************************************************
  Returns length of header and length of footer for the frame.
******************************************************************************/
void MACM__MSRV_SAP__getAffixLength(MACFrameParams *params);

#define MSRV_getAffixLength MACM__MSRV_SAP__getAffixLength

/******************************************************************************
  Notifies that hardware error has occured.
******************************************************************************/
void MACWrapperM__MSRV_SAP__hardwareError(void);

#define MSRV_hardwareError MACWrapperM__MSRV_SAP__hardwareError


/******************************************************************************
---------  Auxiliary functions only for the sensitivity tester  --------------
******************************************************************************/
/******************************************************************************
  Notifies that frame was received. CRC checking and address filtering
  procedures were not performed.
  data - pointer to the received data.
  nextLQI - LQI of the received frame.
  nextRSSI - RSSI of the received frame.
******************************************************************************/
void MACWrapperM__sensTestAuxilary__frameReceiveDone(uint8_t *data, uint8_t nextLQI, uint8_t nextRSSI);

#define sensTestAuxilary_frameReceiveDone MACWrapperM__sensTestAuxilary__frameReceiveDone

/******************************************************************************
  Sends data.
  data - pointer to the frame buffer;
  status - status of operation.
  Returns: void.
******************************************************************************/
void HPLIEEE802_15_4M__sensTestAuxilary__sendFrame(uint8_t* data, MACStatus* status);

#define sensTestAuxilary_sendFrame HPLIEEE802_15_4M__sensTestAuxilary__sendFrame

/******************************************************************************
  Notifies, that frame was sent.
******************************************************************************/
void MACWrapperM__sensTestAuxilary__sendFrameDone();

#define sensTestAuxilary_sendFrameDone MACWrapperM__sensTestAuxilary__sendFrameDone

#endif //_MAC_WRAPPER_H

// eof MACWrapper.h
