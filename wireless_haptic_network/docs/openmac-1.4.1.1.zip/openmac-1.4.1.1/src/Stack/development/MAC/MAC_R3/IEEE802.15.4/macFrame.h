/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: macFrame.h
  Created: AKokhonovskiy 2005.
  Description: Types and constants declaration of IEEE802.15.4 MAC frame.
  Copyright: (c)Meshnetics.
********************************************************************************/

#ifndef _MAC_FRAME_H
#define _MAC_FRAME_H

#include "MAC.h"

enum // Indexes of fields of frame.
{
  MAC_LENGTH_FRAME       = 0, // Length.
  MAC_CONTROL_FRAME_LOW  = 1, // The least significant part of control field.
  MAC_CONTROL_FRAME_HIGH = 2, // The most significant part of control field.
  MAC_DSN_FRAME          = 3, // Data sequence number.
};

typedef struct // Frame control.
{
  uint16_t type         : 3;
  uint16_t security     : 1;
  uint16_t framePending : 1;
  uint16_t ack          : 1;
  uint16_t intraPAN     : 1;
  uint16_t reserved1    : 3;
  uint16_t dstAddrMode  : 2;
  uint16_t reserved2    : 2;
  uint16_t srcAddrMode  : 2;
} MACFrameControl;

enum
{
  MAC_ACK_LENGTH = 5, // ACK frame length, no including length field.
};

typedef enum // Code of frame.
{
  MAC_BEACON_CODE                              = 0x00,
  MAC_DATA_CODE                                = 0x01,
  MAC_ACK_CODE                                 = 0x02,
  MAC_COMMAND_CODE                             = 0x03,
  MAC_ASSOCIATION_REQUEST_COMMAND_CODE         = 0x01,
  MAC_ASSOCIATION_RESPONSE_COMMAND_CODE        = 0x02,
  MAC_DISASSOCIATION_NOTIFICATION_COMMAND_CODE = 0x03,
  MAC_DATA_REQUEST_COMMAND_CODE                = 0x04,
  MAC_PANID_CONFLICT_NOTIFICATION_COMMAND_CODE = 0x05,
  MAC_ORPHAN_NOTIFICATION_COMMAND_CODE         = 0x06,
  MAC_BEACON_REQUEST_COMMAND_CODE              = 0x07,
  MAC_COORDINATOR_REALIGNMENT_COMMAND_CODE     = 0x08,
  MAC_GTS_REQUEST_COMMAND_CODE                 = 0x09,
} MACFrameCode;

typedef enum // Type of frame.
{
  MAC_NO_FRAME,
  MAC_BEACON,
  MAC_DATA,
  MAC_ACK,
  MAC_COMMAND,
  MAC_ASSOCIATION_REQUEST_COMMAND,
  MAC_ASSOCIATION_RESPONSE_COMMAND,
  MAC_DISASSOCIATION_NOTIFICATION_COMMAND,
  MAC_DATA_REQUEST_COMMAND,
  MAC_PANID_CONFLICT_NOTIFICATION_COMMAND,
  MAC_ORPHAN_NOTIFICATION_COMMAND,
  MAC_BEACON_REQUEST_COMMAND,
  MAC_COORDINATOR_REALIGNMENT_COMMAND,
  MAC_GTS_REQUEST_COMMAND,
} MACFrame;

typedef struct // GTS specification.
{
  uint8_t count    : 3;
  uint8_t reserved : 4;
  uint8_t permit   : 1;
} MACGTSSpecification;

typedef struct // GTS description.
{
  MACShortAddr shortAddr;
  struct
  {
    uint8_t startSlot : 4;
    uint8_t length    : 4;
  };
} MACGTSDescription;

typedef struct // Description of beacon MAC payload and current channel.
{
  uint32_t                       timeStamp;
  uint8_t                        channel;
  MACSuperframeSpecification     superframeSpecification;
  MACGTSSpecification            gtsSpecification;
  MACGTSDirection                gtsDirection;
  MACGTSDescription*             gtsList[MAC_GTS_MAX];
  MACPendingAddressSpecification pendAddrSpecification;
  MACAddr*                       pendAddrList[MAC_PENDING_ADDRESS_MAX];
} MACBeaconDescription;

typedef struct // Description of associate request command MAC payload.
{
  MACCapabilityInformation capability;
} MACAssociationRequestDescription;

typedef struct // Description of associate response command MAC payload.
{
  MACShortAddr shortAddr;
  uint8_t      status;
} MACAssociationResponseDescription;

typedef struct // Description of diassociate notification command MAC payload.
{
  uint8_t reason;
} MACDisassociationNotificationDescription;

typedef struct // Description of coordinator realignment command MAC payload.
{
  MACPANId panId;
  MACShortAddr coordShortAddr;
  uint8_t channel;
  MACShortAddr shortAddr;
} MACCoordinatorRealignmentDescription;

typedef struct
{
  MACFrame        type;
  MACFrameControl frameControl;
  uint8_t         dsn;
  MACPANId        dstPANId;
  MACAddr         dstAddr;
  MACPANId        srcPANId;
  MACAddr         srcAddr;
  union
  {
    MACBeaconDescription                     beacon;
    MACAssociationRequestDescription         associationRequest;
    MACAssociationResponseDescription        associationResponse;
    MACDisassociationNotificationDescription disassociationNotification;
    MACCoordinatorRealignmentDescription     coordinatorRealignment;
    MACGTSCharacteristics                    gtsCharacteristics;
  } payload;
  
  uint8_t*        msdu;       // MSDU.
  uint8_t         msduLength; // MSDU length.
  uint8_t         quality;    // Link quality of incoming frame.
  int8_t          rssi;       // rssi of incoming frame.
  bool            gts;        // GTS flag. For outgoing data frames only.
} MACFrameDescription;

enum // Constants of superframe specification field of beacon frame.
{
  MAC_SFS_MASK                  = 0x000F,
  MAC_SUPERFRAME_ORDER_SFS_DISP = 0x4,
  MAC_FINAL_CAP_SLOT_SFS_DISP   = 0x8,
  MAC_BATTERY_LIFE_EXT_SFS      = 0x1000,
  MAC_PAN_COORDINATOR_SFS       = 0x4000,
  MAC_ASSOCIATION_PERMIT_SFS    = 0x8000
};

#endif

// eof macFrame.h
