

#include <sched.h>
/*#include <avrhardware.h>
#include <hardware.h>*/


void appEntry__main();

#ifdef _NO_USER_APP_
void appEntry__main()
{
	return ;
};
#endif /* _NO_USER_APP_ */

int main()
{

	TOSH_sched_init();
	HAL_main();
	/*provided by application*/
	TOS_post(appEntry__main);
	/*TOS_post(user__main);*/
    while (1)
    {
    	//TOSH_run_next_task();
		TOSH_run_task();
    };
	/* Test scheduler*/
    return 0;
};

