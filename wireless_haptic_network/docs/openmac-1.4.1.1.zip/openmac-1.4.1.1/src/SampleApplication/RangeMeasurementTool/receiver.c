/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: receiver.c
  Created: ALuzhetsky January 2007.
  Description: receive part of the RangeMeasurmentTool.
  Copyright: (c)Meshnetics.
********************************************************************************/

#include "MAC.h"
#include "MACWrapper.h"
#include "uid.h"
#include "leds.h"
#include "uart.h"
#include "buttons.h"
#include "apptimer.h"
#include "sched.h"
#ifdef _RCB_PLATFORM
#include "spircb.h"
#endif //_RCB_PLATFORM


enum
{
  IDLE_STATE,
  SET_RX_ON_WHEN_IDLE_STATE,
  SET_SHORT_ADDR_STATE,
  SET_MIN_BE_STATE,
  SET_PROMISCUOUS_MODE_STATE,
  SET_RX_ENABLE_STATE,
} state = IDLE_STATE; // Application current state.

enum
{
  FRAME_COUNTER_OUT_STATE,
  FRAME_ERROR_COUNTER_OUT_STATE,
  BIT_ERROR_COUNTER_OUT_STATE,
  LQI_OUT_STATE,
  RSSI_OUT_STATE,
} uartState; // UART current state.

union
{
  MACPIBParam macPIB;
  MACRxEnableParams rxEnable;
  MACStartParams start;
} params; // Parameters for the MAC layer procedures.

enum
{
  BAD_FRAMERATE      = 50,                     // Minimum rate of the incomming frames.
  MIN_RSSI_VALUE     = 89,                     // Minimum RSSI value (described in the AT86RF230 datasheet).
  BUFFER_DATA_LENGTH = MAX_PHY_PACKET_SIZE + 1,// PSP buffer length.
};

uint8_t  timerId;                    // Application timer handle.
uint8_t  channel             = 0;    // Current channel.
uint8_t  changeChannel       = 0xFF; // Channel to switch.
bool     firstButtonState    = TRUE; // Indicates first button state.
uint32_t bitErrorCounter     = 0;    // Counter of the error bits.
uint32_t frameErrorCounter   = 0;    // Counter of the error frames.
uint32_t frameCounter        = 0;    // Counter of the received frames.
int32_t  lastFrameCounter    = 0;    // Frame counter for the last second.
int32_t  lastFrameErrCounter = 0;    // Error frame counter for the last second.
int8_t   timer_50msec;	              // Timer counter modulo 50 msec.
int8_t   timer_500msec;              // Timer counter modulo 500 msec.
uint8_t  outputCounter       = 0;    // Counter of the bytes sent through UART.
uint8_t  stringLength        = 0;    // Length of the string to send through UART.
int16_t  avaragedLQI         = 0;    // Stores avarage value of frames link quality.
int16_t  avaragedRSSI        = 0;    // Stores avarage value of frames RSSI value.
uint16_t outLQI              = 0;    // LQI value which should be sent through UART.
uint16_t outRSSI             = 0;    // RSSI value which should be sent through UART.
uint8_t  decStrBuf[50];              // Buffer for messages converting.
bool     bad;  		                    // Bad conditions: very bad frame rate !
uint8_t  byteToUART;                 // Next byte to send through uart.
uint8_t  PSPData[BUFFER_DATA_LENGTH];// Pseudorandom sequence buffer.
const uint8_t bitCalcBuf[16] = {0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4};


/****************************************************************************
  Functions declarations
****************************************************************************/
void released( uint8_t bn);
void pressed( uint8_t bn);
void timerFired(void);
#ifndef _RCB_PLATFORM    
  void UARTsend(void);
#else //_RCB_PLATFORM    
  void SPIsend(void);
#endif //_RCB_PLATFORM    
void nextByteToSend(void);
/****************************************************************************
  Auxilary functions.
****************************************************************************/
/****************************************************************************
  Updates leds.
****************************************************************************/
void updateLeds()
{
  // Set leds according to the channel.
  if (channel & 0x01)
    leds_on(LED_GREEN);
  else
    leds_off(LED_GREEN);
  if (channel & 0x02)
    leds_on(LED_YELLOW);
  else
    leds_off(LED_YELLOW);
  if (channel & 0x04)
    leds_on(LED_RED);
  else
    leds_off(LED_RED);
}
  
#ifndef _RCB_PLATFORM    
/****************************************************************************
  Tryes to send byte through UART.
****************************************************************************/
void UARTsend(void)
{
  if(uart_put(USART_CHANNEL1, &byteToUART, 1) == FAIL)
    TOS_post(UARTsend);
  else
    TOS_post(nextByteToSend);
}
#else //_RCB_PLATFORM    
/****************************************************************************
  Sends byte through SPI.
****************************************************************************/
void SPIsend(void)
{
  spi_rcb_select();
  spi_rcb_write(decStrBuf[outputCounter]);
  spi_rcb_deselect();
  TOS_post(nextByteToSend);
}
#endif //_RCB_PLATFORM    

/******************************************************************************
  Fills buffer by PSP.
******************************************************************************/ 
uint8_t PSPNextBit( uint16_t *shiftReg )
{
  uint16_t mask = 0xC001;

  if( *shiftReg & 0x0001 )
  {
    *shiftReg = ( (*shiftReg ^ mask) >> 1) | 0x8000;
    return 1;
  }
  else
  {
    *shiftReg >>= 1;
    return 0;
  }
}

/******************************************************************************
  Fills buffer by PSP.
******************************************************************************/ 
void PSPCalculation()
{
  uint8_t i, j;
  uint16_t shiftReg = 0x7418; //just some digits
  
  for( i = 0; i < BUFFER_DATA_LENGTH; i++ )
  {
    for( j = 0; j < 8; j++ )
    {
      if( PSPNextBit(&shiftReg) )
        PSPData[i] = (PSPData[i] >> 1) | 0x80;
      else
        PSPData[i] = (PSPData[i] >> 1);
      
    }
  }
  
}

/******************************************************************************
  Comparing frame with original PSP.
******************************************************************************/ 
uint16_t frameCompare(uint8_t *frame)
{
  uint8_t  i;
  uint8_t  tmp;
  uint16_t errorCounter = 0;
  
  if(frame[0] != 127)
    return 64*8;
    
  for( i = 1; i < frame[0] - 2 + 1/*-CRC+length*/; i++)
  {
    tmp = frame[i]^PSPData[i];
    if(tmp != 0)
      errorCounter += bitCalcBuf[tmp&0x0f] + bitCalcBuf[tmp>>4];
  }
  //CRC
  tmp = frame[i] ^ 0x6F;
  if( tmp )
  {
      errorCounter += bitCalcBuf[tmp&0x0f] + bitCalcBuf[tmp>>4];
  }
  tmp = frame[i + 1] ^ 0x37;
  if( tmp )
  {
      errorCounter += bitCalcBuf[tmp&0x0f] + bitCalcBuf[tmp>>4];
  }
  return errorCounter;
}




/******************************************************************************
  Main entry point for the user application.
******************************************************************************/
void appEntry__main()
{
#ifndef _RCB_PLATFORM    
  {
    UARTMode_t uartMode;
  
    // UART settings.
    uartMode.baudrate = UART_BAUDRATE_38400;
    uartMode.data = UART_DATA8;
    uartMode.parity = UART_PARITY_NONE;
    uartMode.stopbits = UART_STOPBITS2;
    uartMode.flowControl.ctsControl = FALSE;
    uartMode.flowControl.rtsControl = FALSE; 
    uartMode.flowControl.dtrControl = FALSE;
    // UART configuring.
    uart_setConfig(USART_CHANNEL1, &uartMode);
    // UART openning.
    uart_open(USART_CHANNEL1);
  }
#else //_RCB_PLATFORM    
  {
    spi_rcb_init();
  }
#endif //_RCB_PLATFORM    
  // Buttons openning.
  buttons_open(&pressed, &released);
  // Leds openning.
  leds_open();
  // Application timer openning.
  timerId = appTimer_open(timerFired);
  // Pseudorandom sequence calculation.
  PSPCalculation();
  // MAC initing.
  MAC_init();
}


/******************************************************************************
---------------------------  Auxiliary functions  ----------------------------
******************************************************************************/

/******************************************************************************
---------------------  MAC Control callback functions  ------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MAC layer was initialized.
******************************************************************************/
result_t MAC_initDone(void)
{
  // MAC starting.
  MAC_start();
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was started.
******************************************************************************/
result_t MAC_startDone(void)
{
  MLME_RESETrequest(TRUE);
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was stoped.
******************************************************************************/
result_t MAC_stopDone(void)
{
  return SUCCESS;
}
  


/******************************************************************************
-----------------------  MCPS callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MSDU with the handle has been transfered.
  Status of operation should be analyzed from MACDataParams (MCPS_DATArequest procedure)
  IEEE802.15.4 paragraph: 7.1.1.2
******************************************************************************/
void MCPS_DATAconfirm(uint8_t handle)
{
}

/******************************************************************************
  Notifies that data frame has been recieved.
  indParams - params of received data frame.
  IEEE802.15.4 paragraph: 7.1.1.3
******************************************************************************/
void MCPS_DATAindication(MACDataIndParams* params)
{
}

/******************************************************************************
  Notifies that MSDU has been purged from transaction queue.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.1.5
******************************************************************************/
void MCPS_PURGEconfirm(MACStatus status)
{
}
  

/******************************************************************************
-----------------------  MLME callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that disassociation request has been completed.
  addr - additional parameter (not described in the IEEE standard),
    extended address of the node whose disassociation procedure was finished.
  Status of operation should be analyzed from MACDisassociateReqParams (MLME_DISASSOCIATErequest procedure)
  IEEE802.15.4 paragraph: 7.1.4.3
******************************************************************************/
void MLME_DISASSOCIATEconfirm(MACExtAddr *addr)
{
}

/******************************************************************************
  Notifies, that disassociation request has been received.
  params - params of diassociation.
  IEEE802.15.4 paragraph: 7.1.4.2
******************************************************************************/
void MLME_DISASSOCIATEindication(MACDisassociateIndParams *param)
{
}

/******************************************************************************
  Indicates synchronization loss.
  reason - reason of synchronization loss.
  IEEE802.15.4 paragraph: 7.1.15.2
******************************************************************************/
void MLME_SYNC_LOSSindication(MACStatus status)
{
}

/******************************************************************************
  Notifies that poll request has been completed.
  Status of operation should be analyzed from MACPollParams (MLME_POLLrequest procedure)
  IEEE802.15.4 paragraph: 7.1.16.2
******************************************************************************/
void MLME_POLLconfirm(void)
{
}

/******************************************************************************
  Notifies that start procedure was executed.
  Status of operation should be analyzed from MACStartParams (MLME_STARTrequest procedure)
  IEEE802.15.4 paragraph: 7.1.14.2
******************************************************************************/
void MLME_STARTconfirm(void)
{
  timer_50msec = timer_500msec = 0;
  updateLeds();
  appTimer_start(timerId, TIMER_REPEAT_MODE, 50); 
}

/******************************************************************************
  Reports about the result of the scan operation.
  Scanning procedure results were passed among MLME_SCANrequest parameters.
  Scanning procedure results could be analyzed now.
  IEEE802.15.4 paragraph: 7.1.11.2
******************************************************************************/
void MLME_SCANconfirm(void)
{
}

/******************************************************************************
  Notifies that data request (poll) has been received.
  shortAddr - ahort address of the device which sent data request.
  IEEE802.15.4 paragraph: not specified (extra functionality implemented by Meshnetics).
  This event could be ignored.
******************************************************************************/
void MLME_POLLindication(MACShortAddr shortAddr)
{
}

/******************************************************************************
  Notifies that association request has been received.
  params - indication params.
  IEEE802.15.4 paragraph: 7.1.3.2
******************************************************************************/
void MLME_ASSOCIATEindication(MACAssociateIndParams* associateIndParams)
{
}

/******************************************************************************
  Notifies that association request has been completed.
  Pointer to confirm parameters was passed while MLME_ASSOCIATErequest
    procedure, now confirm parameters could be analyzed.
  IEEE802.15.4 paragraph: 7.1.3.4
******************************************************************************/
void MLME_ASSOCIATEconfirm(void)
{
}

/******************************************************************************
  Reports about the result of processing reset operation.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.9.2
******************************************************************************/
void MLME_RESETconfirm(MACStatus status)
{
  state = SET_RX_ON_WHEN_IDLE_STATE;
  params.macPIB.id = MAC_PIB_RX_ON_WHEN_IDLE_ID;
  params.macPIB.attr.rxOnWhenIdle = TRUE;
  MLME_SETrequest(&params.macPIB);
}

/******************************************************************************
  Indicates communication status.
  params - communication status parameters.
  IEEE802.15.4 paragraph: 7.1.12.1
******************************************************************************/
void MLME_COMM_STATUSindication(MACCommStatusIndParams* commStatusParams)
{
}

/******************************************************************************
  Notifies, that beacon has been received.
  params - params of beacon.
  IEEE802.15.4 paragraph: 7.1.5.1
******************************************************************************/
void MLME_BEACON_NOTIFYindication(MACBeaconIndParams *params)
{
}

/******************************************************************************
  Notifies that TRX enable request has been completed.
  Status of operation should be analyzed from MACRxEnableParams (MLME_RX_ENABLErequest procedure)
  IEEE802.15.4 paragraph: 7.1.10.2
******************************************************************************/
void MLME_RX_ENABLEconfirm(void)
{
  params.start.panId = 0xDADA;
  channel = APP_START_CHANNEL - PHY_MIN_CHANNEL;
  while (!((1UL << (channel + PHY_MIN_CHANNEL)) & CHANNEL_MASK))
   channel = (channel + 1) & 0x0F;
  params.start.channel = channel + PHY_MIN_CHANNEL;
  params.start.panCoordinator = TRUE;
  params.start.coordRealignment = FALSE;
  MLME_STARTrequest(&params.start);
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_GETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.6.2
******************************************************************************/
void MLME_GETconfirm(void)
{
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_SETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.13.2
******************************************************************************/
void MLME_SETconfirm(void)
{
    switch (state)
    {
      case SET_RX_ON_WHEN_IDLE_STATE:
           state = SET_MIN_BE_STATE;
           params.macPIB.id = MAC_PIB_MIN_BE_ID;
           params.macPIB.attr.minBE = 0;
           break;
    
      case SET_MIN_BE_STATE:
           state = SET_SHORT_ADDR_STATE;
           params.macPIB.id = MAC_PIB_SHORT_ADDR_ID;
           params.macPIB.attr.shortAddr = 0xADAD;
           break;
        
      case SET_SHORT_ADDR_STATE:
           params.macPIB.id = MAC_PIB_PROMISCUOUS_MODE_ID;
           params.macPIB.attr.promiscuousMode = TRUE;
           state = SET_PROMISCUOUS_MODE_STATE;
           break;

      case SET_PROMISCUOUS_MODE_STATE:
           state = SET_RX_ENABLE_STATE;
           params.rxEnable.rxOnDuration = 1;
           MLME_RX_ENABLErequest(&params.rxEnable); 
           return;

      default:
        while(1);
    }
    MLME_SETrequest(&params.macPIB);
}

/******************************************************************************
  Notifies, that presence of an orphan device.
  params - params of orphan device.
  IEEE802.15.4 paragraph: 7.1.8.1
******************************************************************************/
void MLME_ORPHANindication(MACOrphanIndParams *a)
{
}


/******************************************************************************
-----------------------  MSRV callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that hardware error has occured.
******************************************************************************/
void MSRV_hardwareError(void)
{
}


/******************************************************************************
---------  Auxiliary functions only for the RangeMeasurmentTool  --------------
******************************************************************************/
/******************************************************************************
  Notifies that frame was received. CRC checking and address filtering
  procedures were not performed.
  data - pointer to the received data.
  nextLQI - LQI of the received frame.
  nextRSSI - RSSI of the received frame.
******************************************************************************/
void sensTestAuxilary_frameReceiveDone(uint8_t *data, uint8_t nextLQI, uint8_t nextRSSI)
{
  int16_t  tmpLQI;
  int16_t  tmpRSSI;
  uint16_t tmpErrors;

  tmpLQI = nextLQI;
  avaragedLQI = avaragedLQI - ( (avaragedLQI - (tmpLQI << 7) ) >> 5 );
  outLQI = avaragedLQI >> 7;
  if(outLQI > 255)
    outLQI = 255;

  tmpRSSI = nextRSSI;
  avaragedRSSI = avaragedRSSI - ( (avaragedRSSI - (tmpRSSI << 7) ) >> 5 );
  outRSSI = avaragedRSSI >> 4;
  if(outRSSI > 255)
    outRSSI = 255;

  frameCounter++; 
  tmpErrors = frameCompare(data);
  if(tmpErrors)
  {
    frameErrorCounter ++;
    bitErrorCounter += tmpErrors;
  }
}

/******************************************************************************
  Notifies, that frame was sent.
******************************************************************************/
void sensTestAuxilary_sendFrameDone()
{
}
/******************************************************************************
  Buttons events handlers.
******************************************************************************/

/******************************************************************************
  Button was pressed.
******************************************************************************/
void pressed(uint8_t bn)
{
  if(bn == 1)
  {
    firstButtonState    = FALSE;
    bitErrorCounter     = 0;
    frameErrorCounter   = 0;
    frameCounter        = 0;
    lastFrameCounter    = 0;
    lastFrameErrCounter = 0;
  }
  else
  {
    do
    {
      channel = (channel + 1) & 0x0F;
    }
    while (!((1UL << (channel + PHY_MIN_CHANNEL)) & CHANNEL_MASK));
    changeChannel = channel;
  }
}

/******************************************************************************
  Button was released.
******************************************************************************/
void released( uint8_t bn)
{
  if(bn == 1)
    firstButtonState = TRUE;
}

/******************************************************************************
Timer fired callback function.
******************************************************************************/
void timerFired()
{
  if (changeChannel!=0xFF)
  {
    channel = changeChannel;
    changeChannel = 0xFF;
    //-------------------------------------
    // Set leds according to the channel.
    //-------------------------------------
    params.start.channel = channel + PHY_MIN_CHANNEL;
    MLME_STARTrequest(&params.start);
    return;
  }
  // Sw timers.
  timer_50msec++;
  if (timer_50msec >= 10)
  {
    timer_50msec = 0;
    timer_500msec++;
  }
  // periodical UART output.
  if (timer_50msec == 0)
  {
    uartState = FRAME_COUNTER_OUT_STATE;
    outputCounter = 0;
    stringLength = sprintf((char *)decStrBuf, "FC=%-12lu", frameCounter);
    byteToUART = decStrBuf[outputCounter];
#ifndef _RCB_PLATFORM    
    UARTsend();
#else //_RCB_PLATFORM    
    SPIsend();
#endif //_RCB_PLATFORM    
    updateLeds();
  }
  //-------------------------------
  // check bad conditions once per second.
  //-------------------------------
  if (timer_50msec == 0 && (timer_500msec & 1) == 0)
  {
    int16_t nFrames = (int16_t)(frameCounter - lastFrameCounter);
    int16_t nErr    = (int16_t)(frameErrorCounter - lastFrameErrCounter);
    lastFrameCounter = frameCounter;
    lastFrameErrCounter = frameErrorCounter;
    bad = (nFrames < BAD_FRAMERATE) || ((nErr<<2)>nFrames);
  }
  //-------------------------------
  // bad indicate bad conditions.
  //-------------------------------
  if (bad && firstButtonState)
  {
    if (timer_50msec & 1)
    {
      leds_on(LED_GREEN);
      leds_on(LED_YELLOW);
      leds_on(LED_RED);
    }
    else
    {
      leds_off(LED_GREEN);
      leds_off(LED_YELLOW);
      leds_off(LED_RED);
    }
  }
  //----------------------------------------
  // indicate generation mode: 
  // green, yellow, red,
  //----------------------------------------
  if ((timer_500msec&7)==0)
  {	
    register uint8_t timer = timer_50msec;
    switch(timer)
    {
    case 0:
    case 4:
      leds_on (LED_GREEN); 
      leds_off(LED_YELLOW); 
      leds_off(LED_RED);
      break;
    case 1:
    case 3:
      leds_off(LED_GREEN); 
      leds_on (LED_YELLOW); 
      leds_off(LED_RED);
      break;
    case 2:
      leds_off(LED_GREEN); 
      leds_off(LED_YELLOW); 
      leds_on (LED_RED);
      break;
    }
  }
}

/******************************************************************************
  Defines next byte to send and initiates transmission procedure.
******************************************************************************/ 
void nextByteToSend()
{
  switch( uartState )
  {
    case FRAME_COUNTER_OUT_STATE:
         outputCounter++;
         if( outputCounter >= stringLength )
         {
           uartState = FRAME_ERROR_COUNTER_OUT_STATE;
           outputCounter = 0;
           stringLength = sprintf((char *)decStrBuf, "FEC=%-12lu", frameErrorCounter);
         }
         break;

    case FRAME_ERROR_COUNTER_OUT_STATE:
         outputCounter++;
         if( outputCounter >= stringLength )
         {
           uartState = BIT_ERROR_COUNTER_OUT_STATE;
           outputCounter = 0;
           stringLength = sprintf((char *)decStrBuf, "BEC=%-12lu", bitErrorCounter);
         }
         break;

    case BIT_ERROR_COUNTER_OUT_STATE:
         outputCounter++;
         if( outputCounter >= stringLength )
         {
           uartState = LQI_OUT_STATE;
           outputCounter = 0;
           stringLength = sprintf((char *)decStrBuf, "LQI=%-8d", outLQI);
         }
         break;

    case LQI_OUT_STATE:
         {
           uint16_t tmpRSSI;
    
           outputCounter++;
           if( outputCounter >= stringLength )
           {
             uartState = RSSI_OUT_STATE;
             outputCounter = 0;
             tmpRSSI = ((MIN_RSSI_VALUE << 3) - (outRSSI*3))>>3;
             stringLength = sprintf((char *)decStrBuf, "RSSI=-%02ddBm(%02d)\n\r", tmpRSSI, outRSSI>>3);
           }
         }
         break;

    case RSSI_OUT_STATE:
         outputCounter++;
         if( outputCounter >= stringLength )
          return;
         break;
  }
  byteToUART = decStrBuf[outputCounter];
#ifndef _RCB_PLATFORM    
  UARTsend();
#else //_RCB_PLATFORM    
  SPIsend();
#endif //_RCB_PLATFORM    
}

// eof receiver.c
