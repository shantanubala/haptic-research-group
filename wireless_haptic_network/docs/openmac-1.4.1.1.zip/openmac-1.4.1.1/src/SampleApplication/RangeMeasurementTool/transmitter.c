/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: transmitter.c
  Created: ALuzhetsky January 2007.
  Description: transmit part of the RangeMeasurmentTool.
  Copyright: (c)Meshnetics.
********************************************************************************/

#include "sched.h"
#include "MAC.h"
#include "MACWrapper.h"
#include "uid.h"
#include "leds.h"
#include "uart.h"
#include "buttons.h"
#include "sliders.h"
#include "apptimer.h"
#include "at86rf230.h"
#ifdef _RCB_PLATFORM
#include "spircb.h"
#endif //_RCB_PLATFORM

enum
{
  IDLE_STATE,
  SET_RX_ON_WHEN_IDLE_STATE,
  SET_MIN_BE_STATE,
  SET_SHORT_ADDR_STATE,
  SET_TX_POWER_STATE,
} state = IDLE_STATE; // Application current state.

enum
{
  BUFFER_DATA_LENGTH = MAX_PHY_PACKET_SIZE + 1, // PSP buffer length.
  NPACKETS	          = 10000,	                  // number of packets to generate
  MIN_DATA_PERIOD    = 6,
};

union
{
  MACPIBParam macPIB;
  MACRxEnableParams rxEnable;
  MACStartParams start;
} params; // Parameters for the MAC layer procedures.
  
struct
{
  uint8_t   PSPData[BUFFER_DATA_LENGTH]; // Pseudorandom sequence buffer.
  MACStatus dataReqStatus;               // Status of data request operation.
} dataParam; // Describes parameters for special RangeMeasurmentTool data request.

uint8_t  timerId;                   // Application timer handle.
uint8_t  dataDelayTimerId;          // Handle of the timer to increase data period. 
int8_t   timer_50msec     = 0;	     // Time in 50 msec intervals.
int8_t   timer_500msec    = 0;      // Time in 500 msec intervals.
uint8_t  channel          = 0;      // Current channel.
bool     changeChannel    = TRUE;   // Indicates necessity to switch channel.
int16_t  Npacket2Tx       = 0x7FFF;	// Number of packets to be sent.
uint32_t sentFrameCounter = 0;      // Counter of the frames which were sent.
uint8_t  outputCounter    = 0;      // Counter of the bytes sent through UART.
uint8_t  stringLength     = 0;      // Length of the string to send through UART.
uint8_t  decStrBuf[50];             // Buffer for messages converting.



/****************************************************************************
  Functions declarations
****************************************************************************/
void released(uint8_t bn);
void pressed(uint8_t bn);
void timerFired(void);
void dataDelayTimerFired(void);
#ifndef _RCB_PLATFORM    
  void UARTsend(void);
#else //_RCB_PLATFORM    
  void SPIsend(void);
#endif //_RCB_PLATFORM    

/****************************************************************************
  Auxilary functions.
****************************************************************************/

/******************************************************************************
 sending the data packet or just reposting 
******************************************************************************/ 
void sendPacket()
{
  if(Npacket2Tx > 0)
  {
    //call MCPS.DATArequest(&dataParams);
    sensTestAuxilary_sendFrame(dataParam.PSPData, &dataParam.dataReqStatus);
  }
  else
  {
    TOS_post(sendPacket);
  }
}

/******************************************************************************
  Fills buffer by PSP.
******************************************************************************/ 
uint8_t PSPNextBit( uint16_t *shiftReg )
{
  uint16_t mask = 0xC001;

  if( *shiftReg & 0x0001 )
  {
    *shiftReg = ( (*shiftReg ^ mask) >> 1) | 0x8000;
    return 1;
  }
  else
  {
    *shiftReg >>= 1;
    return 0;
  }
}

/******************************************************************************
  Fills buffer by PSP.
******************************************************************************/ 
void PSPCalculation()
{
  uint8_t i, j;
  uint16_t shiftReg = 0x7418; //just some digits
  
  for( i = 0; i < BUFFER_DATA_LENGTH; i++ )
  {
    for( j = 0; j < 8; j++ )
    {
      if( PSPNextBit(&shiftReg) )
        dataParam.PSPData[i] = (dataParam.PSPData[i] >> 1) | 0x80;
      else
        dataParam.PSPData[i] = (dataParam.PSPData[i] >> 1);
      
    }
  }
  dataParam.PSPData[0] = MAX_PHY_PACKET_SIZE;
}

/******************************************************************************
  Main entry point for the user application.
******************************************************************************/
void appEntry__main()
{
#ifndef _RCB_PLATFORM    
  {
    UARTMode_t uartMode;
  
    // UART settings.
    uartMode.baudrate = UART_BAUDRATE_38400;
    uartMode.data = UART_DATA8;
    uartMode.parity = UART_PARITY_NONE;
    uartMode.stopbits = UART_STOPBITS2;
    uartMode.flowControl.ctsControl = FALSE;
    uartMode.flowControl.rtsControl = FALSE; 
    uartMode.flowControl.dtrControl = FALSE;
    // UART configuring.
    uart_setConfig(USART_CHANNEL1, &uartMode);
    // UART openning.
    uart_open(USART_CHANNEL1);
  }
#else //_RCB_PLATFORM    
  {
    spi_rcb_init();
  }
#endif //_RCB_PLATFORM    

  // Application timer openning.
  dataDelayTimerId = appTimer_open(dataDelayTimerFired);
  // Buttons openning.
  buttons_open(&pressed, &released);
  // Leds openning.
  leds_open();
  // Application timer openning.
  timerId = appTimer_open(timerFired);
  // Pseudorandom sequence calculation.
  PSPCalculation();
  // MAC initing.
  MAC_init();
}


/******************************************************************************
---------------------------  Auxiliary functions  ----------------------------
******************************************************************************/

/******************************************************************************
---------------------  MAC Control callback functions  ------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MAC layer was initialized.
******************************************************************************/
result_t MAC_initDone(void)
{
  // MAC starting.
  MAC_start();
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was started.
******************************************************************************/
result_t MAC_startDone(void)
{
  MLME_RESETrequest(TRUE);
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was stoped.
******************************************************************************/
result_t MAC_stopDone(void)
{
  return SUCCESS;
}
  


/******************************************************************************
-----------------------  MCPS callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MSDU with the handle has been transfered.
  Status of operation should be analyzed from MACDataParams (MCPS_DATArequest procedure)
  IEEE802.15.4 paragraph: 7.1.1.2
******************************************************************************/
void MCPS_DATAconfirm(uint8_t handle)
{
}

/******************************************************************************
  Notifies that data frame has been recieved.
  indParams - params of received data frame.
  IEEE802.15.4 paragraph: 7.1.1.3
******************************************************************************/
void MCPS_DATAindication(MACDataIndParams* params)
{
}

/******************************************************************************
  Notifies that MSDU has been purged from transaction queue.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.1.5
******************************************************************************/
void MCPS_PURGEconfirm(MACStatus status)
{
}
  

/******************************************************************************
-----------------------  MLME callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that disassociation request has been completed.
  addr - additional parameter (not described in the IEEE standard),
    extended address of the node whose disassociation procedure was finished.
  Status of operation should be analyzed from MACDisassociateReqParams (MLME_DISASSOCIATErequest procedure)
  IEEE802.15.4 paragraph: 7.1.4.3
******************************************************************************/
void MLME_DISASSOCIATEconfirm(MACExtAddr *addr)
{
}

/******************************************************************************
  Notifies, that disassociation request has been received.
  params - params of diassociation.
  IEEE802.15.4 paragraph: 7.1.4.2
******************************************************************************/
void MLME_DISASSOCIATEindication(MACDisassociateIndParams *param)
{
}

/******************************************************************************
  Indicates synchronization loss.
  reason - reason of synchronization loss.
  IEEE802.15.4 paragraph: 7.1.15.2
******************************************************************************/
void MLME_SYNC_LOSSindication(MACStatus status)
{
}

/******************************************************************************
  Notifies that poll request has been completed.
  Status of operation should be analyzed from MACPollParams (MLME_POLLrequest procedure)
  IEEE802.15.4 paragraph: 7.1.16.2
******************************************************************************/
void MLME_POLLconfirm(void)
{
}

/******************************************************************************
  Notifies that start procedure was executed.
  Status of operation should be analyzed from MACStartParams (MLME_STARTrequest procedure)
  IEEE802.15.4 paragraph: 7.1.14.2
******************************************************************************/
void MLME_STARTconfirm(void)
{
  appTimer_start(timerId, TIMER_REPEAT_MODE, 50); 
  changeChannel = FALSE;
  sendPacket();
}

/******************************************************************************
  Reports about the result of the scan operation.
  Scanning procedure results were passed among MLME_SCANrequest parameters.
  Scanning procedure results could be analyzed now.
  IEEE802.15.4 paragraph: 7.1.11.2
******************************************************************************/
void MLME_SCANconfirm(void)
{
}

/******************************************************************************
  Notifies that data request (poll) has been received.
  shortAddr - ahort address of the device which sent data request.
  IEEE802.15.4 paragraph: not specified (extra functionality implemented by Meshnetics).
  This event could be ignored.
******************************************************************************/
void MLME_POLLindication(MACShortAddr shortAddr)
{
}

/******************************************************************************
  Notifies that association request has been received.
  params - indication params.
  IEEE802.15.4 paragraph: 7.1.3.2
******************************************************************************/
void MLME_ASSOCIATEindication(MACAssociateIndParams* associateIndParams)
{
}

/******************************************************************************
  Notifies that association request has been completed.
  Pointer to confirm parameters was passed while MLME_ASSOCIATErequest
    procedure, now confirm parameters could be analyzed.
  IEEE802.15.4 paragraph: 7.1.3.4
******************************************************************************/
void MLME_ASSOCIATEconfirm(void)
{
}

/******************************************************************************
  Reports about the result of processing reset operation.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.9.2
******************************************************************************/
void MLME_RESETconfirm(MACStatus status)
{
  state = SET_RX_ON_WHEN_IDLE_STATE;
  params.macPIB.id = MAC_PIB_RX_ON_WHEN_IDLE_ID;
  params.macPIB.attr.rxOnWhenIdle = TRUE;
  MLME_SETrequest(&params.macPIB);
}

/******************************************************************************
  Indicates communication status.
  params - communication status parameters.
  IEEE802.15.4 paragraph: 7.1.12.1
******************************************************************************/
void MLME_COMM_STATUSindication(MACCommStatusIndParams* commStatusParams)
{
}

/******************************************************************************
  Notifies, that beacon has been received.
  params - params of beacon.
  IEEE802.15.4 paragraph: 7.1.5.1
******************************************************************************/
void MLME_BEACON_NOTIFYindication(MACBeaconIndParams *params)
{
}

/******************************************************************************
  Notifies that TRX enable request has been completed.
  Status of operation should be analyzed from MACRxEnableParams (MLME_RX_ENABLErequest procedure)
  IEEE802.15.4 paragraph: 7.1.10.2
******************************************************************************/
void MLME_RX_ENABLEconfirm(void)
{
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_GETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.6.2
******************************************************************************/
void MLME_GETconfirm(void)
{
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_SETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.13.2
******************************************************************************/
void MLME_SETconfirm(void)
{
  switch (state)
  {
    case SET_RX_ON_WHEN_IDLE_STATE:
         state = SET_MIN_BE_STATE;
         params.macPIB.id = MAC_PIB_MIN_BE_ID;
         params.macPIB.attr.minBE = 0;
         break;
  
    case SET_MIN_BE_STATE:
         state = SET_TX_POWER_STATE;
         params.macPIB.id = MAC_PIB_TX_POWER_ID;

#ifdef _MESHBEAN_PLATFORM
#ifndef _CERTIFICATION
         switch( sliders_read() & 0x03 ) // 2 lower sliders.
         {
            default:
            case 0:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_3_0DBM;
              break;
        
           case 1:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_MIN_7_2DBM;
              break;
        
            case 2:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_MIN_17_2DBM;
              break;
         }
#else         
         switch( sliders_read()) // 2 lower sliders.
         {
            default:
            case 0:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_3_0DBM;
              break;
            case 1:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_2_6DBM;
              break;
            case 2:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_2_1DBM;
              break;
            case 3:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_1_6DBM;
              break;
            case 4:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_1_1DBM;
              break;
            case 5:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_0_5DBM;
              break;
            case 6:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_MIN_0_2DBM;
              break;
            case 7:
              params.macPIB.attr.txPower = AT86RF230_TX_PWR_MIN_1_2DBM;
              break;
         }

#endif //_CERTIFICATION
#else //_MESHBEAN_PLATFORM
         params.macPIB.attr.txPower = AT86RF230_TX_PWR_3_0DBM;
#endif //_MESHBEAN_PLATFORM
         break;
     
    case SET_TX_POWER_STATE:
         state = SET_SHORT_ADDR_STATE;
         params.macPIB.id = MAC_PIB_SHORT_ADDR_ID;
         params.macPIB.attr.shortAddr = 0xADAD;
         break;
      
    case SET_SHORT_ADDR_STATE:
         params.start.panId = 0xDADA;
         channel = APP_START_CHANNEL-PHY_MIN_CHANNEL;
         while (!((1UL << (channel + PHY_MIN_CHANNEL)) & CHANNEL_MASK))
           channel = (channel + 1) & 0x0F;
         params.start.channel = channel + PHY_MIN_CHANNEL;
         params.start.panCoordinator = TRUE;
         params.start.coordRealignment = FALSE;
         MLME_STARTrequest(&params.start);
         return;
  
    default:
          while(1);
  }
  MLME_SETrequest(&params.macPIB);
}

/******************************************************************************
  Notifies, that presence of an orphan device.
  params - params of orphan device.
  IEEE802.15.4 paragraph: 7.1.8.1
******************************************************************************/
void MLME_ORPHANindication(MACOrphanIndParams *a)
{
}


/******************************************************************************
-----------------------  MSRV callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that hardware error has occured.
******************************************************************************/
void MSRV_hardwareError(void)
{
}


/******************************************************************************
---------  Auxiliary functions only for the RangeMeasurmentTool  --------------
******************************************************************************/
/******************************************************************************
  Notifies that frame was received. CRC checking and address filtering
  procedures were not performed.
  data - pointer to the received data.
  nextLQI - LQI of the received frame.
  nextRSSI - RSSI of the received frame.
******************************************************************************/
void sensTestAuxilary_frameReceiveDone(uint8_t *data, uint8_t nextLQI, uint8_t nextRSSI)
{
}

/******************************************************************************
  Notifies, that frame was sent.
******************************************************************************/
void sensTestAuxilary_sendFrameDone()
{
  if(dataParam.dataReqStatus == MAC_SUCCESS_STATUS)
  {
    sentFrameCounter++;
    if (Npacket2Tx>0) 
    {
      if (Npacket2Tx!=0x7FFF) Npacket2Tx--; 
    }
  }
  if(changeChannel)
  {
    params.start.channel = channel + PHY_MIN_CHANNEL;
    MLME_STARTrequest(&params.start);
    return;
  }
  if(MIN_DATA_PERIOD < DATA_PERIOD)
    appTimer_start(dataDelayTimerId, TIMER_ONE_SHOT_MODE, DATA_PERIOD - MIN_DATA_PERIOD); 
  else
   sendPacket();
}

/******************************************************************************
  Buttons events handlers.
******************************************************************************/

/******************************************************************************
  Button was pressed.
******************************************************************************/
void pressed(uint8_t bn)
{
  if(bn == 1)
  {
    timer_50msec  = 0;
    timer_500msec = 0;
  }
  else
  {
    changeChannel = TRUE;
    do
    {
      channel = (channel + 1) & 0x0F;
    }
    while (!((1UL << (channel + PHY_MIN_CHANNEL)) & CHANNEL_MASK));
  }
}

/******************************************************************************
  Button was released.
******************************************************************************/
void released( uint8_t bn)
{
  if(bn == 1)
  {
    int16_t interval = timer_50msec + timer_500msec * 10;
    if(interval < 2) 
      return;	// do nothing if interval is too short
    if(interval > 20) 
      Npacket2Tx = 0x7FFF;	// infinite generation
    else
      Npacket2Tx = NPACKETS;	// 10000 packets
  }
}

/******************************************************************************
Timer fired callback function.
******************************************************************************/
void dataDelayTimerFired(void)
{
  sendPacket();
}

/******************************************************************************
Timer fired callback function.
******************************************************************************/
void timerFired()
{
  // update timer
  timer_50msec++;
  if (timer_50msec == 10)
  {
    timer_50msec = 0;
    timer_500msec++;
  }
  
  if (timer_50msec == 0)
  {
    outputCounter = 0;
    stringLength = sprintf((char *)decStrBuf, "FC = %lu\n\r", sentFrameCounter);
#ifndef _RCB_PLATFORM    
    UARTsend();
#else //_RCB_PLATFORM    
    SPIsend();
#endif //_RCB_PLATFORM    
  }
  if (Npacket2Tx >= 1000)
  {
    // Set leds according to the channel.
    if(channel & 0x01) 
      leds_on(LED_GREEN);
    else
     leds_off(LED_GREEN);
    if(channel & 0x02)
      leds_on(LED_YELLOW);
    else
      leds_off(LED_YELLOW);
    if(channel & 0x04)
      leds_on(LED_RED);
    else
      leds_off(LED_RED);
  }
  else
  {
    // slow led blinking when there is no packets to send
    if (Npacket2Tx != 0)
    {
      if (timer_50msec < 5)
      {
        leds_on(LED_GREEN);
        leds_on(LED_YELLOW);
        leds_on(LED_RED);
      }
      else
      {
        leds_off(LED_GREEN);
        leds_off(LED_YELLOW);
        leds_off(LED_RED);
      }
    }
    else
    {
      // fast led blinking when there is no packets to send
      if (timer_50msec & 1)
      {
        leds_on(LED_GREEN);
        leds_on(LED_YELLOW);
        leds_on(LED_RED);
      }
      else
      {
        leds_off(LED_GREEN);
        leds_off(LED_YELLOW);
        leds_off(LED_RED);
      }
    }
  }
  //----------------------------------------
  // indicate generation mode: if we are 
  // in infinite loop: green, yellow, red,
  // otherwise read,yellow,green
  //----------------------------------------
  if ((timer_500msec & 7) == 0)
  {	
    register uint8_t timer = timer_50msec;
    if (Npacket2Tx == 0x7FFF)
    {
      switch(timer)
      {
        case 0:
           leds_on(LED_GREEN); 
           leds_off(LED_YELLOW); 
           leds_off(LED_RED); 
           break;
           
        case 1:
          leds_off(LED_GREEN); 
          leds_on(LED_YELLOW); 
          leds_off(LED_RED); 
          break;
          
        case 2:
          leds_off(LED_GREEN); 
          leds_off(LED_YELLOW); 
          leds_on(LED_RED); 
          break;
      }
    }
    else
    {
      switch(timer)
      {
        case 2:
          leds_on(LED_GREEN); 
          leds_off(LED_YELLOW); 
          leds_off(LED_RED); 
          break;
        case 1:
          leds_off(LED_GREEN); 
          leds_on(LED_YELLOW); 
          leds_off(LED_RED); 
          break;
        case 0:
          leds_off(LED_GREEN); 
          leds_off(LED_YELLOW); 
          leds_on(LED_RED); 
          break;
      }
    }
  }
}

#ifndef _RCB_PLATFORM    
/****************************************************************************
  Tryes to send byte through UART.
****************************************************************************/
void UARTsend(void)
{
  if(uart_put(USART_CHANNEL1, &decStrBuf[outputCounter], 1) == FAIL)
    TOS_post(UARTsend);
  else
  {
    outputCounter++;
    if( outputCounter < stringLength )
      TOS_post(UARTsend);
  }
}
#else //_RCB_PLATFORM    
/****************************************************************************
  Sends byte through SPI.
****************************************************************************/
void SPIsend(void)
{
  spi_rcb_select();
  spi_rcb_write(decStrBuf[outputCounter]);
  spi_rcb_deselect();
  outputCounter++;
  if( outputCounter < stringLength )
    TOS_post(SPIsend);
}
#endif //_RCB_PLATFORM    

// eof transmitter.c
