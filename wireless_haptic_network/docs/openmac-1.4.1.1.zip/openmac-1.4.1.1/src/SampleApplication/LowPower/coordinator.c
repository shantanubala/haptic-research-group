/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: coordinator.c
  Created: ALuzhetsky January 2007.
  Description: coordinator sample.
  Copyright: (c)Meshnetics.
********************************************************************************/

#include "MAC.h"
#include "MACWrapper.h"
#include "uid.h"
#include "leds.h"
#include "uart.h"
#include "sched.h"
#ifdef _RCB_PLATFORM
#include "spircb.h"
#endif //_RCB_PLATFORM

enum
{
  INIT_STATE,
  RESET_STATE,
  SET_EXT_ADDR_STATE,
  SET_SHORT_ADDR_STATE,
  SET_RX_ON_WHEN_IDLE_STATE,
  SET_ASSOCIATION_PERMIT_STATE,
  SET_BEACON_PAYLOAD_STATE,
  SET_TRANSACTION_PERSISTENCE_TIME,
  ED_SCAN_STATE,
  ACTIVE_SCAN_STATE,
  START_STATE,
  RX_ENABLE_STATE,
  COORD_IN_NETWORK_STATE,
} coordState = INIT_STATE; // Coordinator possible states.

typedef enum
{
  NO_DEVICE_STATE,              // The childTable cell is empty.
  ASSOCIATION_STATE,            // Association procedure state.
  DEVICE_IN_NETWORK_STATE,      // Device was associated and data exchanging is performing.
  PURGE_TO_ASSOCIATE_STATE,     // Purge procedure state after which association procedure will be executed.
  PURGE_TO_DISASSOCIATE_STATE,  // Purge procedure state after which node will be deleted.
} DeviceState_t; // End device possible states.

uint8_t beaconBuffer[MAX_PHY_PACKET_SIZE]; // Buffer to store beacon frame.

MACExtAddr coordExtAddr; // Own extended address.
uint8_t dataHandle = 0;  // Data packet handle. Should be unique for the several 
                         // data transfer operations at the same time.

union
{
  PHYEnergyLevel energy[PHY_CHANNELS_NUMBER];
  PANDescriptor  panDescriptor[MAX_PAN_DESCRIPTORS];
}scanResult; // Scanning procedure results.

union
{
  struct
  {
    MACScanReqParams  reqParams;            // Scanning request procedure parameters.
    MACScanConfParams confParams;           // Scanning confirm procedure parameters.
    uint8_t           currentChannel;       // Channel for the active scanning procedure.
  }scan;
  MACPIBParam            pibParam;          // SET/GET request/confirm procedures parameters.
  MACStartParams         startParams;       // Starting procedure parameters.
  MACRxEnableParams      rxEnableReqParams; // RX enable procedure parameters.
}coordParams;

typedef struct
{
  // Possible procedures parameters for the device when it is in the network.
  union
  {
    MACAssociateRespParams associateRespParams;
    MACDataParams          dataParams;
  }procParams;
  DeviceState_t deviceState; // Device's state.
  MACShortAddr  shortAddr;   // Device's short address.
  MACExtAddr    extAddr;     // Device's extended address. 
  uint8_t       transactionBuffer[MAX_PHY_PACKET_SIZE]; // Buffer for the association response and data transactions.
}EndDevDescr_t;

#ifdef _RCB_PLATFORM    
uint8_t  stringLength        = 0;    // Length of the string to send through SPI.
uint8_t  outputCounter       = 0;    // Counter of the bytes sent through UART.
uint8_t  decStrBuf[50];              // Buffer for messages converting.
#endif //_RCB_PLATFORM    

EndDevDescr_t childTable[END_DEVICE_MAX_NUMBER];

/******************************************************************************
  Functions prototypes.
******************************************************************************/
void trap(uint8_t trapNumber); // Trap function.

/******************************************************************************
  Functions declarations.
******************************************************************************/
#ifdef _RCB_PLATFORM    
  void SPIsend(void);
#endif //_RCB_PLATFORM    

/******************************************************************************
  Main entry point for the user application.
******************************************************************************/
void appEntry__main()
{
#ifndef _RCB_PLATFORM    
  {
    UARTMode_t uartMode;
  
    // UART settings.
    uartMode.baudrate = UART_BAUDRATE_38400;
    uartMode.data = UART_DATA8;
    uartMode.parity = UART_PARITY_NONE;
    uartMode.stopbits = UART_STOPBITS2;
    uartMode.flowControl.ctsControl = FALSE;
    uartMode.flowControl.rtsControl = FALSE; 
    uartMode.flowControl.dtrControl = FALSE;
    // UART configuring.
    uart_setConfig(USART_CHANNEL1, &uartMode);
    // UART openning.
    uart_open(USART_CHANNEL1);
  }
#else //_RCB_PLATFORM    
  {
    spi_rcb_init();
  }
#endif //_RCB_PLATFORM    
  // Leds opening.
  leds_open();
  leds_on(LED_YELLOW);
  // Child table clearing.
  memset(childTable, 0, sizeof(childTable));
  // MAC initing.
  MAC_init();
}


/******************************************************************************
---------------------------  Auxiliary functions  ----------------------------
******************************************************************************/

/******************************************************************************
  Trap function - catches exceptions.
******************************************************************************/
void trap(uint8_t trapNumber)
{
#ifdef _APP_TRAP
  uint8_t toggleCount;
  uint16_t delayCount = 0xFFFF;
  
  leds_on(LED_RED);
  leds_on(LED_YELLOW);
  leds_on(LED_GREEN);
  while(delayCount--);
  while(1)
  {
    toggleCount = trapNumber;
    while(toggleCount--)
    {
      leds_off(LED_YELLOW);
      delayCount = 0x5555;
      while(delayCount--);
      
      leds_on(LED_YELLOW);
      delayCount = 0x5555;
      while(delayCount--);
    }
    leds_on(LED_RED);
    leds_on(LED_GREEN);
    delayCount = 0xffff;
    while(delayCount--);
  }
#endif //_APP_TRAP
}

#ifdef _RCB_PLATFORM    
/****************************************************************************
  Sends byte through SPI.
****************************************************************************/
void SPIsend(void)
{
  spi_rcb_select();
  spi_rcb_write(decStrBuf[outputCounter]);
  spi_rcb_deselect();
  if(outputCounter < stringLength)
  {
    outputCounter++;
    TOS_post(SPIsend);
  }
  else
  {
    outputCounter = 0;
  }
}
#endif //_RCB_PLATFORM

/******************************************************************************
  Analyzes ED scanning procedure results to find channel with minimum ED value.
  returns: channel number with minimum ED value.
******************************************************************************/
uint8_t EDScanResultsAnalyzing(void)
{
  uint8_t i;         // Channels index.
  uint8_t minED = 0; // Energy result array element number with minimum ED value.
  
  for(i = 1; i < coordParams.scan.confParams.resultSize; i++)
    if(coordParams.scan.reqParams.result.energy[i] < coordParams.scan.reqParams.result.energy[minED])
      minED = i;
  
  for(i = PHY_MIN_CHANNEL; i <= PHY_MAX_CHANNEL; i++)
    if( (CHANNEL_MASK >> i) & 1ul )
    {
      if(!minED)
        break;
      minED--;
    }
  return i;
}

/******************************************************************************
  Checks for PANs with the same PANID.
  returns: TRUE if the same PAN ID was not found, FALSE - otherwise.
******************************************************************************/
bool activeScanResultsAnalyzing(void)
{
  uint8_t i; // PAN descriptors index.
  
  for(i = 0; i < coordParams.scan.confParams.resultSize; i++)
    if(coordParams.scan.reqParams.result.panDescriptor[i].coordPANId == PANID)
      return FALSE;
  return TRUE;
}

/******************************************************************************
  Perfoms active scanning procedure.
******************************************************************************/
void activeScan(void)
{
  leds_on(LED_GREEN);
#ifndef _RCB_PLATFORM
  uart_put(USART_CHANNEL1, "\n\rActive scanning", sizeof("\n\rActive scanning"));
#else //_RCB_PLATFORM
  stringLength = sprintf((char *)decStrBuf, "Active scanning\n\r");
  SPIsend();
#endif //_RCB_PLATFORM
  coordParams.scan.reqParams.type = MAC_ACTIVE_SCAN;
  coordParams.scan.currentChannel = EDScanResultsAnalyzing(); // ED scanning results analyzing to find channel with minimum ED value.
  coordParams.scan.reqParams.channels = 1ul << coordParams.scan.currentChannel;
  coordParams.scan.reqParams.duration = SCAN_DURATION;
  coordParams.scan.reqParams.maxResultSize = MAX_PAN_DESCRIPTORS;
  coordParams.scan.reqParams.result.panDescriptor = scanResult.panDescriptor;
  if(MLME_SCANrequest(&coordParams.scan.reqParams, &coordParams.scan.confParams) == FAIL)
      trap(1);
}

/******************************************************************************
  Perfoms energy detection scanning procedure.
******************************************************************************/
void EDScan(void)
{
  leds_on(LED_GREEN);
#ifndef _RCB_PLATFORM
  uart_put(USART_CHANNEL1, "\n\rED scanning", sizeof("\n\rED scanning"));
#else //_RCB_PLATFORM
  stringLength = sprintf((char *)decStrBuf, "ED scanning\n\r");
  SPIsend();
#endif //_RCB_PLATFORM
  coordParams.scan.reqParams.type = MAC_ED_SCAN;
  coordParams.scan.reqParams.channels = CHANNEL_MASK;
  coordParams.scan.reqParams.duration = SCAN_DURATION;
  coordParams.scan.reqParams.maxResultSize = sizeof(scanResult.energy);
  coordParams.scan.reqParams.result.energy = scanResult.energy;
  if(MLME_SCANrequest(&coordParams.scan.reqParams, &coordParams.scan.confParams) == FAIL)
      trap(2);
}


/******************************************************************************
  Looks for the device with particular state.
  params: state to find.
  returns: pointer to the device if it was found, FALSE - otherwise.
******************************************************************************/
EndDevDescr_t* findDeviceByState(DeviceState_t state)
{
  uint8_t i;
  
  for(i = 0; i < END_DEVICE_MAX_NUMBER; i++)
  if(childTable[i].deviceState == state)
    return &childTable[i];
  return FALSE;
}

/******************************************************************************
  Looks for the device with particular address.
  params: MACAddrMode
  returns: FALSE - if device was not found, pointer to the device descriptor - otherwise.
******************************************************************************/
EndDevDescr_t* findDeviceByAddr(MACAddrMode addrMode, MACAddr* addr)
{
  uint8_t i;
  
  if(addrMode == MAC_SHORT_ADDR_MODE)
  {
    for(i = 0; i < END_DEVICE_MAX_NUMBER; i++)
    if(childTable[i].shortAddr == addr->sh && childTable[i].deviceState != NO_DEVICE_STATE)
      return &childTable[i];
  }
  else
  {
    for(i = 0; i < END_DEVICE_MAX_NUMBER; i++)
    if(childTable[i].extAddr == addr->ext && childTable[i].deviceState != NO_DEVICE_STATE)
      return &childTable[i];
  }
  return FALSE;
}

/******************************************************************************
  Looks for the device with particular data handle.
  params: handle to find.
  returns: pointer to the device if it was found, FALSE - otherwise.
******************************************************************************/
EndDevDescr_t* findDeviceByHandle(uint8_t handle)
{
  uint8_t i;
  
  for(i = 0; i < END_DEVICE_MAX_NUMBER; i++)
  if(childTable[i].procParams.dataParams.msduHandle == handle && childTable[i].deviceState != NO_DEVICE_STATE)
    return &childTable[i];
  return FALSE;
}

/******************************************************************************
  Put data transaction for the particular device.
  params: pointer to the destination device.
  returns: result of DATArequest calling.
******************************************************************************/
result_t dataSending(EndDevDescr_t* devDescrPtr)
{
  MACFrameParams frameParams;

  devDescrPtr->procParams.dataParams.srcAddrMode = MAC_SHORT_ADDR_MODE;
  devDescrPtr->procParams.dataParams.srcPANId = PANID;
  devDescrPtr->procParams.dataParams.srcAddr.sh = (MACShortAddr )coordExtAddr;
  devDescrPtr->procParams.dataParams.dstAddrMode = MAC_SHORT_ADDR_MODE;
  devDescrPtr->procParams.dataParams.dstPANId = PANID;
  devDescrPtr->procParams.dataParams.dstAddr.sh = devDescrPtr->shortAddr;
  // Just to send something... for exapmle device extended address.
  devDescrPtr->procParams.dataParams.msduLength = sizeof(MACExtAddr);
  devDescrPtr->procParams.dataParams.msduHandle = ++dataHandle;
  devDescrPtr->procParams.dataParams.txOptions = MAC_INDIRECT_TXOPTION | MAC_ACK_TXOPTION;
  frameParams.type = MAC_DATA_TYPE;
  MSRV_getAffixLength(&frameParams);
  devDescrPtr->procParams.dataParams.msdu = devDescrPtr->transactionBuffer + frameParams.header;
  memcpy(devDescrPtr->procParams.dataParams.msdu, &devDescrPtr->extAddr, sizeof(MACExtAddr));
  return MCPS_DATArequest(&devDescrPtr->procParams.dataParams);
}


/******************************************************************************
---------------------  MAC Control callback functions  ------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MAC layer was initialized.
******************************************************************************/
result_t MAC_initDone(void)
{
  // MAC starting.
  MAC_start();
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was started.
******************************************************************************/
result_t MAC_startDone(void)
{
#ifndef _RCB_PLATFORM
  uart_put(USART_CHANNEL1, "\n\rCoordinator starting...", sizeof("\n\rCoordinator starting..."));
#else //_RCB_PLATFORM
  stringLength = sprintf((char *)decStrBuf, "Coordinator starting...\n\r");
  SPIsend();
#endif //_RCB_PLATFORM
  coordState = RESET_STATE;
  if(MLME_RESETrequest(TRUE) == FAIL)
    trap(3);
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was stoped.
******************************************************************************/
result_t MAC_stopDone(void)
{
  return SUCCESS;
}
  


/******************************************************************************
-----------------------  MCPS callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MSDU with the handle has been transfered.
  Status of operation should be analyzed from MACDataParams (MCPS_DATArequest procedure)
  IEEE802.15.4 paragraph: 7.1.1.2
******************************************************************************/
void MCPS_DATAconfirm(uint8_t handle)
{
  EndDevDescr_t* devDescrPtr;
#ifndef _RCB_PLATFORM
  uint8_t strBuf[50];
  uint8_t strLength;
#endif //_RCB_PLATFORM
  
  if((devDescrPtr = findDeviceByHandle(handle)) != FALSE)
  {
    switch(devDescrPtr->procParams.dataParams.status)
    {
      case MAC_SUCCESS_STATUS:
      case MAC_TRANSACTION_OVERFLOW_STATUS:
      case MAC_CHANNEL_ACCESS_FAILURE_STATUS:
      case MAC_NO_ACK_STATUS:
        if(dataSending(devDescrPtr) == FAIL)
          trap(4);
        break;

      case MAC_TRANSACTION_EXPIRED_STATUS:
        // Unsuccessful transmission
#ifndef _RCB_PLATFORM
        strLength = sprintf(strBuf, "\n\rDevice was lost Addr = 0x%04X", (int )devDescrPtr->shortAddr);
        uart_put(USART_CHANNEL1, strBuf, strLength);
#else //_RCB_PLATFORM
        stringLength = sprintf((char *)decStrBuf, "Device was lost Addr=0x%04X\n\r", (int )devDescrPtr->shortAddr);
        SPIsend();
#endif //_RCB_PLATFORM
        devDescrPtr->deviceState = NO_DEVICE_STATE;
        break;

      default:
        trap(5);
        break;
    }
  }
  else
   trap(6);
}

/******************************************************************************
  Notifies that data frame has been recieved.
  indParams - params of received data frame.
  IEEE802.15.4 paragraph: 7.1.1.3
******************************************************************************/
void MCPS_DATAindication(MACDataIndParams* params)
{
#ifndef _RCB_PLATFORM
  uint8_t strBuf[50];
  uint8_t strLength;
#endif //_RCB_PLATFORM
  
  leds_on(LED_RED);
#ifndef _RCB_PLATFORM
  strLength = sprintf(strBuf, "\n\rAddress = 0x%04X, RSSI = %02d dBm", (int )params->srcAddr.sh, (int )params->rssi);
  uart_put(USART_CHANNEL1, strBuf, strLength);
#else //_RCB_PLATFORM
  stringLength = sprintf((char *)decStrBuf, "Address=0x%04X, RSSI=%02ddBm\n\r", (int )params->srcAddr.sh, (int )params->rssi);
  SPIsend();
#endif //_RCB_PLATFORM
  leds_off(LED_RED);
}

/******************************************************************************
  Notifies that MSDU has been purged from transaction queue.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.1.5
******************************************************************************/
void MCPS_PURGEconfirm(MACStatus status)
{
  EndDevDescr_t* devDescrPtr;
  MACFrameParams frameParams;
  
  if((devDescrPtr = findDeviceByState(PURGE_TO_ASSOCIATE_STATE))!= FALSE)
  { // Empty cell in the child table was found.
    devDescrPtr->deviceState = ASSOCIATION_STATE;
    devDescrPtr->procParams.associateRespParams.extAddr = devDescrPtr->extAddr;
    devDescrPtr->procParams.associateRespParams.shortAddr = devDescrPtr->shortAddr; // Two lower bytes of extended address.
    devDescrPtr->procParams.associateRespParams.status = MAC_SUCCESS_STATUS;
    frameParams.type = MAC_ASSOCIATION_RESPONSE_COMMAND_TYPE;
    MSRV_getAffixLength(&frameParams);
    devDescrPtr->procParams.associateRespParams.msdu = devDescrPtr->transactionBuffer + frameParams.header;
    if(MLME_ASSOCIATEresponse(&devDescrPtr->procParams.associateRespParams) == FAIL)
      trap(7);
    return;
  }
  if((devDescrPtr = findDeviceByState(PURGE_TO_DISASSOCIATE_STATE))!= FALSE)
  { // Empty cell in the child table was found.
    devDescrPtr->deviceState = NO_DEVICE_STATE;
    return;
  }
  trap(8);
}
  

/******************************************************************************
-----------------------  MLME callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that disassociation request has been completed.
  addr - additional parameter (not described in the IEEE standard),
    extended address of the node whose disassociation procedure was finished.
  Status of operation should be analyzed from MACDisassociateReqParams (MLME_DISASSOCIATErequest procedure)
  IEEE802.15.4 paragraph: 7.1.4.3
******************************************************************************/
void MLME_DISASSOCIATEconfirm(MACExtAddr *addr)
{
}

/******************************************************************************
  Notifies, that disassociation request has been received.
  params - params of diassociation.
  IEEE802.15.4 paragraph: 7.1.4.2
******************************************************************************/
void MLME_DISASSOCIATEindication(MACDisassociateIndParams *param)
{
  EndDevDescr_t* devDescrPtr;
#ifndef _RCB_PLATFORM
  uint8_t strBuf[50];
  uint8_t strLength;
#endif //_RCB_PLATFORM

  if((devDescrPtr = findDeviceByAddr(MAC_EXT_ADDR_MODE, (MACAddr* )&param->extAddr)) != FALSE)
  {
#ifndef _RCB_PLATFORM
    strLength = sprintf(strBuf, "\n\rDevice initiates disassociation Addr = 0x%04X", (int )devDescrPtr->shortAddr);
    uart_put(USART_CHANNEL1, strBuf, strLength);
#else //_RCB_PLATFORM
        stringLength = sprintf((char *)decStrBuf, "Device initiates disassociation Addr=0x%04X\n\r", (int )devDescrPtr->shortAddr);
        SPIsend();
#endif //_RCB_PLATFORM
    switch(devDescrPtr->deviceState)
    {
      case DEVICE_IN_NETWORK_STATE:
        devDescrPtr->deviceState = PURGE_TO_DISASSOCIATE_STATE;
        MCPS_PURGErequest(devDescrPtr->procParams.dataParams.msduHandle);
        break;
        
      case ASSOCIATION_STATE:
      case PURGE_TO_ASSOCIATE_STATE:
      case PURGE_TO_DISASSOCIATE_STATE:
        // Do nothing in this case.
        break;
        
      default:
        trap(9);
        break;
    }
  }
  
}

/******************************************************************************
  Indicates synchronization loss.
  reason - reason of synchronization loss.
  IEEE802.15.4 paragraph: 7.1.15.2
******************************************************************************/
void MLME_SYNC_LOSSindication(MACStatus status)
{
}

/******************************************************************************
  Notifies that poll request has been completed.
  Status of operation should be analyzed from MACPollParams (MLME_POLLrequest procedure)
  IEEE802.15.4 paragraph: 7.1.16.2
******************************************************************************/
void MLME_POLLconfirm(void)
{
}

/******************************************************************************
  Notifies that start procedure was executed.
  Status of operation should be analyzed from MACStartParams (MLME_STARTrequest procedure)
  IEEE802.15.4 paragraph: 7.1.14.2
******************************************************************************/
void MLME_STARTconfirm(void)
{
  coordState = RX_ENABLE_STATE;
  coordParams.rxEnableReqParams.rxOnDuration = 1;  // Just to enable the receiver.
  MLME_RX_ENABLErequest(&coordParams.rxEnableReqParams);
}

/******************************************************************************
  Reports about the result of the scan operation.
  Scanning procedure results were passed among MLME_SCANrequest parameters.
  Scanning procedure results could be analyzed now.
  IEEE802.15.4 paragraph: 7.1.11.2
******************************************************************************/
void MLME_SCANconfirm(void)
{
#ifndef _RCB_PLATFORM
  uint8_t strBuf[30];
  uint8_t strLength;
#endif //_RCB_PLATFORM
  
  leds_off(LED_GREEN);
  switch(coordState)
  {
    case ED_SCAN_STATE:
      if( coordParams.scan.confParams.status != MAC_SUCCESS_STATUS )
        trap(10);
      coordState = ACTIVE_SCAN_STATE;
      activeScan();
      break;
    
    case ACTIVE_SCAN_STATE:
      if( coordParams.scan.confParams.status != MAC_SUCCESS_STATUS && coordParams.scan.confParams.status != MAC_NO_BEACON_STATUS )
        trap(11);
      if(activeScanResultsAnalyzing())
      {
#ifndef _RCB_PLATFORM
        strLength = sprintf(strBuf, "\n\rSelected channel = 0x%02X", (int )coordParams.scan.currentChannel);
        uart_put(USART_CHANNEL1, strBuf, strLength);
#else //_RCB_PLATFORM
        stringLength = sprintf((char *)decStrBuf, "Selected channel=0x%02X\n\r", (int )coordParams.scan.currentChannel);
        SPIsend();
#endif //_RCB_PLATFORM
        coordState = START_STATE;
        coordParams.startParams.panId = PANID;
        coordParams.startParams.channel = coordParams.scan.currentChannel;
        coordParams.startParams.panCoordinator = TRUE;
        coordParams.startParams.coordRealignment = FALSE;
        if(MLME_STARTrequest(&coordParams.startParams) == FAIL)
          trap(12);
      }
      else
      {
#ifndef _RCB_PLATFORM
        uart_put(USART_CHANNEL1, "\n\rPANID conflict!", sizeof("\n\rPANID conflict!"));
        coordState = ED_SCAN_STATE;
#else //_RCB_PLATFORM
        stringLength = sprintf((char *)decStrBuf, "PANID conflict!\n\r");
        SPIsend();
#endif //_RCB_PLATFORM
        EDScan();
      }
      break;

    default:
      trap(13);
      break;
  }

}

/******************************************************************************
  Notifies that data request (poll) has been received.
  shortAddr - ahort address of the device which sent data request.
  IEEE802.15.4 paragraph: not specified (extra functionality implemented by Meshnetics).
  This event could be ignored.
******************************************************************************/
void MLME_POLLindication(MACShortAddr shortAddr)
{
}

/******************************************************************************
  Notifies that association request has been received.
  params - indication params.
  IEEE802.15.4 paragraph: 7.1.3.2
******************************************************************************/
void MLME_ASSOCIATEindication(MACAssociateIndParams* associateIndParams)
{
  EndDevDescr_t* devDescrPtr;
  MACFrameParams frameParams;
#ifndef _RCB_PLATFORM
  uint8_t strBuf[50];
  uint8_t strLength;
#endif //_RCB_PLATFORM
  
  if((devDescrPtr = findDeviceByAddr(MAC_EXT_ADDR_MODE, (MACAddr* )&associateIndParams->extAddr)) == FALSE)
  { // Such device was not found in the child table.
#ifndef _RCB_PLATFORM
    strLength = sprintf(strBuf, "\n\rDevice associating Addr = 0x%04X", (int )associateIndParams->extAddr);
    uart_put(USART_CHANNEL1, strBuf, strLength);
#else //_RCB_PLATFORM
    stringLength = sprintf((char *)decStrBuf, "Device associating Addr=0x%04X\n\r", (int )associateIndParams->extAddr);
    SPIsend();
#endif //_RCB_PLATFORM

    if((devDescrPtr = findDeviceByState(NO_DEVICE_STATE))!= FALSE)
    { // Empty cell in the child table was found.
      devDescrPtr->deviceState = ASSOCIATION_STATE;
      devDescrPtr->extAddr = associateIndParams->extAddr;
      devDescrPtr->shortAddr = (MACShortAddr )associateIndParams->extAddr;
      devDescrPtr->procParams.associateRespParams.extAddr = associateIndParams->extAddr;
      devDescrPtr->procParams.associateRespParams.shortAddr = (MACShortAddr )associateIndParams->extAddr; // Two lower bytes of extended address.
      devDescrPtr->procParams.associateRespParams.status = MAC_SUCCESS_STATUS;
      frameParams.type = MAC_ASSOCIATION_RESPONSE_COMMAND_TYPE;
      MSRV_getAffixLength(&frameParams);
      devDescrPtr->procParams.associateRespParams.msdu = devDescrPtr->transactionBuffer + frameParams.header;
      if(MLME_ASSOCIATEresponse(&devDescrPtr->procParams.associateRespParams) == FAIL)
        trap(14);
    }
    else
    {
#ifndef _RCB_PLATFORM
      uart_put(USART_CHANNEL1, "... No space", sizeof("No space..."));
#else //_RCB_PLATFORM
      stringLength = sprintf((char *)decStrBuf, "... No space");
      SPIsend();
#endif //_RCB_PLATFORM
    }
  }
  else
  { // Such device is already in the table.
#ifndef _RCB_PLATFORM
    strLength = sprintf(strBuf, "\n\rDevice rejoin Addr = 0x%04X", (int )associateIndParams->extAddr);
    uart_put(USART_CHANNEL1, strBuf, strLength);
#else //_RCB_PLATFORM
    stringLength = sprintf((char *)decStrBuf, "Device rejoin Addr=0x%04X\n\r", (int )associateIndParams->extAddr);
    SPIsend();
#endif //_RCB_PLATFORM
    switch(devDescrPtr->deviceState)
    {
      case DEVICE_IN_NETWORK_STATE:
        devDescrPtr->deviceState = PURGE_TO_ASSOCIATE_STATE;
        MCPS_PURGErequest(devDescrPtr->procParams.dataParams.msduHandle);
        break;
        
      case ASSOCIATION_STATE:
      case PURGE_TO_ASSOCIATE_STATE:
      case PURGE_TO_DISASSOCIATE_STATE:
        break;
        
      default:
        trap(15);
        break;
    }
  }
}

/******************************************************************************
  Notifies that association request has been completed.
  Pointer to confirm parameters was passed while MLME_ASSOCIATErequest
    procedure, now confirm parameters could be analyzed.
  IEEE802.15.4 paragraph: 7.1.3.4
******************************************************************************/
void MLME_ASSOCIATEconfirm(void)
{
}

/******************************************************************************
  Reports about the result of processing reset operation.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.9.2
******************************************************************************/
void MLME_RESETconfirm(MACStatus status)
{
  coordState = SET_EXT_ADDR_STATE;
  coordParams.pibParam.id = MAC_PIB_EXT_ADDR_ID;
#ifdef _MESHBEAN_PLATFORM
  if(uid_read((uint64_t*)&coordParams.pibParam.attr.extAddr) != SUCCESS)
  {
    // Unique ID does not present.
    coordParams.pibParam.attr.extAddr = COORD_EXT_ADDR;
  }
#else
    coordParams.pibParam.attr.extAddr = COORD_EXT_ADDR;
#endif //_MESHBEAN_PLATFORM
  coordExtAddr = coordParams.pibParam.attr.extAddr;
  if(MLME_SETrequest(&coordParams.pibParam) == FAIL)
    trap(16);
}

/******************************************************************************
  Indicates communication status.
  params - communication status parameters.
  IEEE802.15.4 paragraph: 7.1.12.1
******************************************************************************/
void MLME_COMM_STATUSindication(MACCommStatusIndParams* commStatusParams)
{
  EndDevDescr_t* devDescrPtr;
#ifndef _RCB_PLATFORM
  uint8_t strBuf[50];
  uint8_t strLength;
#endif //_RCB_PLATFORM
  
  if((devDescrPtr = findDeviceByAddr(commStatusParams->dstAddrMode, &commStatusParams->dstAddr)) != FALSE)
  {
    if(commStatusParams->status != MAC_SUCCESS_STATUS)
    {
      // Association procedure was unsuccessful.
      devDescrPtr->deviceState = NO_DEVICE_STATE;
      
    }
    else
    {
      devDescrPtr->deviceState = DEVICE_IN_NETWORK_STATE;
#ifndef _RCB_PLATFORM
      strLength = sprintf(strBuf, "\n\rDevice was associated Addr = 0x%04X", (int )commStatusParams->dstAddr.sh);
      uart_put(USART_CHANNEL1, strBuf, strLength);
#else //_RCB_PLATFORM
      stringLength = sprintf((char *)decStrBuf, "Device was associated Addr=0x%04X\n\r", (int )commStatusParams->dstAddr.sh);
      SPIsend();
#endif //_RCB_PLATFORM
      if(dataSending(devDescrPtr) == FAIL)
        trap(17);
    }
  }
  else
  {
    trap(18);
  }
}

/******************************************************************************
  Notifies, that beacon has been received.
  params - params of beacon.
  IEEE802.15.4 paragraph: 7.1.5.1
******************************************************************************/
void MLME_BEACON_NOTIFYindication(MACBeaconIndParams *params)
{
}

/******************************************************************************
  Notifies that TRX enable request has been completed.
  Status of operation should be analyzed from MACRxEnableParams (MLME_RX_ENABLErequest procedure)
  IEEE802.15.4 paragraph: 7.1.10.2
******************************************************************************/
void MLME_RX_ENABLEconfirm(void)
{
  coordState = COORD_IN_NETWORK_STATE;
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_GETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.6.2
******************************************************************************/
void MLME_GETconfirm(void)
{
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_SETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.13.2
******************************************************************************/
void MLME_SETconfirm(void)
{
  MACFrameParams frameParams;
  uint32_t tmp32;

  if(coordParams.pibParam.status != MAC_SUCCESS_STATUS)
    trap(19);
    
  switch(coordState)
  {
    case SET_EXT_ADDR_STATE:
      coordState = SET_SHORT_ADDR_STATE;
      coordParams.pibParam.id = MAC_PIB_SHORT_ADDR_ID;
      //coordParams.pibParam.attr.shortAddr = ;  // Two lower bytes of the previous parameter
                                        // (extended address).
      break;
      
    case SET_SHORT_ADDR_STATE:
      coordState = SET_RX_ON_WHEN_IDLE_STATE;
      coordParams.pibParam.id = MAC_PIB_RX_ON_WHEN_IDLE_ID;
      coordParams.pibParam.attr.rxOnWhenIdle = TRUE;
      break;
    
    case SET_RX_ON_WHEN_IDLE_STATE:
      coordState = SET_ASSOCIATION_PERMIT_STATE;
      coordParams.pibParam.id = MAC_PIB_ASSOCIATION_PERMIT_ID;
      coordParams.pibParam.attr.associationPermit = TRUE;
      break;

    case SET_ASSOCIATION_PERMIT_STATE:
      coordState = SET_BEACON_PAYLOAD_STATE;
      frameParams.type = MAC_BEACON_TYPE;
      MSRV_getAffixLength(&frameParams);
      coordParams.pibParam.id = MAC_PIB_BEACON_PAYLOAD_ID;
      coordParams.pibParam.attr.beaconPayload = beaconBuffer + frameParams.header;
      break;
      
    case SET_BEACON_PAYLOAD_STATE:
      tmp32 = (uint32_t)SLEEP_PERIOD * 1000;
      tmp32 /= MAC_BASE_SLOT_DURATION; 
      tmp32 /= MAC_NUM_SUPERFRAME_SLOTS;
      tmp32 /= PHY_SYMBOL_DURATION;
      tmp32 *= 2;
      if(tmp32 > MAC_PIB_TRANSACTION_PERSISTENCE_TIME_DEFAULT)
      {
        coordState = SET_TRANSACTION_PERSISTENCE_TIME;
        coordParams.pibParam.id = MAC_PIB_TRANSACTION_PERSISTENCE_TIME_ID;
        coordParams.pibParam.attr.transactionPersistenceTime = tmp32;
        break;
      }

    case SET_TRANSACTION_PERSISTENCE_TIME:
      coordState = ED_SCAN_STATE;
      EDScan();
      return;

    default:
      trap(20);
      break;
  }
  if(MLME_SETrequest(&coordParams.pibParam) == FAIL)
    trap(21);
}

/******************************************************************************
  Notifies, that presence of an orphan device.
  params - params of orphan device.
  IEEE802.15.4 paragraph: 7.1.8.1
******************************************************************************/
void MLME_ORPHANindication(MACOrphanIndParams *a)
{
}


/******************************************************************************
-----------------------  MSRV callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that hardware error has occured.
******************************************************************************/
void MSRV_hardwareError(void)
{
}

// eof coordinator.c
