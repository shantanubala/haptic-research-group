/********************************************************************************
* MeshNetics OpenMAC Software Distribution
* 
*  
* The contents of this file are subject to the terms of the Common
* Development and Distribution License (the License). You may not use this
* file except in compliance with the License.  You can obtain a copy of the
* License at http://www.opensource.org/licenses/cddl1.txt.
*  
* When distributing Covered Code, include this CDDL Header Notice in each
* file and include the License. If applicable, add the following below the
* CDDL Header, with the fields enclosed by brackets [] replaced by your own
* identifying information:
* "Portions Copyrighted [year] [name of copyright owner]"
*  
* (c) 2007 MeshNetics.  All rights reserved.
*  
* Contact Information
* LuxLabs Ltd, dba MeshNetics
* Email: openmac@meshnetics.com
* www.meshnetics.com
*
********************************************************************************/

/********************************************************************************
  File: enddevice.c
  Created: ALuzhetsky January 2007.
  Description: end-device sample.
  Copyright: (c)Meshnetics.
********************************************************************************/

#include "MAC.h"
#include "MACWrapper.h"
#include "uid.h"
#include "sleep.h"
#include "sleeptimer.h"
#include "leds.h"

enum
{
  INIT_STATE,
  RESET_STATE,
  SET_EXT_ADDR_STATE,
  ACTIVE_SCAN_STATE,
  START_STATE,
  ASSOCIATION_STATE,
  GET_COORD_EXT_ADDR,
  DATA_SEND_STATE,
  POLL_STATE,
  DISASSOCIATE_STATE,
  SLEEP_STATE,
} endDevState = INIT_STATE; // End device possible states.


MACExtAddr   endDevExtAddr;  // Own extended address.
MACShortAddr coordShortAddr; // Coordinator's short address.
MACExtAddr   coordExtAddr;   // Coordinator's extended address.
uint8_t      dataHandle;     // Current data packet handle.
uint8_t      timerHandle;    // Timer's handle.
uint8_t      rssi;           // Received data packet RSSI value.
uint8_t      pollIterations; // Number of POLLrequest repeates.

union
{
  PHYEnergyLevel energy[PHY_CHANNELS_NUMBER];
  PANDescriptor  panDescriptor[MAX_PAN_DESCRIPTORS];
} scanResult; // Scan operation results.

uint8_t transactionBuffer[MAX_PHY_PACKET_SIZE]; // Buffer for the operations which are performed.
                                                // througth the transaction queue.

union
{
  struct
  {
    MACScanReqParams       reqParams;             // Scanning request procedure parameters.
    MACScanConfParams      confParams;            // Scanning confirm procedure parameters.
  } scan; 
  struct
  {
    MACAssociateReqParams  reqParams;             // Association request procedure parameters.
    MACAssociateConfParams confParams;            // Association confirm procedure parameters.
  } associate;
  MACPIBParam              pibParam;              // SET/GET request/confirm procedures parameters.
  MACDataParams            dataParams;            // Data request procedure parameters.
  MACPollParams            pollParams;            // Poll request procedure parameters.
  MACDisassociateReqParams disassociateReqParams; // Disassociation request procedure parameters.
  MACRxEnableParams        rxEnableReqParams;        // RxEnable request procedure parameters.
}endDevParams; 

/******************************************************************************
  Functions prototypes.
******************************************************************************/
void sleepTimerFired(void); // Sleep timer call back function.
void trap(uint8_t trapNumber); // Trap function.

/******************************************************************************
  Main entry point for the user application.
******************************************************************************/
void appEntry__main()
{
  timerHandle  = sleepTimer_open(sleepTimerFired);
  leds_open();
  leds_on(LED_YELLOW);
  MAC_init();
}


/******************************************************************************
---------------------------  Auxiliary functions  ----------------------------
******************************************************************************/
/******************************************************************************
  Trap function - catches exceptions.
******************************************************************************/
void trap(uint8_t trapNumber)
{
#ifdef _APP_TRAP
  uint8_t toggleCount;
  uint16_t delayCount = 0xFFFF;
  
  leds_on(LED_RED);
  leds_on(LED_YELLOW);
  leds_on(LED_GREEN);
  while(delayCount--);
  while(1)
  {
    toggleCount = trapNumber;
    while(toggleCount--)
    {
      leds_off(LED_YELLOW);
      delayCount = 0x5555;
      while(delayCount--);
      
      leds_on(LED_YELLOW);
      delayCount = 0x5555;
      while(delayCount--);
    }
    leds_on(LED_RED);
    leds_on(LED_GREEN);
    delayCount = 0xffff;
    while(delayCount--);
  }
#endif //_APP_TRAP
}

/******************************************************************************
  Looks for the coordinator with preferred PANID.
  returns: pointer to the PAN descriptor if coordinator was found, FALSE - otherwise.
******************************************************************************/
PANDescriptor* activeScanResultsAnalyzing(void)
{
  uint8_t i; // PAN descriptors index.
  
  for(i = 0; i < endDevParams.scan.confParams.resultSize; i++)
    if(endDevParams.scan.reqParams.result.panDescriptor[i].coordPANId == PANID)
      return &endDevParams.scan.reqParams.result.panDescriptor[i];
  return FALSE;
}

/******************************************************************************
  Perfoms active scanning procedure.
******************************************************************************/
void activeScan(void)
{
  leds_on(LED_GREEN);
  endDevParams.scan.reqParams.type = MAC_ACTIVE_SCAN;
  endDevParams.scan.reqParams.channels = CHANNEL_MASK;
  endDevParams.scan.reqParams.duration = SCAN_DURATION;
  endDevParams.scan.reqParams.maxResultSize = MAX_PAN_DESCRIPTORS;
  endDevParams.scan.reqParams.result.panDescriptor = scanResult.panDescriptor;
  if(MLME_SCANrequest(&endDevParams.scan.reqParams, &endDevParams.scan.confParams) == FAIL)
    trap(1);
}

/******************************************************************************
  Sends data to the coordinator.
  params: data - pointer to the data buffer, length - data length.
  returns: reesult of calling MCPS_DATArequest.
******************************************************************************/
result_t sendData(uint8_t* data, uint8_t length)
{
  MACFrameParams frameParams;

  endDevState = DATA_SEND_STATE;
  leds_on(LED_RED);
  endDevParams.dataParams.srcAddrMode = MAC_SHORT_ADDR_MODE;
  endDevParams.dataParams.srcPANId = PANID;
  endDevParams.dataParams.srcAddr.sh = (MACShortAddr )endDevExtAddr;
  endDevParams.dataParams.dstAddrMode = MAC_SHORT_ADDR_MODE;
  endDevParams.dataParams.dstPANId = PANID;
  endDevParams.dataParams.dstAddr.sh = coordShortAddr;
  endDevParams.dataParams.msduLength = length;
  endDevParams.dataParams.msduHandle = dataHandle++;
  endDevParams.dataParams.txOptions = MAC_ACK_TXOPTION;
  frameParams.type = MAC_DATA_TYPE;
  MSRV_getAffixLength(&frameParams);
  endDevParams.dataParams.msdu = transactionBuffer + frameParams.header;
  memcpy(endDevParams.dataParams.msdu, data, length);
  return MCPS_DATArequest(&endDevParams.dataParams);
}


/******************************************************************************
---------------------  MAC Control callback functions  ------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MAC layer was initialized.
******************************************************************************/
result_t MAC_initDone(void)
{
  MAC_start();
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was started.
******************************************************************************/
result_t MAC_startDone(void)
{
  endDevState = RESET_STATE;
  if(MLME_RESETrequest(TRUE) == FAIL)
    trap(2);
  return SUCCESS;
}

/******************************************************************************
  Notifies that MAC layer was stoped.
******************************************************************************/
result_t MAC_stopDone(void)
{
  return SUCCESS;
}


/******************************************************************************
-----------------------  MCPS callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that MSDU with the handle has been transfered.
  Status of operation should be analyzed from MACDataParams (MCPS_DATArequest procedure)
  IEEE802.15.4 paragraph: 7.1.1.2
******************************************************************************/
void MCPS_DATAconfirm(uint8_t handle)
{
  endDevState = SLEEP_STATE;
  leds_off(LED_YELLOW);
  leds_off(LED_RED);
  leds_close();
  sleepTimer_start(timerHandle, TIMER_ONE_SHOT_MODE, SLEEP_PERIOD);
  sleep();
}

/******************************************************************************
  Notifies that data frame has been recieved.
  indParams - params of received data frame.
  IEEE802.15.4 paragraph: 7.1.1.3
******************************************************************************/
void MCPS_DATAindication(MACDataIndParams* dataIndParams)
{
  rssi = dataIndParams->rssi;
}

/******************************************************************************
  Notifies that MSDU has been purged from transaction queue.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.1.5
******************************************************************************/
void MCPS_PURGEconfirm(MACStatus status)
{
}
  

/******************************************************************************
-----------------------  MLME callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that disassociation request has been completed.
  addr - additional parameter (not described in the IEEE standard),
    extended address of the node whose disassociation procedure was finished.
  Status of operation should be analyzed from MACDisassociateReqParams (MLME_DISASSOCIATErequest procedure)
  IEEE802.15.4 paragraph: 7.1.4.3
******************************************************************************/
void MLME_DISASSOCIATEconfirm(MACExtAddr* addr)
{
  endDevState = ACTIVE_SCAN_STATE;
  activeScan();
}

/******************************************************************************
  Notifies, that disassociation request has been received.
  params - params of diassociation.
  IEEE802.15.4 paragraph: 7.1.4.2
******************************************************************************/
void MLME_DISASSOCIATEindication(MACDisassociateIndParams* param)
{
}

/******************************************************************************
  Indicates synchronization loss.
  reason - reason of synchronization loss.
  IEEE802.15.4 paragraph: 7.1.15.2
******************************************************************************/
void MLME_SYNC_LOSSindication(MACStatus status)
{
}

/******************************************************************************
  Notifies that poll request has been completed.
  Status of operation should be analyzed from MACPollParams (MLME_POLLrequest procedure)
  IEEE802.15.4 paragraph: 7.1.16.2
******************************************************************************/
void MLME_POLLconfirm(void)
{
  MACFrameParams frameParams;

  if(endDevParams.pollParams.status != MAC_SUCCESS_STATUS)
  { // Coordinator has been lost.
    pollIterations++;
    if(pollIterations < MAX_POLL_ITERATIONS_NUMBER)  
    {
      if(MLME_POLLrequest(&endDevParams.pollParams) == FAIL)
        trap(3);
    }
    else
    {
      endDevState = DISASSOCIATE_STATE;
      endDevParams.disassociateReqParams.extAddr = coordExtAddr;
      endDevParams.disassociateReqParams.shortAddr = coordShortAddr;
      endDevParams.disassociateReqParams.reason = MAC_DEVICE_WISHES_LEAVE_PAN_REASON;
      frameParams.type = MAC_DISASSOCIATION_NOTIFICATION_COMMAND_TYPE;
      MSRV_getAffixLength(&frameParams);
      endDevParams.disassociateReqParams.msdu = transactionBuffer + frameParams.header;
      if(MLME_DISASSOCIATErequest(&endDevParams.disassociateReqParams) == FAIL)
        trap(4);
    }
  }
  else
  { // Data packet from the coordinator was received. RSSI is known now.
    sendData(&rssi, sizeof(rssi));
  }
}

/******************************************************************************
  Reports about the result of the scan operation.
  Scanning procedure results were passed among MLME_SCANrequest parameters.
  Scanning procedure results could be analyzed now.
  IEEE802.15.4 paragraph: 7.1.11.2
******************************************************************************/
void MLME_SCANconfirm(void)
{
  PANDescriptor* PDptr;
  
  leds_off(LED_GREEN);
  if( endDevParams.scan.confParams.status != MAC_SUCCESS_STATUS && endDevParams.scan.confParams.status != MAC_NO_BEACON_STATUS )
    trap(5);
  
  PDptr = activeScanResultsAnalyzing();
  if(PDptr)
  {
    rssi = PDptr->rssi;
    endDevState = ASSOCIATION_STATE;
    endDevParams.associate.reqParams.channel = PDptr->channel;
    endDevParams.associate.reqParams.coordAddrMode = PDptr->coordAddrMode;
    endDevParams.associate.reqParams.coordPANId = PDptr->coordPANId;
    endDevParams.associate.reqParams.coordAddr = PDptr->coordAddr;
    coordShortAddr = PDptr->coordAddr.sh; // Save coordinator short address.
    *(uint8_t* )(&endDevParams.associate.reqParams.capability) = 0;
    endDevParams.associate.reqParams.capability.deviceType = 1;
    endDevParams.associate.reqParams.capability.rxOnWhenIdle = 1;
    endDevParams.associate.reqParams.capability.allocateAddress = 1;
    if(MLME_ASSOCIATErequest(&endDevParams.associate.reqParams, &endDevParams.associate.confParams) == FAIL)
      trap(6);
  }
  else
    activeScan();
}

/******************************************************************************
  Notifies that association request has been completed.
  Pointer to confirm parameters was passed while MLME_ASSOCIATErequest
    procedure, now confirm parameters could be analyzed.
  IEEE802.15.4 paragraph: 7.1.3.4
******************************************************************************/
void MLME_ASSOCIATEconfirm(void)
{
  if(endDevParams.associate.confParams.status != MAC_SUCCESS_STATUS)
  {
    endDevState = ACTIVE_SCAN_STATE;
    activeScan();
  }
  else
  {
    endDevState = GET_COORD_EXT_ADDR;
    endDevParams.pibParam.id = MAC_PIB_COORD_EXT_ADDR_ID;
    if(MLME_GETrequest(&endDevParams.pibParam) == FAIL)
      trap(7);
  }
}

/******************************************************************************
  Reports about the result of processing reset operation.
  status - status of operation.
  IEEE802.15.4 paragraph: 7.1.9.2
******************************************************************************/
void MLME_RESETconfirm(MACStatus status)
{
  endDevState = SET_EXT_ADDR_STATE;
  endDevParams.pibParam.id = MAC_PIB_EXT_ADDR_ID;
#ifdef _MESHBEAN_PLATFORM
  if(uid_read((uint64_t*)&endDevParams.pibParam.attr.extAddr) != SUCCESS)
  {
    // Unique ID does not present.
    endDevParams.pibParam.attr.extAddr = ENDDEV_EXT_ADDR;
  }
#else //_MESHBEAN_PLATFORM
  endDevParams.pibParam.attr.extAddr = ENDDEV_EXT_ADDR;
#endif //_MESHBEAN_PLATFORM
  endDevExtAddr = endDevParams.pibParam.attr.extAddr;
  if(MLME_SETrequest(&endDevParams.pibParam) == FAIL)
    trap(8);
}

/******************************************************************************
  Notifies, that beacon has been received.
  params - params of beacon.
  IEEE802.15.4 paragraph: 7.1.5.1
******************************************************************************/
void MLME_BEACON_NOTIFYindication(MACBeaconIndParams* params)
{
}

/******************************************************************************
  Notifies that TRX enable request has been completed.
  Status of operation should be analyzed from MACRxEnableParams (MLME_RX_ENABLErequest procedure)
  IEEE802.15.4 paragraph: 7.1.10.2
******************************************************************************/
void MLME_RX_ENABLEconfirm(void)
{
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_GETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.6.2
******************************************************************************/
void MLME_GETconfirm(void)
{
  coordExtAddr = endDevParams.pibParam.attr.coordExtAddr;
  sendData(&rssi, sizeof(rssi));
}

/******************************************************************************
  Notifies, that attribute has been written.
  Status of operation should be analyzed from MACPIBParam (MLME_SETrequest procedure)
  IEEE802.15.4 paragraph: 7.1.13.2
******************************************************************************/
void MLME_SETconfirm(void)
{
  if(endDevParams.pibParam.status != MAC_SUCCESS_STATUS)
    trap(9);
    
  switch(endDevState)
  {
    case SET_EXT_ADDR_STATE:
      endDevState = ACTIVE_SCAN_STATE;
      activeScan();
      break;

    default:
      trap(10);
      break;
  }
}



/******************************************************************************
-----------------------  MSRV callback functions  -------------------------
******************************************************************************/
/******************************************************************************
  Notifies that hardware error has occured.
******************************************************************************/
void MSRV_hardwareError(void)
{
}

/******************************************************************************
------------------  Sleep timer fired call back function  ---------------------
******************************************************************************/
void sleepTimerFired(void)
{
  // Wake up!
  leds_open();
  leds_on(LED_YELLOW);
  endDevState = POLL_STATE;
  endDevParams.pollParams.coordAddrMode = MAC_SHORT_ADDR_MODE;
  endDevParams.pollParams.coordPANId = PANID;
  endDevParams.pollParams.coordAddr.sh = coordShortAddr;
  pollIterations = 0;
  if(MLME_POLLrequest(&endDevParams.pollParams) == FAIL)
    trap(11);
}

// eof enddevice.c
